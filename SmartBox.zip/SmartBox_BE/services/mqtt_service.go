package services

import (
	"SmartBox-backend/config"
	"SmartBox-backend/models"
	"bufio"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	MQTT "github.com/eclipse/paho.mqtt.golang"
)

// 定义MQTT服务接口
type MQTTServiceInterface interface {
	PublishCommand(command models.CommandPacket) error
	PublishRaw(data []byte) error
	GetDeviceStatus() models.DeviceStatus
	GetOperationHistory() []models.WSMessage
	GetDeviceID() string
	GetConfig() *config.MQTTConfig
	CheckConnection() bool
	GetConnectionInfo() map[string]interface{}
	GetMessageChan() <-chan models.WSMessage
	StartCommandInterface() // 启动命令行交互
	GetBoxStatus() bool
	WaitBoxStatusChange(timeout time.Duration) (bool, bool)
	SetDoorUnlockHandler(handler func(method string, id int))
}

// 确保MQTTService实现接口
var _ MQTTServiceInterface = (*MQTTService)(nil)

// MQTTService结构体
type MQTTService struct {
	client        MQTT.Client
	config        *config.MQTTConfig
	deviceStatus  *models.DeviceStatus
	history       []models.WSMessage
	mutex         sync.RWMutex
	messageChan   chan models.WSMessage
	isConnected   bool
	reconnectChan chan bool
	commandChan   chan string // 命令行指令通道
	boxStatus     bool
	boxStatusMu   sync.RWMutex
	waiters       []chan bool // 等待状态变化的通道
	waitersMu     sync.Mutex
	onDoorUnlock  func(method string, id int)
}

// BoxStatusPayload 柜门状态消息
type BoxStatusPayload struct {
	Type      string `json:"type"`
	DeviceID  string `json:"device_id"`
	Status    string `json:"status"`
	Timestamp int64  `json:"timestamp"`
}

// NewMQTTService 创建新的MQTT服务实例
func NewMQTTService(cfg *config.MQTTConfig) *MQTTService {
	service := &MQTTService{
		config: cfg,
		deviceStatus: &models.DeviceStatus{
			Online:    false,
			Timestamp: time.Now(),
		},
		history:       make([]models.WSMessage, 0),
		messageChan:   make(chan models.WSMessage, 100),
		isConnected:   false,
		reconnectChan: make(chan bool, 1),
		commandChan:   make(chan string, 10), // 初始化命令行通道
		waiters:       make([]chan bool, 0),
	}

	// 启动连接
	go service.startConnection()

	// 启动命令行交互界面
	go service.startCommandInterface()

	return service
}

func (s *MQTTService) startConnection() {
	// 初始连接
	s.connect()

	// 监听重连信号
	for range s.reconnectChan {
		time.Sleep(10 * time.Second) // 等待10秒后重连
		s.connect()
	}
}

func (s *MQTTService) connect() {
	if s.isConnected {
		return
	}

	opts := MQTT.NewClientOptions()
	opts.AddBroker(s.config.Broker)

	// 使用与上一段代码相同的客户端ID格式
	clientID := fmt.Sprintf("%s@@@ReceiveDevice", s.config.GroupID)

	// 使用与上一段代码相同的用户名格式
	username := s.config.AccessKey
	password := s.config.Password

	opts.SetClientID(clientID)
	opts.SetUsername(username)
	opts.SetPassword(password)
	opts.SetKeepAlive(60 * time.Second)
	opts.SetPingTimeout(10 * time.Second)
	opts.SetConnectTimeout(30 * time.Second)
	opts.SetAutoReconnect(true) // 启用自动重连，与上一段代码一致
	opts.SetCleanSession(true)

	// 设置连接回调
	opts.OnConnect = s.onConnect
	opts.OnConnectionLost = s.onConnectionLost

	// 设置默认消息处理器
	opts.SetDefaultPublishHandler(s.defaultMessageHandler)

	log.Printf("正在连接到MQTT服务器: %s", s.config.Broker)
	log.Printf("ClientID: %s", clientID)
	log.Printf("Username: %s", username)

	s.client = MQTT.NewClient(opts)

	if token := s.client.Connect(); token.Wait() && token.Error() != nil {
		log.Printf("MQTT连接失败: %v", token.Error())
		// 触发重连
		go s.triggerReconnect()
		return
	}
}

func (s *MQTTService) onConnect(client MQTT.Client) {
	log.Println("✅ MQTT连接成功")

	s.mutex.Lock()
	s.isConnected = true
	s.deviceStatus.Online = true
	s.deviceStatus.Timestamp = time.Now()
	s.mutex.Unlock()

	// 订阅指令主题 - 用于接收设备状态
	topicCmd := "device/smartlock_001/cmd"
	if token := client.Subscribe(topicCmd, 1, s.messageHandler); token.Wait() && token.Error() != nil {
		log.Printf("❌ 订阅指令主题失败: %v", token.Error())
	} else {
		log.Printf("✅ 成功订阅指令主题: %s", topicCmd)
	}

	// 订阅应答主题 - 用于接收设备应答包
	topicAck := "device/smartlock_001/ack"
	if token := client.Subscribe(topicAck, 1, s.messageHandler); token.Wait() && token.Error() != nil {
		log.Printf("❌ 订阅应答主题失败: %v", token.Error())
	} else {
		log.Printf("✅ 成功订阅应答主题: %s", topicAck)
	}

	// 订阅柜门状态主题
	topic := "device/+/box_status"
	if token := client.Subscribe(topic, 1, s.boxStatusHandler); token.Wait() && token.Error() != nil {
		log.Printf("[MQTT] 订阅主题 %s 失败: %v", topic, token.Error())
	} else {
		log.Printf("[MQTT] 已订阅主题: %s", topic)
	}

	s.addHistory("system", "MQTT连接成功", nil)
}

func (s *MQTTService) onConnectionLost(client MQTT.Client, err error) {
	log.Printf("❌ MQTT连接丢失: %v", err)

	s.mutex.Lock()
	s.isConnected = false
	s.deviceStatus.Online = false
	s.mutex.Unlock()

	s.addHistory("system", "MQTT连接丢失", nil)
}

func (s *MQTTService) triggerReconnect() {
	select {
	case s.reconnectChan <- true:
		// 成功发送重连信号
	default:
		// 通道已满，忽略
	}
}

func (s *MQTTService) defaultMessageHandler(client MQTT.Client, msg MQTT.Message) {
	log.Printf("收到消息 - 主题: %s, 消息: %s", msg.Topic(), string(msg.Payload()))
}

func (s *MQTTService) messageHandler(client MQTT.Client, msg MQTT.Message) {
	log.Printf("处理消息 - 主题: %s, 消息: %s", msg.Topic(), string(msg.Payload()))

	var base map[string]interface{}
	if err := json.Unmarshal(msg.Payload(), &base); err != nil {
		log.Printf("JSON解析失败: %v", err)
		return
	}

	pkgType, ok := base["pkg"].(string)
	if !ok {
		log.Printf("收到非标准协议消息: %s", string(msg.Payload()))
		// 尝试处理旧版协议
		s.handleLegacyMessage(msg.Payload())
		return
	}

	switch pkgType {
	case "ack":
		var response models.ResponsePacket
		if err := json.Unmarshal(msg.Payload(), &response); err == nil {
			s.handleAckResponse(response)
		} else {
			log.Printf("ACK包解析失败: %v", err)
		}
	case "info":
		var info models.InfoPacket
		if err := json.Unmarshal(msg.Payload(), &info); err == nil {
			s.handleInfoPacket(info)
		} else {
			log.Printf("INFO包解析失败: %v", err)
		}
	default:
		log.Printf("未知包类型: %s", pkgType)
	}
}

func (s *MQTTService) handleLegacyMessage(payload []byte) {
	var legacyMsg map[string]interface{}
	if err := json.Unmarshal(payload, &legacyMsg); err != nil {
		log.Printf("旧版消息解析失败: %v", err)
		return
	}

	// 处理状态查询响应
	if status, ok := legacyMsg["status"].(string); ok {
		if status == "online" {
			s.mutex.Lock()
			s.deviceStatus.Online = true
			if freeMemory, ok := legacyMsg["free_memory"].(float64); ok {
				s.deviceStatus.FreeMemory = uint32(freeMemory)
			}
			s.deviceStatus.Timestamp = time.Now()
			s.mutex.Unlock()

			s.addHistory("info", "设备状态更新", legacyMsg)
		}
	}
}

func (s *MQTTService) handleAckResponse(response models.ResponsePacket) {
	var message string
	if response.Result == "success" {
		message = fmt.Sprintf("✅ 操作成功: %s", response.App)
	} else {
		message = fmt.Sprintf("❌ 操作失败: %s, 错误: %s", response.App, response.Message)
	}

	s.addHistory("response", message, response)

	// 这里可以添加更多的业务逻辑，比如：
	// - 更新数据库中的操作状态
	// - 通过WebSocket向前端推送实时通知
	// - 记录操作日志等
	log.Printf("设备应答: 应用=%s, 结果=%s, 消息=%s",
		response.App, response.Result, response.Message)
}

func (s *MQTTService) handleInfoPacket(info models.InfoPacket) {
	message := fmt.Sprintf("📊 状态事件: %s, 方式: %s", info.Event, info.Method)
	s.addHistory("info", message, info)

	// 更新设备状态
	if info.Event == "door_unlock" || info.Event == "device_online" {
		s.mutex.Lock()
		s.deviceStatus.Online = true
		s.deviceStatus.Timestamp = time.Now()
		s.mutex.Unlock()
	}

	if info.Event == "door_unlock" && s.onDoorUnlock != nil {
		s.onDoorUnlock(info.Method, info.UserID)
	}
}

// 发送指令包 - 与上一段代码保持一致
func (s *MQTTService) sendCommand(cmd models.CommandPacket) error {
	if !s.isConnected {
		return fmt.Errorf("MQTT未连接，无法发送指令")
	}

	// 确保包类型正确
	cmd.Pkg = "cmd"

	data, err := json.Marshal(cmd)
	if err != nil {
		return fmt.Errorf("JSON编码失败: %v", err)
	}

	log.Printf("📤 发送指令: %s", string(data))

	topic := "device/smartlock_001/cmd"
	token := s.client.Publish(topic, 1, false, data)
	if token.Wait() && token.Error() != nil {
		return fmt.Errorf("MQTT发布失败: %v", token.Error())
	}

	s.addHistory("command", fmt.Sprintf("发送指令: %s", cmd.Cmd), cmd)
	return nil
}

// 实现接口方法
func (s *MQTTService) PublishCommand(command models.CommandPacket) error {
	return s.sendCommand(command)
}

func (s *MQTTService) PublishRaw(data []byte) error {
	if !s.isConnected {
		return fmt.Errorf("MQTT未连接")
	}

	// 注意：这里发布到指令主题，因为这是发送命令的地方
	topic := "device/smartlock_001/cmd"
	token := s.client.Publish(topic, 1, false, data)
	if token.Wait() && token.Error() != nil {
		return fmt.Errorf("MQTT发布失败: %v", token.Error())
	}

	log.Printf("发送原始数据: %s", string(data))
	return nil
}

func (s *MQTTService) GetDeviceStatus() models.DeviceStatus {
	s.mutex.RLock()
	defer s.mutex.RUnlock()
	return *s.deviceStatus
}

func (s *MQTTService) GetOperationHistory() []models.WSMessage {
	s.mutex.RLock()
	defer s.mutex.RUnlock()
	return s.history
}

func (s *MQTTService) addHistory(msgType string, message string, data interface{}) {
	s.mutex.Lock()
	defer s.mutex.Unlock()

	wsMessage := models.WSMessage{
		Type:      msgType,
		Message:   message,
		Data:      data,
		Timestamp: time.Now(),
	}

	s.history = append(s.history, wsMessage)

	// 保持历史记录在100条以内
	if len(s.history) > 100 {
		s.history = s.history[1:]
	}

	// 发送到消息通道
	select {
	case s.messageChan <- wsMessage:
	default:
		// 如果通道满了，丢弃消息
	}
}

func (s *MQTTService) GetMessageChan() <-chan models.WSMessage {
	return s.messageChan
}

// 检查连接状态
func (s *MQTTService) CheckConnection() bool {
	if s.client == nil {
		return false
	}
	return s.client.IsConnected()
}

// 获取连接信息
func (s *MQTTService) GetConnectionInfo() map[string]interface{} {
	return map[string]interface{}{
		"connected": s.isConnected,
		"broker":    s.config.Broker,
		"client_id": fmt.Sprintf("%s@@@ReceiveDevice", s.config.GroupID),
		"username":  "Signature|LTAI5t6Uuj4W1foByFjJYo5K|post-cn-7xh4ijj9603",
		"subscribed_topics": []string{
			"device/smartlock_001/cmd",
			"device/smartlock_001/ack",
		},
	}
}

// 获取设备ID
func (s *MQTTService) GetDeviceID() string {
	return s.config.DeviceID
}

// 获取配置信息（只读）
func (s *MQTTService) GetConfig() *config.MQTTConfig {
	return s.config
}

// 新增：启动命令行交互界面 - 与上一段代码保持一致
func (s *MQTTService) StartCommandInterface() {
	go s.startCommandInterface()
}

func (s *MQTTService) startCommandInterface() {
	reader := bufio.NewReader(os.Stdin)

	log.Println("🎯 门锁控制系统就绪!")
	log.Println("   输入以下命令控制门锁:")
	log.Println("   1. finger_enroll [id]          : 录入指纹")
	log.Println("   2. card_enroll [id]            : 录入卡片")
	log.Println("   3. open_door                   : 远程开门")
	log.Println("   4. reset_factory               : 恢复出厂设置")
	log.Println("   5. set_password [password]     : 设置永久密码")
	log.Println("   6. temp_password [id] [password] [count] [minutes] : 创建临时密码")
	log.Println("   7. delete_finger [id]          : 删除指纹")
	log.Println("   8. delete_card [id]            : 删除卡片")
	log.Println("   9. delete_temp_password [id]   : 删除临时密码")
	log.Println("   10. led_on                     : 打开LED")
	log.Println("   11. led_off                    : 关闭LED")
	log.Println("   12. status                     : 获取状态")
	log.Println("   13. custom [json]              : 发送自定义JSON")
	log.Println("   14. quit                       : 退出程序")
	log.Println("")

	for {
		fmt.Print("> ")
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)
		parts := strings.Fields(input)

		if len(parts) == 0 {
			continue
		}

		command := parts[0]

		switch command {
		case "quit":
			log.Println("👋 退出程序")
			os.Exit(0)

		case "finger_enroll":
			if len(parts) >= 2 {
				if id, err := strconv.Atoi(parts[1]); err == nil {
					cmd := models.CommandPacket{Pkg: "cmd", Cmd: "finger_enroll", ID: &id}
					s.sendCommand(cmd)
				}
			} else {
				log.Println("❌ 用法: finger_enroll [id]")
			}

		case "card_enroll":
			if len(parts) >= 2 {
				if id, err := strconv.Atoi(parts[1]); err == nil {
					cmd := models.CommandPacket{Pkg: "cmd", Cmd: "card_enroll", ID: &id}
					s.sendCommand(cmd)
				}
			} else {
				log.Println("❌ 用法: card_enroll [id]")
			}

		case "open_door":
			cmd := models.CommandPacket{Pkg: "cmd", Cmd: "open_door"}
			s.sendCommand(cmd)

		case "reset_factory":
			cmd := models.CommandPacket{Pkg: "cmd", Cmd: "reset_factory"}
			s.sendCommand(cmd)

		case "set_password":
			if len(parts) >= 2 {
				password := parts[1]
				cmd := models.CommandPacket{Pkg: "cmd", Cmd: "set_permanent_password", Password: &password}
				s.sendCommand(cmd)
			} else {
				log.Println("❌ 用法: set_password [password]")
			}

		case "temp_password":
			if len(parts) >= 5 {
				if id, err := strconv.Atoi(parts[1]); err == nil {
					password := parts[2]
					if useCount, err := strconv.Atoi(parts[3]); err == nil {
						if validMinutes, err := strconv.Atoi(parts[4]); err == nil {
							cmd := models.CommandPacket{
								Pkg:          "cmd",
								Cmd:          "create_temp_password",
								ID:           &id,
								Password:     &password,
								UseCount:     &useCount,
								ValidMinutes: &validMinutes,
							}
							s.sendCommand(cmd)
							continue
						}
					}
				}
				log.Println("❌ 参数格式错误")
			} else {
				log.Println("❌ 用法: temp_password [id] [password] [use_count] [valid_minutes]")
			}

		case "delete_finger":
			if len(parts) >= 2 {
				if id, err := strconv.Atoi(parts[1]); err == nil {
					cmd := models.CommandPacket{Pkg: "cmd", Cmd: "delete_finger", ID: &id}
					s.sendCommand(cmd)
				}
			} else {
				log.Println("❌ 用法: delete_finger [id]")
			}

		case "delete_card":
			if len(parts) >= 2 {
				if id, err := strconv.Atoi(parts[1]); err == nil {
					cmd := models.CommandPacket{Pkg: "cmd", Cmd: "delete_card", ID: &id}
					s.sendCommand(cmd)
				}
			} else {
				log.Println("❌ 用法: delete_card [id]")
			}

		case "delete_temp_password":
			if len(parts) >= 2 {
				if id, err := strconv.Atoi(parts[1]); err == nil {
					cmd := models.CommandPacket{Pkg: "cmd", Cmd: "delete_temp_password", ID: &id}
					s.sendCommand(cmd)
				}
			} else {
				log.Println("❌ 用法: delete_temp_password [id]")
			}

		case "led_on":
			// 使用CommandPacket结构体而不是原始JSON
			cmd := models.CommandPacket{Pkg: "cmd", Cmd: "led_on"}
			s.sendCommand(cmd)

		case "led_off":
			// 使用CommandPacket结构体而不是原始JSON
			cmd := models.CommandPacket{Pkg: "cmd", Cmd: "led_off"}
			s.sendCommand(cmd)

		case "status":
			// 向后兼容的状态查询
			msg := fmt.Sprintf(`{"command": "GET_STATUS", "device_id": "demo1", "timestamp": %d}`, time.Now().Unix())
			s.PublishRaw([]byte(msg))

		case "custom":
			if len(parts) >= 2 {
				customInput := strings.Join(parts[1:], " ")
				s.PublishRaw([]byte(customInput))
			} else {
				log.Println("❌ 用法: custom [json]")
			}

		default:
			log.Printf("❌ 未知命令: %s", command)
			log.Println("   输入 'help' 查看可用命令")
		}
	}
}

// ========== 柜门状态处理 ==========

// boxStatusHandler 处理柜门状态消息（符合 MQTT.MessageHandler 签名）
func (s *MQTTService) boxStatusHandler(client MQTT.Client, msg MQTT.Message) {
	topic := msg.Topic()
	log.Printf("[MQTT] 收到柜门状态消息 [%s]: %s", topic, string(msg.Payload()))

	var payload BoxStatusPayload
	if err := json.Unmarshal(msg.Payload(), &payload); err != nil {
		log.Printf("[MQTT] 解析 box_status JSON 失败: %v", err)
		return
	}

	log.Printf("[MQTT] 设备 %s 柜门状态: %s", payload.DeviceID, payload.Status)

	// 发送应答给 ESP32
	s.sendBoxStatusAck(payload.DeviceID)

	isOpen := payload.Status == "open"

	// 添加到历史记录
	s.addHistory("info", fmt.Sprintf("柜门已%s", payload.Status), payload)

	// 存储状态
	s.boxStatusMu.Lock()
	s.boxStatus = isOpen
	s.boxStatusMu.Unlock()

	// 唤醒所有等待的长轮询请求
	s.notifyBoxStatusChange(isOpen)
}

// sendBoxStatusAck 向设备发送应答
func (s *MQTTService) sendBoxStatusAck(deviceID string) {
	ackTopic := fmt.Sprintf("device/%s/cmd", deviceID)
	ackMsg := map[string]string{
		"pkg": "cmd",
		"cmd": "box_status_ack",
	}
	ackJSON, _ := json.Marshal(ackMsg)

	token := s.client.Publish(ackTopic, 1, false, ackJSON)
	if token.Wait() && token.Error() != nil {
		log.Printf("[MQTT] 发送应答失败: %v", token.Error())
	} else {
		log.Printf("[MQTT] 已发送应答到 %s", ackTopic)
	}
}

func (s *MQTTService) GetBoxStatus() bool {
	s.boxStatusMu.RLock()
	defer s.boxStatusMu.RUnlock()
	return s.boxStatus
}

// WaitBoxStatusChange 等待柜门状态变化，超时返回当前状态
func (s *MQTTService) WaitBoxStatusChange(timeout time.Duration) (bool, bool) {
	ch := make(chan bool, 1)

	s.waitersMu.Lock()
	s.waiters = append(s.waiters, ch)
	s.waitersMu.Unlock()

	select {
	case newStatus := <-ch:
		return newStatus, true
	case <-time.After(timeout):
		s.waitersMu.Lock()
		for i, waiter := range s.waiters {
			if waiter == ch {
				s.waiters = append(s.waiters[:i], s.waiters[i+1:]...)
				break
			}
		}
		s.waitersMu.Unlock()
		return s.GetBoxStatus(), false
	}
}

// notifyBoxStatusChange 唤醒所有等待者
func (s *MQTTService) notifyBoxStatusChange(isOpen bool) {
	s.waitersMu.Lock()
	defer s.waitersMu.Unlock()
	for _, ch := range s.waiters {
		select {
		case ch <- isOpen:
		default:
		}
	}
	s.waiters = make([]chan bool, 0)
}

func (s *MQTTService) SetDoorUnlockHandler(handler func(method string, id int)) {
	s.onDoorUnlock = handler
}
