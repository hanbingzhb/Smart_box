package routers

import (
	"SmartBox-backend/controllers"
	"SmartBox-backend/services"

	"github.com/gin-gonic/gin"
)

func SetupRouter(mqttService services.MQTTServiceInterface, smartBoxCtrl *controllers.SmartBoxController) *gin.Engine { // 使用接口类型
	router := gin.Default()

	// 配置CORS
	router.Use(func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}

		c.Next()
	})

	deviceController := controllers.NewDeviceController(mqttService)

	api := router.Group("/api/device")
	{
		api.POST("/door/open", deviceController.OpenDoor)
		api.POST("/reset", deviceController.ResetFactory)
		api.POST("/fingerprint/enroll", deviceController.EnrollFingerprint)
		api.POST("/fingerprint/delete", deviceController.DeleteFingerprint)
		api.POST("/card/enroll", deviceController.EnrollCard)
		api.POST("/card/delete", deviceController.DeleteCard)
		api.GET("/box_status", deviceController.GetBoxStatus)
	}

	apiV1 := router.Group("/api/v1")
	{
		// 用户管理
		apiV1.GET("/users", controllers.GetUsers)
		apiV1.POST("/users", controllers.CreateUser)
		apiV1.PUT("/users/:id", controllers.UpdateUser)
		apiV1.DELETE("/users/:id", controllers.DeleteUser)

		// 用户指纹
		// apiV1.POST("/users/:user_id/fingerprints", controllers.AddUserFingerprint)
		apiV1.DELETE("/fingerprints/:id", smartBoxCtrl.DeleteFingerprint)
		apiV1.GET("/fingerprints", controllers.GetFingerprints)
		apiV1.POST("/fingerprints/enroll", smartBoxCtrl.EnrollFingerprint) // 含数据库记录

		// 用户卡片
		// apiV1.POST("/users/:user_id/cards", controllers.AddUserCard)
		apiV1.DELETE("/cards/:id", smartBoxCtrl.DeleteCard)
		apiV1.GET("/cards", controllers.GetCards)
		apiV1.POST("/cards/enroll", smartBoxCtrl.EnrollCard) // 含数据库记录

		// 物品管理
		apiV1.GET("/goods", controllers.GetGoods)
		apiV1.POST("/goods", controllers.CreateGoods)
		apiV1.PUT("/goods/:id", controllers.UpdateGoods)
		apiV1.DELETE("/goods/:id", controllers.DeleteGoods)

		// 事件记录
		apiV1.GET("/events", controllers.GetEvents)
		apiV1.POST("/events", controllers.CreateEvent)
	}

	return router
}
