package models

import "time"

// 设备状态
type DeviceStatus struct {
	Online     bool      `json:"online"`
	LEDStatus  bool      `json:"led_status"`
	FreeMemory uint32    `json:"free_memory"`
	Timestamp  time.Time `json:"timestamp"`
}

// 指令包
type CommandPacket struct {
	Pkg          string  `json:"pkg"`
	Cmd          string  `json:"cmd"`
	ID           *int    `json:"id,omitempty"`
	Password     *string `json:"password,omitempty"`
	UseCount     *int    `json:"use_count,omitempty"`
	ValidMinutes *int    `json:"valid_minutes,omitempty"`
}

// 应答包
type ResponsePacket struct {
	Pkg     string `json:"pkg"`
	App     string `json:"app"`
	Result  string `json:"result"`
	Message string `json:"message,omitempty"`
}

// 状态包
type InfoPacket struct {
	Pkg    string `json:"pkg"`
	Event  string `json:"event"`
	Method string `json:"method"`
	UserID int    `json:"user_id,omitempty"`
}

// WebSocket消息
type WSMessage struct {
	Type      string      `json:"type"`
	Data      interface{} `json:"data"`
	Message   string      `json:"message,omitempty"`
	Timestamp time.Time   `json:"timestamp"`
}
