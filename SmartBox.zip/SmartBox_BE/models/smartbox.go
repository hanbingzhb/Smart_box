package models

type User struct {
	UserID  int    `gorm:"primaryKey;autoIncrement;column:user_id"`
	Name    string `gorm:"size:50;column:name" json:"name`
	IsAdmin bool   `gorm:"not null;default:false;column:is_admin"`
}

type UserFingerprint struct {
	FingerprintID int  `gorm:"primaryKey;autoIncrement;column:fingerprint_id"`
	UserID        int  `gorm:"column:user_id;not null;index"`
	User          User `gorm:"foreignKey:UserID;references:UserID;constraint:OnDelete:CASCADE"`
}

type UserCard struct {
	CardID int  `gorm:"primaryKey;autoIncrement;column:card_id"`
	UserID int  `gorm:"column:user_id;not null;index"`
	User   User `gorm:"foreignKey:UserID;references:UserID;constraint:OnDelete:CASCADE"`
}

type Goods struct {
	GoodsID   int    `gorm:"primaryKey;autoIncrement;column:goods_id"`
	GoodsName string `gorm:"size:100;column:goods_name"`
	CardID    int    `gorm:"not null;column:card_id"`
	IsInside  bool   `gorm:"not null;default:true;column:is_inside"`
}

type Event struct {
	EventID         int    `gorm:"primaryKey;autoIncrement;column:event_id"`
	UserID          int    `gorm:"column:user_id;not null;index"`
	GoodsID         int    `gorm:"column:goods_id;not null;index"`
	EventType       string `gorm:"type:enum('STORE','RETRIEVE');not null;column:event_type"`
	AccessTime      string `gorm:"not null;column:access_time"`
	OperatorRemarks string `gorm:"type:text;column:operator_remarks"`
	User            User   `gorm:"foreignKey:UserID;references:UserID"`
	Goods           Goods  `gorm:"foreignKey:GoodsID;references:GoodsID"`
}
