package config

import (
	"log"

	"github.com/spf13/viper"
)

// Config 定义应用程序的配置结构体
type Config struct {
	App      AppConfig      `mapstructure:"app"`
	MQTT     MQTTConfig     `mapstructure:"mqtt"`
	CORS     CORSConfig     `mapstructure:"cors"`
	Database DatabaseConfig `mapstructure:"database"`
}

// DatabaseConfig 定义数据库连接配置
type DatabaseConfig struct {
	Driver          string `mapstructure:"driver"`            // mysql
	Host            string `mapstructure:"host"`              // localhost
	Port            string `mapstructure:"port"`              // 3306
	Username        string `mapstructure:"username"`          // root
	Password        string `mapstructure:"password"`          // password
	DBName          string `mapstructure:"dbname"`            // smartbox
	Charset         string `mapstructure:"charset"`           // utf8mb4
	MaxIdleConns    int    `mapstructure:"max_idle_conns"`    // 10
	MaxOpenConns    int    `mapstructure:"max_open_conns"`    // 100
	ConnMaxLifetime int    `mapstructure:"conn_max_lifetime"` // 3600 (秒)
}

// AppConfig 定义应用程序配置
type AppConfig struct {
	Name    string `mapstructure:"name"`
	Port    string `mapstructure:"port"`
	Version string `mapstructure:"version"`
}

// MQTTConfig 定义 MQTT 连接配置
type MQTTConfig struct {
	Broker        string `mapstructure:"broker"`
	InstanceID    string `mapstructure:"instance_id"`
	GroupID       string `mapstructure:"group_id"`
	DeviceID      string `mapstructure:"device_id"`
	AccessKey     string `mapstructure:"access_key"`
	Password      string `mapstructure:"password"`
	TopicCommand  string `mapstructure:"topic_command"`
	TopicResponse string `mapstructure:"topic_response"`
}

// CORSConfig 定义 CORS 配置
type CORSConfig struct {
	AllowOrigins []string `mapstructure:"allow_origins"`
	AllowMethods []string `mapstructure:"allow_methods"`
	AllowHeaders []string `mapstructure:"allow_headers"`
}

var GlobalConfig *Config // 全局配置变量

// InitConfig 初始化配置
func InitConfig() {
	viper.SetConfigName("config")
	viper.SetConfigType("yml")
	viper.AddConfigPath(".")
	viper.AddConfigPath("./config")

	// 设置默认值
	viper.SetDefault("app.port", ":8080")
	viper.SetDefault("cors.allow_origins", []string{"*"})
	viper.SetDefault("cors.allow_methods", []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"})
	viper.SetDefault("cors.allow_headers", []string{"*"})

	// 数据库默认配置
	viper.SetDefault("database.driver", "mysql")
	viper.SetDefault("database.host", "localhost")
	viper.SetDefault("database.port", "3306")
	viper.SetDefault("database.charset", "utf8mb4")
	viper.SetDefault("database.max_idle_conns", 10)
	viper.SetDefault("database.max_open_conns", 100)
	viper.SetDefault("database.conn_max_lifetime", 3600)

	if err := viper.ReadInConfig(); err != nil {
		log.Printf("Warning: Error reading config file: %v, using defaults", err)
	}

	GlobalConfig = &Config{}
	if err := viper.Unmarshal(GlobalConfig); err != nil {
		log.Fatalf("Unable to decode config into struct: %v", err)
	}

	log.Println("Configuration loaded successfully")
}
