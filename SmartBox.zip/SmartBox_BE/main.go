package main

import (
	"SmartBox-backend/config"
	"SmartBox-backend/controllers"
	"SmartBox-backend/database"
	"SmartBox-backend/routers"
	"SmartBox-backend/services"
	"log"
)

func main() {
	// 初始化配置
	config.InitConfig()

	// 初始化数据库
	if err := database.InitDB(&config.GlobalConfig.Database); err != nil {
		log.Fatalf("数据库初始化失败: %v", err)
	}
	defer database.CloseDB()

	// 初始化MQTT服务
	var mqttService services.MQTTServiceInterface
	mqttService = services.NewMQTTService(&config.GlobalConfig.MQTT)

	// 创建智能储物柜业务控制器
	smartBoxCtrl := controllers.NewSmartBoxController(mqttService)

	mqttService.SetDoorUnlockHandler(func(method string, id int) {
		// 调用控制器中的业务处理方法
		smartBoxCtrl.HandleDoorUnlock(method, id)
	})

	// 设置路由
	router := routers.SetupRouter(mqttService, smartBoxCtrl)

	log.Printf("启动服务器在端口 %s", config.GlobalConfig.App.Port)
	if err := router.Run(config.GlobalConfig.App.Port); err != nil {
		log.Fatalf("服务器启动失败: %v", err)
	}
}
