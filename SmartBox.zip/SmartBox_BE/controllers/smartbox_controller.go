package controllers

import (
	"SmartBox-backend/database"
	"SmartBox-backend/models"
	"SmartBox-backend/services"
	"log"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
)

// SmartBoxController 智能储物柜业务控制器，整合数据库与MQTT
type SmartBoxController struct {
	mqttService services.MQTTServiceInterface
}

func NewSmartBoxController(mqtt services.MQTTServiceInterface) *SmartBoxController {
	return &SmartBoxController{mqttService: mqtt}
}

// ---------- 用户管理 ----------

// GetUsers 获取所有用户
func GetUsers(c *gin.Context) {
	var users []models.User
	if err := database.DB.Find(&users).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": users})
}

// CreateUser 创建用户
func CreateUser(c *gin.Context) {
	var user models.User
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := database.DB.Create(&user).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": user})
}

// UpdateUser 更新用户
func UpdateUser(c *gin.Context) {
	id := c.Param("id")
	var user models.User
	if err := database.DB.First(&user, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "用户不存在"})
		return
	}
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	database.DB.Save(&user)
	c.JSON(http.StatusOK, gin.H{"data": user})
}

// DeleteUser 删除用户（级联删除指纹和卡片）
func DeleteUser(c *gin.Context) {
	id := c.Param("id")
	if err := database.DB.Delete(&models.User{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "删除成功"})
}

// ---------- 用户指纹 ----------

// AddUserFingerprint 为用户添加指纹
func (ctrl *SmartBoxController) AddUserFingerprint(c *gin.Context) {
	userID, err := strconv.Atoi(c.Param("user_id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "无效的用户ID"})
		return
	}

	fp := models.UserFingerprint{UserID: userID}
	fingerprintID := fp.FingerprintID
	if err := database.DB.Create(&fp).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	cmd := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "finger_enroll",
		ID:  &fingerprintID,
	}

	if err := ctrl.mqttService.PublishCommand(cmd); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "发送MQTT指令失败: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message":        "指纹录入指令已发送",
		"fingerprint_id": fingerprintID,
		"user_id":        userID,
	})
}

// DeleteFingerprint 删除指纹
func (ctrl *SmartBoxController) DeleteFingerprint(c *gin.Context) {
	idStr := c.Param("id")
	fpID, err := strconv.Atoi(idStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "无效的指纹ID"})
		return
	}

	// 查询指纹记录（可选）
	var fp models.UserFingerprint
	if err := database.DB.First(&fp, fpID).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "指纹不存在"})
		return
	}

	// 构造MQTT删除指令
	cmd := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "delete_finger",
		ID:  &fpID,
	}

	// 发送MQTT指令
	if err := ctrl.mqttService.PublishCommand(cmd); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "发送MQTT指令失败: " + err.Error()})
		return
	}

	// 从数据库删除
	if err := database.DB.Delete(&models.UserFingerprint{}, fpID).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "删除成功"})
}

// ---------- 用户卡片 ----------

// AddUserCard 为用户添加卡片
func (ctrl *SmartBoxController) AddUserCard(c *gin.Context) {
	userID, err := strconv.Atoi(c.Param("user_id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "无效的用户ID"})
		return
	}

	card := models.UserCard{UserID: userID}
	cardID := card.CardID
	if err := database.DB.Create(&card).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	cmd := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "card_enroll",
		ID:  &cardID,
	}

	if err := ctrl.mqttService.PublishCommand(cmd); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "发送MQTT指令失败: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "卡片录入指令已发送",
		"card_id": cardID,
		"user_id": userID,
	})
}

// DeleteCard 删除卡片
func (ctrl *SmartBoxController) DeleteCard(c *gin.Context) {
	idStr := c.Param("id")
	cardID, err := strconv.Atoi(idStr)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "无效的卡片ID"})
		return
	}

	// 先查询卡片是否存在（可选，但发送MQTT前确认ID有效）
	var card models.UserCard
	if err := database.DB.First(&card, cardID).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "卡片不存在"})
		return
	}

	// 构造MQTT删除指令
	cmd := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "delete_card",
		ID:  &cardID,
	}

	// 发送MQTT指令
	if err := ctrl.mqttService.PublishCommand(cmd); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "发送MQTT指令失败: " + err.Error()})
		return
	}

	// 从数据库删除记录
	if err := database.DB.Delete(&models.UserCard{}, cardID).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "删除成功"})
}

// ---------- 物品管理 ----------

// GetGoods 获取所有物品
func GetGoods(c *gin.Context) {
	var goods []models.Goods
	if err := database.DB.Find(&goods).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": goods})
}

// CreateGoods 创建物品
func CreateGoods(c *gin.Context) {
	var goods models.Goods
	if err := c.ShouldBindJSON(&goods); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := database.DB.Create(&goods).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": goods})
}

// UpdateGoods 更新物品
func UpdateGoods(c *gin.Context) {
	id := c.Param("id")
	var goods models.Goods
	if err := database.DB.First(&goods, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "物品不存在"})
		return
	}
	if err := c.ShouldBindJSON(&goods); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	database.DB.Save(&goods)
	c.JSON(http.StatusOK, gin.H{"data": goods})
}

// DeleteGoods 删除物品
func DeleteGoods(c *gin.Context) {
	id := c.Param("id")
	if err := database.DB.Delete(&models.Goods{}, id).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "删除成功"})
}

// ---------- 事件记录 ----------

// GetEvents 获取事件列表（支持按用户/物品筛选）
func GetEvents(c *gin.Context) {
	var events []models.Event
	query := database.DB.Preload("User").Preload("Goods")

	if userID := c.Query("user_id"); userID != "" {
		query = query.Where("user_id = ?", userID)
	}
	if goodsID := c.Query("goods_id"); goodsID != "" {
		query = query.Where("goods_id = ?", goodsID)
	}
	if eventType := c.Query("type"); eventType != "" {
		query = query.Where("event_type = ?", eventType)
	}

	if err := query.Order("access_time desc").Find(&events).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": events})
}

// CreateEvent 创建存取事件
func CreateEvent(c *gin.Context) {
	var event models.Event
	if err := c.ShouldBindJSON(&event); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 可选：自动更新物品的 is_inside 状态
	tx := database.DB.Begin()
	if err := tx.Create(&event).Error; err != nil {
		tx.Rollback()
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// 根据事件类型更新物品位置状态
	var goods models.Goods
	if err := tx.First(&goods, event.GoodsID).Error; err == nil {
		if event.EventType == "STORE" {
			goods.IsInside = true
		} else if event.EventType == "RETRIEVE" {
			goods.IsInside = false
		}
		tx.Save(&goods)
	}

	tx.Commit()
	c.JSON(http.StatusOK, gin.H{"data": event})
}

// GetCards 获取所有卡片（含用户信息）
func GetCards(c *gin.Context) {
	var cards []models.UserCard
	if err := database.DB.Preload("User").Find(&cards).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": cards})
}

// GetFingerprints 获取所有指纹（含用户信息）
func GetFingerprints(c *gin.Context) {
	var fingerprints []models.UserFingerprint
	if err := database.DB.Preload("User").Find(&fingerprints).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": fingerprints})
}

// EnrollFingerprint 录入指纹（生成ID并发送MQTT指令）
func (ctrl *SmartBoxController) EnrollFingerprint(c *gin.Context) {
	var req struct {
		UserID int `json:"user_id" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 在数据库中创建指纹记录，获取自增ID
	fp := models.UserFingerprint{UserID: req.UserID}
	if err := database.DB.Create(&fp).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建指纹记录失败: " + err.Error()})
		return
	}

	// 使用生成的 ID 构造 MQTT 指令
	fingerprintID := fp.FingerprintID
	cmd := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "finger_enroll",
		ID:  &fingerprintID,
	}

	// 发送 MQTT 指令
	if err := ctrl.mqttService.PublishCommand(cmd); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "发送MQTT指令失败: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message":        "指纹录入指令已发送",
		"fingerprint_id": fingerprintID,
		"user_id":        req.UserID,
	})
}

// EnrollCard 录入卡片（生成ID并发送MQTT指令）
func (ctrl *SmartBoxController) EnrollCard(c *gin.Context) {
	var req struct {
		UserID int `json:"user_id" binding:"required"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 创建卡片记录
	card := models.UserCard{UserID: req.UserID}
	if err := database.DB.Create(&card).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建卡片记录失败: " + err.Error()})
		return
	}

	// 构造 MQTT 指令
	cardID := card.CardID
	cmd := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "card_enroll",
		ID:  &cardID,
	}

	// 发送指令
	if err := ctrl.mqttService.PublishCommand(cmd); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "发送MQTT指令失败: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "卡片录入指令已发送",
		"card_id": cardID,
		"user_id": req.UserID,
	})
}

func (ctrl *SmartBoxController) HandleDoorUnlock(method string, id int) {
	switch method {
	case "finger":
		// 指纹开门：查询指纹对应的用户
		var fp models.UserFingerprint
		if err := database.DB.First(&fp, id).Error; err != nil {
			log.Printf("指纹ID %d 未找到对应记录", id)
			return
		}
		event := models.Event{
			UserID:          fp.UserID,
			GoodsID:         0,
			EventType:       "STORE",
			AccessTime:      time.Now().Format("2006-01-02 15:04:05"),
			OperatorRemarks: "用户指纹开门",
		}
		database.DB.Create(&event)
		log.Printf("用户 %d 通过指纹开门", fp.UserID)

	case "card":
		// 先尝试作为用户卡片处理
		var userCard models.UserCard
		if err := database.DB.First(&userCard, id).Error; err == nil {
			// 找到用户卡片，记录开门事件
			event := models.Event{
				UserID:          userCard.UserID,
				GoodsID:         0,
				EventType:       "STORE",
				AccessTime:      time.Now().Format("2006-01-02 15:04:05"),
				OperatorRemarks: "用户卡片开门",
			}
			database.DB.Create(&event)
			log.Printf("用户 %d 通过卡片开门", userCard.UserID)
			return
		}

		// 不是用户卡片，尝试作为物品卡片处理
		var goods models.Goods
		if err := database.DB.Where("card_id = ?", id).First(&goods).Error; err != nil {
			log.Printf("卡片ID %d 未找到对应记录（既非用户卡也非物品卡）", id)
			return
		}

		// 切换物品状态
		goods.IsInside = !goods.IsInside
		if err := database.DB.Save(&goods).Error; err != nil {
			log.Printf("更新物品状态失败: %v", err)
			return
		}

		eventType := "RETRIEVE"
		if goods.IsInside {
			eventType = "STORE"
		}
		event := models.Event{
			UserID:          0,
			GoodsID:         goods.GoodsID,
			EventType:       eventType,
			AccessTime:      time.Now().Format("2006-01-02 15:04:05"),
			OperatorRemarks: "物品卡片识别",
		}
		database.DB.Create(&event)
		log.Printf("物品 %d 状态已切换为 %v", goods.GoodsID, goods.IsInside)

	default:
		log.Printf("未知开门方式: %s", method)
	}
}
