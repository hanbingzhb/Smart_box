package controllers

import (
	"SmartBox-backend/models"
	"SmartBox-backend/services"
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
)

type DeviceController struct {
	mqttService services.MQTTServiceInterface // 使用接口类型
}

func NewDeviceController(mqttService services.MQTTServiceInterface) *DeviceController { // 使用接口类型
	return &DeviceController{
		mqttService: mqttService,
	}
}

// 发送指令
func (dc *DeviceController) SendCommand(c *gin.Context) {
	var command models.CommandPacket
	if err := c.ShouldBindJSON(&command); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 确保包类型为cmd
	command.Pkg = "cmd"

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"message": "指令发送成功",
		"command": command.Cmd,
	})
}

// 获取设备状态
func (dc *DeviceController) GetStatus(c *gin.Context) {
	status := dc.mqttService.GetDeviceStatus()
	c.JSON(http.StatusOK, status)
}

// 获取操作历史
func (dc *DeviceController) GetHistory(c *gin.Context) {
	history := dc.mqttService.GetOperationHistory()
	c.JSON(http.StatusOK, gin.H{"history": history})
}

// 指纹管理
func (dc *DeviceController) FingerEnroll(c *gin.Context) {
	var req struct {
		ID int `json:"id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "finger_enroll",
		ID:  &req.ID,
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "指纹录入指令已发送"})
}

func (dc *DeviceController) FingerDelete(c *gin.Context) {
	var req struct {
		ID int `json:"id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "delete_finger",
		ID:  &req.ID,
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "指纹删除指令已发送"})
}

// 卡片管理
func (dc *DeviceController) CardEnroll(c *gin.Context) {
	var req struct {
		ID int `json:"id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "card_enroll",
		ID:  &req.ID,
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "卡片录入指令已发送"})
}

func (dc *DeviceController) CardDelete(c *gin.Context) {
	var req struct {
		ID int `json:"id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "delete_card",
		ID:  &req.ID,
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "卡片删除指令已发送"})
}

// 开门控制
func (dc *DeviceController) OpenDoor(c *gin.Context) {
	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "open_door",
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "开门指令已发送"})
}

// 恢复出厂设置
func (dc *DeviceController) ResetFactory(c *gin.Context) {
	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "reset_factory",
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "恢复出厂设置指令已发送"})
}

// 录入指纹
func (dc *DeviceController) EnrollFingerprint(c *gin.Context) {
	var req struct {
		ID int `json:"id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "finger_enroll",
		ID:  &req.ID,
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": fmt.Sprintf("指纹录入指令已发送，ID: %d", req.ID)})
}

// 录入卡片
func (dc *DeviceController) EnrollCard(c *gin.Context) {
	var req struct {
		ID int `json:"id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "card_enroll",
		ID:  &req.ID,
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": fmt.Sprintf("卡片录入指令已发送，ID: %d", req.ID)})
}

// 删除指纹
func (dc *DeviceController) DeleteFingerprint(c *gin.Context) {
	var req struct {
		ID int `json:"id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "delete_finger",
		ID:  &req.ID,
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": fmt.Sprintf("删除指纹指令已发送，ID: %d", req.ID)})
}

// 删除卡片
func (dc *DeviceController) DeleteCard(c *gin.Context) {
	var req struct {
		ID int `json:"id" binding:"required"`
	}

	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	command := models.CommandPacket{
		Pkg: "cmd",
		Cmd: "delete_card",
		ID:  &req.ID,
	}

	if err := dc.mqttService.PublishCommand(command); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": fmt.Sprintf("删除卡片指令已发送，ID: %d", req.ID)})
}

// GetBoxStatus 获取柜门状态
func (dc *DeviceController) GetBoxStatus(c *gin.Context) {
	isOpen := dc.mqttService.GetBoxStatus()
	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"data": gin.H{
			"box_open":  isOpen,
			"timestamp": time.Now().Unix(),
		},
	})
}

// WaitBoxStatus 长轮询接口：等待柜门状态变化
func (dc *DeviceController) WaitBoxStatus(c *gin.Context) {
	timeout := 30 * time.Second // 最长等待 30 秒

	newStatus, changed := dc.mqttService.WaitBoxStatusChange(timeout)

	c.JSON(http.StatusOK, gin.H{
		"code": 0,
		"data": gin.H{
			"box_open":  newStatus,
			"changed":   changed,
			"timestamp": time.Now().Unix(),
		},
	})
}
