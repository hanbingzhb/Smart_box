// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  // 原有控制面板保留
  {
    path: '/',
    name: 'Dashboard',
    component: () => import('@/views/Dashboard.vue')
  },
  // 新增数据库管理路由
  {
    path: '/users',
    name: 'UserManagement',
    component: () => import('@/views/UserManagement.vue')
  },
  {
    path: '/fingerprints',
    name: 'FingerprintManagement',
    component: () => import('@/views/FingerprintManagement.vue')
  },
  {
    path: '/cards',
    name: 'CardManagement',
    component: () => import('@/views/CardManagement.vue')
  },
  {
    path: '/goods',
    name: 'GoodsManagement',
    component: () => import('@/views/GoodsManagement.vue')
  },
  {
    path: '/events',
    name: 'EventManagement',
    component: () => import('@/views/EventManagement.vue')
  },
  // 保留原有的指纹/卡片管理页面（若需要可删除）
  {
    path: '/finger',
    redirect: '/fingerprints'
  },
  {
    path: '/card',
    redirect: '/cards'
  },
  {
    path: '/history',
    redirect: '/events'
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
