// src/stores/device.js
import { defineStore } from 'pinia'
import { ref } from 'vue'
import { deviceApi } from '@/api/device'

export const useDeviceStore = defineStore('device', () => {
   // 状态
  const status = ref({
    online: false,
    led_status: false,
    free_memory: 0,
    timestamp: null,
    box_open: false
  })

  const history = ref([])
  const loading = ref(false)

  const fetchStatus = async () => {
    try {
      // 模拟状态更新
      status.value.timestamp = new Date().toISOString()
      status.value.online = true
    } catch (error) {
      console.error('获取设备状态失败:', error)
    }
  }

  const fetchHistory = async () => {
    try {
      // 模拟历史记录
      history.value = [
        {
          id: 1,
          type: 'command',
          message: 'LED开启指令',
          timestamp: new Date().toISOString(),
          data: { action: 'LED_ON' }
        }
      ]
    } catch (error) {
      console.error('获取操作历史失败:', error)
    }
  }

  // LED 控制
  const controlLED = async (action) => {
    loading.value = true
    try {
      await deviceApi.controlLED(action)
      await fetchStatus()
    } catch (error) {
      console.error('LED控制失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // 开锁
  const openDoor = async () => {
    loading.value = true
    try {
      await deviceApi.openDoor()
      await fetchStatus()
    } catch (error) {
      console.error('开锁失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // 恢复出厂设置
  const resetFactory = async () => {
    loading.value = true
    try {
      await deviceApi.resetFactory()
      await fetchStatus()
    } catch (error) {
      console.error('恢复出厂设置失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // === 添加指纹管理方法 ===
  const fingerEnroll = async (id) => {
    loading.value = true
    try {
      console.log('🔄 Store: 开始指纹录入，ID:', id)
      await deviceApi.fingerEnroll(id)
      await fetchStatus()
      console.log('✅ Store: 指纹录入指令发送成功')
    } catch (error) {
      console.error('❌ Store: 指纹录入失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  const fingerDelete = async (id) => {
    loading.value = true
    try {
      console.log('🔄 Store: 开始删除指纹，ID:', id)
      await deviceApi.fingerDelete(id)
      await fetchStatus()
      console.log('✅ Store: 指纹删除指令发送成功')
    } catch (error) {
      console.error('❌ Store: 指纹删除失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // === 添加卡片管理方法 ===
  const cardEnroll = async (id) => {
    loading.value = true
    try {
      await deviceApi.cardEnroll(id)
      await fetchStatus()
    } catch (error) {
      console.error('卡片录入失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  const cardDelete = async (id) => {
    loading.value = true
    try {
      await deviceApi.cardDelete(id)
      await fetchStatus()
    } catch (error) {
      console.error('卡片删除失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // 为了兼容性，保留 sendCommand 方法
  const sendCommand = async (command) => {
    loading.value = true
    try {
      if (command.cmd === 'LED_ON' || command.cmd === 'LED_OFF') {
        await deviceApi.controlLED(command.cmd === 'LED_ON' ? 'on' : 'off')
      } else if (command.cmd === 'open_door') {
        await deviceApi.openDoor()
      } else if (command.cmd === 'reset_factory') {
        await deviceApi.resetFactory()
      } else {
        throw new Error(`未知命令: ${command.cmd}`)
      }
      await fetchStatus()
    } catch (error) {
      console.error('发送指令失败:', error)
      throw error
    } finally {
      loading.value = false
    }
  }

  // 递归长轮询
  let pollingActive = true
  const startLongPolling = async () => {
    while (pollingActive) {
      try {
        const res = await deviceApi.waitBoxStatus(30)
        if (res.data.code === 0) {
          const data = res.data.data
          const isOpen = data.box_open

          if (data.changed) {
            // 状态发生了变化
            status.value.box_open = isOpen
            history.value.unshift({
              id: Date.now() + Math.random(),
              type: 'info',
              message: `柜门已${isOpen ? '打开' : '关闭'}`,
              timestamp: new Date(data.timestamp * 1000).toISOString(),
              data: data
            })
            if (history.value.length > 100) history.value.pop()
            ElMessage.info(`柜门已${isOpen ? '打开' : '关闭'}`)
          }
          status.value.timestamp = new Date().toISOString()
        }
      } catch (error) {
        console.error('长轮询出错，2秒后重试:', error)
        await new Promise(resolve => setTimeout(resolve, 2000))
      }
    }
  }

  const stopLongPolling = () => {
    pollingActive = false
  }

  // 获取初始状态（短超时）
  const fetchInitialStatus = async () => {
    try {
      const res = await deviceApi.waitBoxStatus(1)
      if (res.data.code === 0) {
        status.value.box_open = res.data.data.box_open
        status.value.timestamp = new Date().toISOString()
      }
    } catch (error) {
      console.error('获取初始状态失败:', error)
    }
  }

  return {
    status,
    history,
    loading,
    fetchStatus,
    fetchHistory,
    fetchInitialStatus,
    sendCommand,
    controlLED,
    openDoor,
    resetFactory,

    fingerEnroll,
    fingerDelete,
    cardEnroll,
    cardDelete
  }
})
