// src/stores/database.js
import { defineStore } from 'pinia'
import { ref } from 'vue'
import { userApi, fingerprintApi, cardApi, goodsApi, eventApi } from '@/api/database'

export const useDatabaseStore = defineStore('database', () => {
  // 状态
  const users = ref([])
  const fingerprints = ref([])
  const cards = ref([])
  const goods = ref([])
  const events = ref([])
  const loading = ref(false)

  // ---------- 用户操作 ----------
  const fetchUsers = async () => {
    loading.value = true
    try {
      const res = await userApi.getUsers()
      users.value = res.data.data || [] 
    } finally {
      loading.value = false
    }
  }

  const createUser = async (data) => {
    await userApi.createUser(data)
    await fetchUsers()
  }

  const updateUser = async (id, data) => {
    await userApi.updateUser(id, data)
    await fetchUsers()
  }

  const deleteUser = async (id) => {
    await userApi.deleteUser(id)
    await fetchUsers()
  }

  // ---------- 指纹操作 ----------
  const fetchFingerprints = async () => {
    const res = await fingerprintApi.getAllFingerprints()
    fingerprints.value = res.data.data || []
  }

  const addFingerprint = async (userId) => {
    await fingerprintApi.addFingerprint(userId)
    await fetchFingerprints()
  }

  const deleteFingerprint = async (id) => {
    await fingerprintApi.deleteFingerprint(id)
    await fetchFingerprints()
  }

  // ---------- 卡片操作 ----------
  const fetchCards = async () => {
    const res = await cardApi.getCards()
    cards.value = res.data.data || []
  }

  const addCard = async (userId) => {
    await cardApi.addCard(userId)
    await fetchCards()
  }

  const deleteCard = async (id) => {
    await cardApi.deleteCard(id)
    await fetchCards()
  }

  // ---------- 物品操作 ----------
  const fetchGoods = async () => {
    const res = await goodsApi.getGoods()
    goods.value = res.data.data || []
  }

  const createGoods = async (data) => {
    await goodsApi.createGoods(data)
    await fetchGoods()
  }

  const updateGoods = async (id, data) => {
    await goodsApi.updateGoods(id, data)
    await fetchGoods()
  }

  const deleteGoods = async (id) => {
    await goodsApi.deleteGoods(id)
    await fetchGoods()
  }

  // ---------- 事件操作 ----------
  const fetchEvents = async (params = {}) => {
    const res = await eventApi.getEvents(params)
    events.value = res.data.data || []
  }

  const createEvent = async (data) => {
    await eventApi.createEvent(data)
    await fetchEvents()
  }

  return {
    users, fingerprints, cards, goods, events, loading,
    fetchUsers, createUser, updateUser, deleteUser,
    fetchFingerprints, addFingerprint, deleteFingerprint,
    fetchCards, addCard, deleteCard,
    fetchGoods, createGoods, updateGoods, deleteGoods,
    fetchEvents, createEvent
  }
})