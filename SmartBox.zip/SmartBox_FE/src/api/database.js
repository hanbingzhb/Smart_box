// src/api/database.js
import request from '@/utils/request'

// 用户管理
export const userApi = {
  getUsers: () => request.get('/api/v1/users'),
  createUser: (data) => request.post('/api/v1/users', data),
  updateUser: (id, data) => request.put(`/api/v1/users/${id}`, data),
  deleteUser: (id) => request.delete(`/api/v1/users/${id}`)
}

// 指纹管理
export const fingerprintApi = {
  addFingerprint: (userId) => request.post('/api/v1/fingerprints/enroll', { user_id: userId }),
  deleteFingerprint: (id) => request.delete(`/api/v1/fingerprints/${id}`),
  getAllFingerprints: () => request.get('/api/v1/fingerprints'),
}

// 卡片管理
export const cardApi = {
  getCards: () => request.get('/api/v1/cards'),
  addCard: (userId) => request.post('/api/v1/cards/enroll', { user_id: userId }),
  deleteCard: (id) => request.delete(`/api/v1/cards/${id}`),
  getAllCards: () => request.get('/api/v1/cards'),
  enrollCard: (userId) => request.post('/api/v1/cards/enroll', { user_id: userId })
}

// 物品管理
export const goodsApi = {
  getGoods: () => request.get('/api/v1/goods'),
  createGoods: (data) => request.post('/api/v1/goods', data),
  updateGoods: (id, data) => request.put(`/api/v1/goods/${id}`, data),
  deleteGoods: (id) => request.delete(`/api/v1/goods/${id}`)
}

// 事件记录
export const eventApi = {
  getEvents: (params) => request.get('/api/v1/events', { params }),
  createEvent: (data) => request.post('/api/v1/events', data)
}