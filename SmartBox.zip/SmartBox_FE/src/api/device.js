// src/api/device.js
import request from '@/utils/request'

export const deviceApi = {
  // LED控制
  controlLED(action) {
    const requestData = { 
      action: action
    }
    
    console.log('📤 发送LED控制请求:', JSON.stringify(requestData))
    return request.post('/api/device/led', requestData)
  },

  // 开门
  openDoor() {
    return request.post('/api/device/door/open', {
      pkg: 'cmd',
      cmd: 'open_door'
    })
  },

  // 恢复出厂设置
  resetFactory() {
    return request.post('/api/device/reset', {
      pkg: 'cmd', 
      cmd: 'reset_factory'
    })
  },

  // === 指纹管理 ===
  fingerEnroll(id) {
    const requestData = { 
      id: id 
    }
    
    console.log('📤 发送指纹录入请求:', JSON.stringify(requestData))
    return request.post('/api/device/fingerprint/enroll', requestData)
  },

  fingerDelete(id) {
    const requestData = { 
      id: id 
    }
    
    console.log('📤 发送指纹删除请求:', JSON.stringify(requestData))
    return request.post('/api/device/fingerprint/delete', requestData)
  },

  // === 卡片管理 ===
  cardEnroll(id) {
    const requestData = { 
      id: id 
    }
    
    return request.post('/api/device/card/enroll', requestData)
  },

  cardDelete(id) {
    const requestData = { 
      id: id 
    }
    
    return request.post('/api/device/card/delete', requestData)
  // },

  // // 获取柜门状态
  // getBoxStatus() {
  //   return request.get('/api/device/box_status')
  // },

  // // 长轮询：等待柜门状态变化
  // waitBoxStatus(timeout = 30) {
  //   return request.get('/api/device/box_status/wait', {
  //     timeout: (timeout + 5) * 1000  // 比后端超时稍长，防止前端先超时
  //   })
  }
}
