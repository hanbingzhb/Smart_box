<!-- src/views/History.vue -->
<template>
  <div class="history">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <i class="el-icon-document"></i>
            <span>操作历史</span>
          </div>
          <el-button type="primary" size="small" @click="refreshHistory" :loading="loading" class="refresh-btn">
            <i class="el-icon-refresh"></i>
            <span class="btn-text">刷新</span>
          </el-button>
        </div>
      </template>

      <el-timeline class="timeline-mobile">
        <el-timeline-item
          v-for="(item, index) in history"
          :key="index"
          :timestamp="formatTime(item.timestamp)"
          :type="getTimelineType(item.type)"
          placement="top"
        >
          <el-card shadow="hover" class="history-item">
            <div class="history-content">
              <div class="message">{{ item.message }}</div>
              <div class="type">
                <el-tag :type="getTagType(item.type)" size="small">
                  {{ getTypeText(item.type) }}
                </el-tag>
              </div>
            </div>
            <div v-if="item.data" class="data-preview">
              <el-button
                type="text"
                size="small"
                @click="showDetail(item)"
                class="detail-btn"
              >
                查看详情
              </el-button>
            </div>
          </el-card>
        </el-timeline-item>
      </el-timeline>

      <div v-if="history.length === 0" class="empty-state">
        <i class="el-icon-document-remove"></i>
        <p>暂无操作记录</p>
      </div>
    </el-card>

    <!-- 详情对话框 -->
    <el-dialog
      v-model="detailVisible"
      title="操作详情"
      width="90%"
      class="mobile-dialog"
    >
      <pre class="detail-content">{{ JSON.stringify(selectedItem?.data, null, 2) }}</pre>
      <template #footer>
        <el-button @click="detailVisible = false" class="dialog-btn">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useDeviceStore } from '@/stores/device'

const deviceStore = useDeviceStore()
const loading = ref(false)
const detailVisible = ref(false)
const selectedItem = ref(null)

const history = computed(() => deviceStore.history)

const formatTime = (timestamp) => {
  if (!timestamp) return '--'
  return new Date(timestamp).toLocaleString('zh-CN')
}

const getTimelineType = (type) => {
  const types = {
    command: 'primary',
    response: 'success',
    info: 'warning',
    system: 'info'
  }
  return types[type] || 'info'
}

const getTagType = (type) => {
  const types = {
    command: 'primary',
    response: 'success',
    info: 'warning',
    system: 'info'
  }
  return types[type] || 'info'
}

const getTypeText = (type) => {
  const texts = {
    command: '指令',
    response: '响应',
    info: '状态',
    system: '系统'
  }
  return texts[type] || '未知'
}

const refreshHistory = async () => {
  loading.value = true
  try {
    await deviceStore.fetchHistory()
  } catch (error) {
    console.error('刷新历史记录失败:', error)
  } finally {
    loading.value = false
  }
}

const showDetail = (item) => {
  selectedItem.value = item
  detailVisible.value = true
}

onMounted(() => {
  refreshHistory()
})
</script>

<style scoped>
.history {
  max-width: 800px;
  margin: 0 auto;
  padding: 0 8px;
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-weight: bold;
  flex-wrap: wrap;
  gap: 8px;
}

.header-left {
  display: flex;
  align-items: center;
}

.card-header i {
  margin-right: 8px;
  font-size: 16px;
}

.refresh-btn {
  min-width: auto;
}

.btn-text {
  margin-left: 4px;
}

.history-item {
  margin: 5px 0;
}

.history-content {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  flex-direction: column;
  gap: 8px;
}

.message {
  flex: 1;
  margin-right: 0;
  word-break: break-word;
  line-height: 1.4;
}

.data-preview {
  margin-top: 10px;
  width: 100%;
  text-align: center;
}

.detail-btn {
  padding: 8px 16px;
  font-size: 14px;
}

.empty-state {
  text-align: center;
  padding: 40px 20px;
  color: #909399;
}

.empty-state i {
  font-size: 48px;
  margin-bottom: 16px;
}

.detail-content {
  background: #f5f7fa;
  padding: 16px;
  border-radius: 4px;
  max-height: 60vh;
  overflow: auto;
  font-family: 'Courier New', monospace;
  font-size: 12px;
  line-height: 1.3;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .history {
    padding: 0 4px;
  }
  
  .timeline-mobile {
    padding-left: 8px;
  }
  
  .history-content {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .message {
    margin-right: 0;
    margin-bottom: 8px;
  }
  
  .refresh-btn .btn-text {
    display: inline;
  }
  
  .card-header {
    font-size: 14px;
  }
}

@media (max-width: 480px) {
  .history-item {
    margin: 3px 0;
  }
  
  .detail-content {
    font-size: 11px;
    padding: 12px;
  }
  
  .mobile-dialog :deep(.el-dialog) {
    margin: 20px auto;
    max-width: 95%;
  }
  
  .dialog-btn {
    width: 100%;
    padding: 12px;
  }
}

@media (min-width: 769px) {
  .history-content {
    flex-direction: row;
    align-items: center;
  }
  
  .message {
    margin-right: 15px;
  }
}
</style>