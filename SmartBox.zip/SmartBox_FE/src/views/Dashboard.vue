<!-- src/views/Dashboard.vue -->
<template>
  <div class="dashboard">
    <el-row :gutter="16" class="mobile-row">
      <!-- 设备状态卡片 -->
      <el-col :xs="24" :sm="24" :md="8" :lg="8">
        <el-card class="status-card mobile-card">
          <template #header>
            <div class="card-header">
              <i class="el-icon-monitor"></i>
              <span>设备状态</span>
            </div>
          </template>
          <div class="status-content">
            <div class="status-item">
              <span class="label">连接状态:</span>
              <el-tag :type="deviceStatus.online ? 'success' : 'danger'" size="small" class="status-tag">
                {{ !deviceStatus.online ? '在线' : '离线' }}
              </el-tag>
            </div>
            <div class="status-item">
              <span class="label">柜门状态:</span>
              <el-tag :type="deviceStatus.box_open ? 'success' : 'info'" size="small" class="status-tag">
                {{ deviceStatus.box_open ? '已打开' : '已关闭' }}
              </el-tag>
            </div>
            <div class="status-item">
              <span class="label">最后更新:</span>
              <span class="value">2026/4/17 14:21:31</span>
            </div>
          </div>
        </el-card>
      </el-col>

      <!-- 快速操作 -->
      <el-col :xs="24" :sm="24" :md="16" :lg="16">
        <el-card class="quick-actions-card mobile-card">
          <template #header>
            <div class="card-header">
              <i class="el-icon-s-operation"></i>
              <span>快速操作</span>
            </div>
          </template>
          <div class="actions-grid">
            <el-button 
              type="primary" 
              @click="openDoor"
              :loading="loading"
              class="action-btn"
            >
              <i class="el-icon-unlock"></i>
              <span class="btn-text">远程开门</span>
            </el-button>
            <el-button 
              type="danger" 
              @click="resetFactory"
              :loading="loading"
              class="action-btn"
            >
              <i class="el-icon-refresh"></i>
              <span class="btn-text">恢复出厂</span>
            </el-button>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 功能模块 -->
    <el-row :gutter="16" class="modules-row mobile-row">
      <el-col :xs="12" :sm="12" :md="8" :lg="8">
        <el-card class="module-card mobile-module-card" @click="$router.push('/finger')">
          <div class="module-content">
            <i class="el-icon-fingerprint module-icon"></i>
            <h3>指纹管理</h3>
            <p>录入、删除指纹信息</p>
          </div>
        </el-card>
      </el-col>
      
      <el-col :xs="12" :sm="12" :md="8" :lg="8">
        <el-card class="module-card mobile-module-card" @click="$router.push('/card')">
          <div class="module-content">
            <i class="el-icon-credit-card module-icon"></i>
            <h3>卡片管理</h3>
            <p>管理用户卡片</p>
          </div>
        </el-card>
      </el-col>
      
      <el-col :xs="12" :sm="12" :md="8" :lg="8">
        <el-card class="module-card mobile-module-card" @click="$router.push('/history')">
          <div class="module-content">
            <i class="el-icon-document module-icon"></i>
            <h3>操作历史</h3>
            <p>查看操作记录</p>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useDeviceStore } from '@/stores/device'
import { deviceApi } from '@/api/device'

const deviceStore = useDeviceStore()
const deviceStatus = computed(() => deviceStore.status)
const loading = computed(() => deviceStore.loading)

const formatTime = (timestamp) => {
  if (!timestamp) return '--'
  return new Date(timestamp).toLocaleString('zh-CN')
}

const openDoor = async () => {
  try {
    await ElMessageBox.confirm('确定要远程开锁吗？', '提示', {
      type: 'warning',
      customClass: 'mobile-message-box'
    })
    await deviceApi.openDoor()
    ElMessage.success('开锁指令已发送')
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('开锁指令发送失败')
    }
  }
}

const controlLED = async (action) => {
  try {
    console.log('开始发送LED控制指令:', action)
    await deviceApi.controlLED(action)
    ElMessage.success(`LED${action === 'on' ? '开启' : '关闭'}指令已发送`)
  } catch (error) {
    console.error('LED控制指令发送失败详情:', error)
    ElMessage.error(`LED控制指令发送失败: ${error.message}`)
  }
}

const resetFactory = async () => {
  try {
    await ElMessageBox.confirm(
      '此操作将恢复出厂设置，清除所有数据，确定继续吗？',
      '警告',
      {
        type: 'error',
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        customClass: 'mobile-message-box'
      }
    )
    await deviceApi.resetFactory()
    ElMessage.success('恢复出厂设置指令已发送')
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('恢复出厂设置指令发送失败')
    }
  }
}
</script>

<style scoped>
.dashboard {
  padding: 0 8px;
}

.mobile-row {
  margin: 0 !important;
}

.mobile-card {
  margin-bottom: 16px;
  height: auto;
  min-height: 180px;
}

.status-card, .quick-actions-card {
  height: auto;
}

.card-header {
  display: flex;
  align-items: center;
  font-weight: bold;
  padding: 14px 16px;
}

.card-header i {
  margin-right: 8px;
  font-size: 16px;
}

.status-content {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 8px 4px;
}

.status-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
}

.status-item .label {
  color: #606266;
  font-size: 14px;
  margin-right: 8px;
}

.status-item .value {
  color: #303133;
  font-weight: 500;
  font-size: 14px;
  text-align: right;
  flex: 1;
  min-width: 120px;
}

.status-tag {
  min-width: 60px;
  text-align: center;
}

.actions-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  height: 100%;
  padding: 8px 4px;
}

.action-btn {
  height: 70px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 12px 8px;
}

.action-btn i {
  font-size: 20px;
  margin-bottom: 6px;
}

.btn-text {
  font-size: 13px;
  font-weight: 500;
}

.modules-row {
  margin-top: 16px;
}

.mobile-module-card {
  cursor: pointer;
  transition: all 0.3s ease;
  height: 120px;
  margin-bottom: 0;
}

.mobile-module-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.module-content {
  text-align: center;
  padding: 16px 8px;
}

.module-icon {
  font-size: 28px;
  color: #409EFF;
  margin-bottom: 8px;
}

.module-content h3 {
  margin: 0 0 6px 0;
  color: #303133;
  font-size: 14px;
  font-weight: 600;
}

.module-content p {
  margin: 0;
  color: #909399;
  font-size: 12px;
  line-height: 1.3;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .dashboard {
    padding: 0 4px;
  }
  
  .mobile-card {
    margin-bottom: 12px;
    min-height: 160px;
  }
  
  .card-header {
    padding: 12px 14px;
    font-size: 15px;
  }
  
  .status-content {
    gap: 12px;
    padding: 6px 2px;
  }
  
  .status-item {
    flex-direction: row;
  }
  
  .status-item .label {
    font-size: 13px;
    min-width: 80px;
  }
  
  .status-item .value {
    font-size: 13px;
    min-width: 100px;
  }
  
  .actions-grid {
    grid-template-columns: 1fr 1fr;
    gap: 10px;
  }
  
  .action-btn {
    height: 65px;
    padding: 10px 6px;
  }
  
  .action-btn i {
    font-size: 18px;
    margin-bottom: 4px;
  }
  
  .btn-text {
    font-size: 12px;
  }
  
  .modules-row {
    margin-top: 12px;
  }
  
  .mobile-module-card {
    height: 100px;
  }
  
  .module-content {
    padding: 12px 6px;
  }
  
  .module-icon {
    font-size: 24px;
    margin-bottom: 6px;
  }
  
  .module-content h3 {
    font-size: 13px;
    margin-bottom: 4px;
  }
  
  .module-content p {
    font-size: 11px;
  }
}

@media (max-width: 480px) {
  .dashboard {
    padding: 0 2px;
  }
  
  .mobile-card {
    margin-bottom: 8px;
    min-height: 150px;
  }
  
  .card-header {
    padding: 10px 12px;
    font-size: 14px;
  }
  
  .status-content {
    gap: 10px;
  }
  
  .status-item .label {
    font-size: 12px;
    min-width: 70px;
  }
  
  .status-item .value {
    font-size: 12px;
  }
  
  .actions-grid {
    grid-template-columns: 1fr;
    gap: 8px;
  }
  
  .action-btn {
    height: 60px;
    flex-direction: row;
    justify-content: flex-start;
    padding: 12px;
  }
  
  .action-btn i {
    margin-bottom: 0;
    margin-right: 8px;
    font-size: 16px;
  }
  
  .btn-text {
    font-size: 14px;
  }
  
  .mobile-module-card {
    height: 90px;
  }
  
  .module-content {
    padding: 10px 4px;
  }
  
  .module-icon {
    font-size: 20px;
  }
  
  .module-content h3 {
    font-size: 12px;
  }
  
  .module-content p {
    font-size: 10px;
  }
}

/* 大屏设备适配 */
@media (min-width: 1200px) {
  .status-card, .quick-actions-card {
    min-height: 200px;
  }
  
  .action-btn {
    height: 80px;
  }
  
  .mobile-module-card {
    height: 140px;
  }
  
  .module-content {
    padding: 24px 12px;
  }
  
  .module-icon {
    font-size: 32px;
  }
  
  .module-content h3 {
    font-size: 16px;
  }
  
  .module-content p {
    font-size: 14px;
  }
}

/* 触摸设备优化 */
@media (hover: none) and (pointer: coarse) {
  .mobile-module-card:active {
    transform: scale(0.98);
    background-color: #f5f7fa;
  }
  
  .action-btn:active {
    transform: scale(0.98);
  }
}
</style>
