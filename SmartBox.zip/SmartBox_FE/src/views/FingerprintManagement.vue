<template>
  <div class="page-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span><el-icon><Pointer /></el-icon> 指纹管理</span>
          <el-button type="primary" @click="openAddDialog">
            <el-icon><Plus /></el-icon> 添加指纹
          </el-button>
        </div>
      </template>

      <!-- 指纹列表表格 -->
      <el-table :data="fingerprints" v-loading="loading" stripe>
        <el-table-column prop="FingerprintID" label="指纹ID" width="120" />
        <el-table-column prop="UserID" label="用户ID" width="120" />
        <el-table-column prop="User.Name" label="用户姓名" />
        <el-table-column label="操作" width="150">
          <template #default="{ row }">
            <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 添加指纹对话框 -->
    <el-dialog v-model="dialogVisible" title="添加指纹" width="400px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="选择用户" prop="UserID">
          <el-select v-model="form.UserID" placeholder="请选择用户" filterable>
            <el-option
              v-for="user in users"
              :key="user.UserID"
              :label="`${user.Name} (ID:${user.UserID})`"
              :value="user.UserID"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Pointer, Plus } from '@element-plus/icons-vue'
import { useDatabaseStore } from '@/stores/database'

const store = useDatabaseStore()
const fingerprints = computed(() => store.fingerprints)
const users = computed(() => store.users)
const loading = computed(() => store.loading)

const dialogVisible = ref(false)
const formRef = ref()
const form = ref({ UserID: null })

const rules = {
  UserID: [{ required: true, message: '请选择用户', trigger: 'change' }]
}

const openAddDialog = () => {
  form.value = { UserID: null }
  dialogVisible.value = true
}

const submitForm = async () => {
  await formRef.value.validate()
  
  const selectedUser = users.value.find(u => u.UserID === form.value.UserID)
  const userName = selectedUser ? selectedUser.Name : '未知用户'
  
  try {
    await ElMessageBox.confirm(
      `确定为用户 "${userName}" (ID:${form.value.UserID}) 添加指纹吗？`,
      '确认添加',
      { type: 'warning' }
    )
    
    await store.addFingerprint(form.value.UserID)
    ElMessage.success('指纹添加成功')
    dialogVisible.value = false
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('添加失败')
    }
  }
}

const handleDelete = async (row) => {
  try {
    await ElMessageBox.confirm(
      `确定删除指纹 ID: ${row.FingerprintID} 吗？`,
      '警告',
      { type: 'warning' }
    )
    await store.deleteFingerprint(row.FingerprintID)
    ElMessage.success('删除成功')
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除失败')
    }
  }
}

onMounted(async () => {
  await store.fetchUsers()
  await store.fetchFingerprints()
})
</script>

<style scoped>
.page-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style>