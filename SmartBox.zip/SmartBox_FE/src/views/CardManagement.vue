<!-- src/views/CardManagement.vue -->
<template>
  <div class="page-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span><el-icon><CreditCard /></el-icon> 卡片管理</span>
          <el-button type="primary" @click="openAddDialog">
            <el-icon><Plus /></el-icon> 添加卡片
          </el-button>
        </div>
      </template>

      <!-- 卡片列表表格 -->
      <el-table :data="cards" v-loading="loading" stripe>
        <el-table-column prop="CardID" label="卡片ID" width="120" />
        <!-- 修改为 UserID -->
        <el-table-column prop="UserID" label="用户ID" width="120" />
        <!-- 关联用户姓名，假设后端返回了 user 对象且包含 Name 字段 -->
        <el-table-column prop="User.Name" label="用户姓名" />
        <el-table-column label="操作" width="150">
          <template #default="{ row }">
            <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 添加卡片对话框 -->
    <el-dialog v-model="dialogVisible" title="添加卡片" width="400px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="选择用户" prop="UserID">
          <el-select v-model="form.UserID" placeholder="请选择用户" filterable>
            <el-option
              v-for="user in users"
              :key="user.UserID"
              :label="`${user.Name} (ID:${user.UserID})`"
              :value="user.UserID"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { CreditCard, Plus } from '@element-plus/icons-vue'
import { useDatabaseStore } from '@/stores/database'

const store = useDatabaseStore()
const cards = computed(() => store.cards)
const users = computed(() => store.users)
const loading = computed(() => store.loading)

const dialogVisible = ref(false)
const formRef = ref()
// 修改为 UserID
const form = ref({ UserID: null })

const rules = {
  UserID: [{ required: true, message: '请选择用户', trigger: 'change' }]
}

const openAddDialog = () => {
  form.value = { UserID: null }
  dialogVisible.value = true
}

const submitForm = async () => {
  await formRef.value.validate()
  try {
    // 传递 UserID
    await store.addCard(form.value.UserID)
    ElMessage.success('卡片添加成功')
    dialogVisible.value = false
  } catch (error) {
    ElMessage.error('添加失败')
  }
}

const handleDelete = async (row) => {
  await ElMessageBox.confirm(
    `确定删除卡片 ID: ${row.CardID} 吗？`,
    '警告',
    { type: 'warning' }
  )
  try {
    await store.deleteCard(row.CardID)
    ElMessage.success('删除成功')
  } catch (error) {
    ElMessage.error('删除失败')
  }
}

onMounted(async () => {
  await store.fetchUsers()
  await store.fetchCards()
})
</script>

<style scoped>
.page-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style>