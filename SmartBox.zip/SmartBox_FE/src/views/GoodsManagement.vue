<!-- src/views/GoodsManagement.vue -->
<template>
  <div class="page-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span><el-icon><Goods /></el-icon> 物品管理</span>
          <el-button type="primary" @click="openAddDialog">
            <el-icon><Plus /></el-icon> 新增物品
          </el-button>
        </div>
      </template>

      <el-table :data="goods" v-loading="loading" stripe>
        <el-table-column prop="GoodsID" label="物品ID" width="100" />
        <el-table-column prop="GoodsName" label="物品名称" />
        <el-table-column prop="CardID" label="卡片ID" width="120" />
        <el-table-column prop="IsInside" label="存放状态" width="120">
          <template #default="{ row }">
            <el-tag :type="row.IsInside ? 'success' : 'info'">
              {{ row.IsInside ? '在柜中' : '已取出' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200">
          <template #default="{ row }">
            <el-button type="primary" link @click="openEditDialog(row)">编辑</el-button>
            <el-button type="danger" link @click="handleDelete(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/编辑物品对话框 -->
    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="物品名称" prop="GoodsName">
          <el-input v-model="form.GoodsName" placeholder="请输入物品名称" />
        </el-form-item>
        <el-form-item label="卡片ID" prop="CardID">
          <el-input-number v-model="form.CardID" :min="1" controls-position="right" style="width: 100%" />
        </el-form-item>
        <el-form-item label="存放状态" prop="IsInside">
          <el-switch v-model="form.IsInside" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Goods, Plus } from '@element-plus/icons-vue'
import { useDatabaseStore } from '@/stores/database'

const store = useDatabaseStore()
const goods = computed(() => store.goods)
const loading = computed(() => store.loading)

const dialogVisible = ref(false)
const isEdit = ref(false)
const editingId = ref(null)
const formRef = ref()
const form = ref({
  GoodsName: '',
  CardID: 1,
  IsInside: true
})

const rules = {
  GoodsName: [{ required: true, message: '请输入物品名称', trigger: 'blur' }],
  CardID: [{ required: true, message: '请输入卡片ID', trigger: 'blur' }]
}

const dialogTitle = computed(() => isEdit.value ? '编辑物品' : '新增物品')

const openAddDialog = () => {
  isEdit.value = false
  editingId.value = null
  form.value = { GoodsName: '', CardID: 1, IsInside: true }
  dialogVisible.value = true
}

const openEditDialog = (row) => {
  isEdit.value = true
  editingId.value = row.GoodsID
  form.value = {
    GoodsName: row.GoodsName,
    CardID: row.CardID,
    IsInside: row.IsInside
  }
  dialogVisible.value = true
}

const submitForm = async () => {
  await formRef.value.validate()
  try {
    if (isEdit.value) {
      await store.updateGoods(editingId.value, form.value)
      ElMessage.success('更新成功')
    } else {
      await store.createGoods(form.value)
      ElMessage.success('创建成功')
    }
    dialogVisible.value = false
  } catch (error) {
    ElMessage.error('操作失败')
  }
}

const handleDelete = async (row) => {
  await ElMessageBox.confirm(`确定删除物品 "${row.GoodsName}" 吗？`, '警告', { type: 'warning' })
  try {
    await store.deleteGoods(row.GoodsID)
    ElMessage.success('删除成功')
  } catch (error) {
    ElMessage.error('删除失败')
  }
}

onMounted(() => {
  store.fetchGoods()
})
</script>