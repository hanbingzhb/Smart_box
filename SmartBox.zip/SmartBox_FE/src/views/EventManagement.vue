<template>
  <div class="page-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span><el-icon><Document /></el-icon> 存取记录</span>
          <el-button EventType="primary" @click="openAddDialog">
            <el-icon><Plus /></el-icon> 记录存取
          </el-button>
        </div>
      </template>

      <!-- 筛选栏 -->
      <el-form :inline="true" :model="filterForm" class="filter-form">
        <el-form-item label="用户ID">
          <el-input v-model="filterForm.UserId" placeholder="用户ID" clearable />
        </el-form-item>
        <el-form-item label="物品ID">
          <el-input v-model="filterForm.GoodsId" placeholder="物品ID" clearable />
        </el-form-item>
        <el-form-item label="类型">
          <el-select v-model="filterForm.EventType" placeholder="全部" clearable>
            <el-option label="存入" value="STORE" />
            <el-option label="取出" value="RETRIEVE" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button EventType="primary" @click="handleFilter">查询</el-button>
          <el-button @click="resetFilter">重置</el-button>
        </el-form-item>
      </el-form>

      <el-table :data="events" v-loading="loading" stripe>
        <el-table-column prop="EventID" label="事件ID" width="80" />
        <el-table-column prop="UserID" label="用户ID" width="80" />
        <el-table-column prop="GoodsID" label="物品ID" width="80" />
        <el-table-column prop="EventType" label="类型" width="100">
          <template #default="{ row }">
            <el-tag v-if="row.EventType === 'DOOR_OPEN'" type="primary">
              开门
            </el-tag>
            <el-tag v-else-if="row.EventType === 'STORE' && row.GoodsID === 0" type="info">
              开门 <span style="font-size: 12px">(无物品)</span>
            </el-tag>
            <el-tag v-else-if="row.EventType === 'STORE'" type="success">
              存入
            </el-tag>
            <el-tag v-else-if="row.EventType === 'RETRIEVE'" type="warning">
              取出
            </el-tag>
            <el-tag v-else type="info">
              {{ row.EventType }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="AccessTime" label="时间" width="180" />
        <el-table-column prop="OperatorRemarks" label="备注" />
      </el-table>
    </el-card>

    <!-- 记录存取对话框 -->
    <el-dialog v-model="dialogVisible" title="记录存取事件" width="500px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="用户ID" prop="UserId">
          <el-input-number v-model="form.UserId" :min="1" controls-position="right" style="width: 100%" />
        </el-form-item>
        <el-form-item label="物品ID" prop="GoodsId">
          <el-input-number v-model="form.GoodsId" :min="1" controls-position="right" style="width: 100%" />
        </el-form-item>
        <el-form-item label="操作类型" prop="event_EventType">
          <el-radio-group v-model="form.EventType">
            <el-radio label="STORE">存入</el-radio>
            <el-radio label="RETRIEVE">取出</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="时间" prop="AccessTime">
          <el-date-picker
            v-model="form.AccessTime"
            type="datetime"
            placeholder="选择日期时间"
            value-format="YYYY-MM-DD HH:mm:ss"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.OperatorRemarks" type="textarea" :rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { Document, Plus } from '@element-plus/icons-vue'
import { useDatabaseStore } from '@/stores/database'

const store = useDatabaseStore()
const events = computed(() => store.events)
const loading = computed(() => store.loading)

const filterForm = reactive({
  UserId: '',
  GoodsId: '',
  EventType: ''
})

const dialogVisible = ref(false)
const formRef = ref()
const form = reactive({
  UserId: null,
  GoodsId: null,
  EventType: 'STORE',
  AccessTime: '',
  OperatorRemarks: ''
})

const rules = {
  UserId: [{ required: true, message: '请输入用户ID', trigger: 'blur' }],
  GoodsId: [{ required: true, message: '请输入物品ID', trigger: 'blur' }],
  EventType: [{ required: true, message: '请选择类型', trigger: 'change' }],
  AccessTime: [{ required: true, message: '请选择时间', trigger: 'change' }]
}

const handleFilter = () => {
  const params = {}
  if (filterForm.UserId) params.UserId = filterForm.UserId
  if (filterForm.GoodsId) params.GoodsId = filterForm.GoodsId
  if (filterForm.EventType) params.EventType = filterForm.EventType
  store.fetchEvents(params)
}

const resetFilter = () => {
  filterForm.UserId = ''
  filterForm.GoodsId = ''
  filterForm.EventType = ''
  store.fetchEvents()
}

const openAddDialog = () => {
  // 默认时间为当前
  const now = new Date()
  form.AccessTime = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`
  form.UserId = null
  form.GoodsId = null
  form.EventType = 'STORE'
  form.OperatorRemarks = ''
  dialogVisible.value = true
}

const submitForm = async () => {
  await formRef.value.validate()
  try {
    await store.createEvent(form)
    ElMessage.success('记录成功')
    dialogVisible.value = false
  } catch (error) {
    ElMessage.error('记录失败')
  }
}

onMounted(() => {
  store.fetchEvents()
})
</script>

<style scoped>
.page-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.filter-form {
  margin-bottom: 20px;
}
</style>