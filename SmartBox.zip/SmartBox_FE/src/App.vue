<!-- src/App.vue -->
<template>
  <div id="app">
    <el-container class="layout-container">
      <!-- 侧边栏 -->
      <el-aside width="250px" class="sidebar">
        <div class="logo">
          <i class="el-icon-lock"></i>
          <span>智能储物柜控制系统</span>
        </div>
        <el-menu
          :default-active="currentRoute"
          router
          class="sidebar-menu"
          background-color="#304156"
          text-color="#bfcbd9"
          active-text-color="#409EFF"
        >
          <el-menu-item index="/">
    <el-icon><Monitor /></el-icon>
    <span>控制面板</span>
    </el-menu-item>
      <el-menu-item index="/users">
        <el-icon><User /></el-icon>
        <span>用户管理</span>
      </el-menu-item>
      <el-menu-item index="/fingerprints">
        <el-icon><Pointer /></el-icon>
        <span>指纹管理</span>
      </el-menu-item>
      <el-menu-item index="/cards">
        <el-icon><CreditCard /></el-icon>
        <span>卡片管理</span>
      </el-menu-item>
      <el-menu-item index="/goods">
        <el-icon><Goods /></el-icon>
        <span>物品管理</span>
      </el-menu-item>
      <el-menu-item index="/events">
        <el-icon><Document /></el-icon>
        <span>存取记录</span>
    </el-menu-item>
</el-menu>
      </el-aside>

      <!-- 主内容区 -->
      <el-container>
        <el-header class="header">
          <div class="header-left">
            <h2>{{ pageTitle }}</h2>
          </div>
          <div class="header-right">
            <el-tag :type="deviceStatus.online ? 'success' : 'danger'">
              {{ deviceStatus.online ? '设备在线' : '设备离线' }}
            </el-tag>
            <span class="update-time">
              最后更新: 2026/4/17 14:26:28
            </span>
          </div>
        </el-header>

        <el-main class="main-content">
          <router-view />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import { useDeviceStore } from '@/stores/device'
import { Pointer } from '@element-plus/icons-vue'

const route = useRoute()
const deviceStore = useDeviceStore()

const currentRoute = computed(() => route.path)

const pageTitle = computed(() => {
  const titles = {
    '/': '控制面板',
    '/users': '用户管理',
    '/fingerprints': '指纹管理',
    '/cards': '卡片管理',
    '/goods': '物品管理',
    '/events': '存取记录'
  }
  return titles[route.path] || '智能储物柜控制系统'
})

const deviceStatus = computed(() => deviceStore.status)

const formatTime = (timestamp) => {
  if (!timestamp) return '--'
  return new Date(timestamp).toLocaleString('zh-CN')
}

// 定时获取设备状态
let intervalId

onMounted(() => {
  deviceStore.fetchStatus()
  intervalId = setInterval(() => {
    deviceStore.fetchStatus()
  }, 5000)
  // deviceStore.fetchInitialStatus()  // 获取初始状态
  // deviceStore.startLongPolling()    // 启动长轮询
})

onUnmounted(() => {
  // deviceStore.stopLongPolling()     // 停止长轮询
  if (intervalId) {
    clearInterval(intervalId)
  }
})
</script>

<style scoped>
.layout-container {
  height: 100vh;
}

.sidebar {
  background-color: #304156;
  color: white;
}

.logo {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  font-weight: bold;
  border-bottom: 1px solid #263445;
}

.logo i {
  margin-right: 10px;
  font-size: 24px;
}

.sidebar-menu {
  border: none;
}

.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #fff;
  border-bottom: 1px solid #e6e6e6;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
}

.header-left h2 {
  margin: 0;
  color: #303133;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 15px;
}

.update-time {
  color: #909399;
  font-size: 14px;
}

.main-content {
  background-color: #f5f7fa;
  padding: 20px;
}
</style>
