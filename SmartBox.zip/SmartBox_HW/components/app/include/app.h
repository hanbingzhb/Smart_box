/**
 * *****************************************************************************
 * @file app.h
 * @brief 智能储物柜主应用程序
 * @version 1.0
 * @date 2025-11-10
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * *****************************************************************************
 */

#ifndef __APP_H__
#define __APP_H__

#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief 初始化智能储物柜应用程序
 * @return esp_err_t 错误代码
 */
esp_err_t app_init(void);

/**
 * @brief 停止智能储物柜应用程序
 * @return esp_err_t 错误代码
 */
esp_err_t app_stop(void);

// /**
//  * @brief 恢复出厂设置
//  * @return esp_err_t 错误代码
//  */
// esp_err_t app_factory_reset(void);

#ifdef __cplusplus
}
#endif

#endif /* __APP_H__ */