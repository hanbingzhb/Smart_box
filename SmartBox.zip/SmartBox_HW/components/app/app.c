/**
 * *****************************************************************************
 * @file app.c
 * @brief 智能储物柜主应用程序实现
 * @version 1.0
 * @date 2025-11-10
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * *****************************************************************************
 */

#include "app.h"
#include "box_sensor.h"
#include "OLED.h"
#include "zw111.h"
#include "rc522_driver.h"
#include "OpenTheDoor.h"
#include "wifi_config.h"
#include "web_server.h"
#include "smartlock_mqtt.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "cJSON.h"
#include <string.h>
#include <sys/time.h>

static const char *TAG = "SmartLock_App";

// 应用状态枚举
typedef enum {
    APP_STATE_IDLE = 0,              // 空闲状态，等待验证
    APP_STATE_VERIFYING,             // 验证中
    APP_STATE_ENROLLING_FINGER,      // 录入指纹中
    APP_STATE_ENROLLING_CARD,        // 录入卡片中
    APP_STATE_PASSWORD_INPUT,        // 密码输入中
    APP_STATE_SETTING,               // 设置中
    APP_STATE_RESETTING,             // 重置中
    APP_STATE_WIFI_CONFIG,           // WiFi配置中
    APP_STATE_COOL_DOWN,             // 冷却时间（特殊功能可用）
    APP_STATE_CONFIRM_RESET,         // 确认恢复出厂设置
    APP_STATE_CONFIRM_WIFI_RESET,    // 确认删除WiFi
} app_state_t;

// 验证方法枚举
typedef enum {
    VERIFY_METHOD_NONE = 0,
    VERIFY_METHOD_FINGER,
    VERIFY_METHOD_CARD, 
    VERIFY_METHOD_PASSWORD,
    VERIFY_METHOD_TEMP_PASSWORD,
} verify_method_t;

// 应用上下文结构体
typedef struct {
    app_state_t state;                   // 当前状态
    app_state_t prev_state;              // 前一个状态
    verify_method_t last_method;         // 最后使用的验证方法
    uint16_t last_user_id;               // 最后验证的用户ID
    TaskHandle_t main_task_handle;       // 主任务句柄
    QueueHandle_t event_queue;           // 事件队列
    SemaphoreHandle_t state_mutex;       // 状态互斥锁
    bool initialized;                    // 初始化标志
    bool mqtt_connected;                 // MQTT连接状态
    char device_id[32];                  // 设备ID
    uint32_t cool_down_end_time;         // 冷却结束时间
    char password_input[9];              // 密码输入缓冲区
    uint8_t password_length;             // 密码输入长度
    bool show_password_stars;            // 是否显示密码星号
} app_context_t;

static app_context_t g_app = {0};

// MQTT配置
static mqtt_config_t g_mqtt_config = {
    .uri = "mqtt://post-cn-kds4q4s1r01.mqtt.aliyuncs.com",
    .client_id = "GID_Demo@@@demo2",
    .username = "DeviceCredential|DC.ZHoGPwgETMSYtbqRaDh5OA|post-cn-kds4q4s1r01",
    .password = "6TeRzfbzLlhww4beyrMI2RPCeoI=",
    .keepalive = 60,
    .use_ssl = false,
};

// ========== 柜门状态上报重试机制 ==========
#define BOX_STATUS_RETRY_MAX        5
#define BOX_STATUS_RETRY_INTERVAL   2000

static bool g_box_status_ack_received = false;
static uint8_t g_box_status_retry_count = 0;
static TimerHandle_t g_box_status_timer = NULL;

// ========== 内部函数声明 ==========
static void app_main_task(void *arg);
static void app_change_state(app_state_t new_state);
static void app_handle_verify_success(verify_method_t method, uint16_t user_id);
static void app_handle_verify_failed(verify_method_t method);
static void app_handle_special_function(uint8_t function_id);
static void app_perform_factory_reset(void);
static void app_delete_wifi_config(void);

// ========== 柜门状态相关函数声明 ==========
static void on_box_closed(void);
static void send_box_status_json(bool is_open);
static void box_status_retry_timer_cb(TimerHandle_t xTimer);
static void send_box_status_with_retry(bool is_open);
void box_status_ack_received(void);   // 非静态，供 mqtt 回调使用

// ========== 驱动回调函数 ==========

/**
 * @brief 指纹验证回调
 */
static void zw111_verify_callback(uint16_t user_id, uint16_t score, esp_err_t result)
{
    if (result == ESP_OK) {
        ESP_LOGI(TAG, "指纹验证成功，用户ID: %u, 分数: %u", user_id, score);
        app_handle_verify_success(VERIFY_METHOD_FINGER, user_id);
    } else {
        ESP_LOGI(TAG, "指纹验证失败");
        app_handle_verify_failed(VERIFY_METHOD_FINGER);
    }
}

// /**
//  * @brief 指纹录入回调
//  */
static void zw111_enroll_callback(uint16_t user_id, uint16_t score, esp_err_t result)
{
    if (result == ESP_OK) {
        ESP_LOGI(TAG, "指纹录入成功，用户ID: %u", user_id);
        OLED_Clear();
        OLED_ShowPhrase(2, 3, PHRASE_ENROLL_SUCCESS);
        mqtt_send_ack("finger_enroll", "success", NULL);
    } else {
        ESP_LOGE(TAG, "指纹录入失败");
        OLED_Clear();
        OLED_ShowPhrase(2, 3, PHRASE_ENROLL_FAILED);
        mqtt_send_ack("finger_enroll", "failed", "ENROLL_FAILED");
    }
    
    buzzer_success();
    vTaskDelay(pdMS_TO_TICKS(2000));
    app_change_state(APP_STATE_IDLE);
    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
}

// /**
//  * @brief 指纹录入进度回调
//  */
static void zw111_enroll_progress_callback(uint8_t current_step, uint8_t total_steps, const char* status)
{
    OLED_ShowPhrase(1, 3, PHRASE_ENROLLING);
    
    char progress[32];
    snprintf(progress, sizeof(progress), "%d/%d", current_step, total_steps);
    OLED_ShowString(3, 7, progress);
}

/**
 * @brief RC522事件回调
 */
static void rc522_event_callback(rc522_event_t *event, void *user_data)
{
    switch (event->type) {
        case RC522_EVENT_CARD_VERIFIED:
            ESP_LOGI(TAG, "卡片验证成功，ID: %u", event->id);
            app_handle_verify_success(VERIFY_METHOD_CARD, event->id);
            break;
            
        case RC522_EVENT_CARD_ADDED:
            ESP_LOGI(TAG, "卡片录入成功，ID: %u", event->id);
            OLED_Clear();
            OLED_ShowPhrase(2, 3, PHRASE_ENROLL_SUCCESS);
            mqtt_send_ack("card_enroll", "success", NULL);
            buzzer_success();
            vTaskDelay(pdMS_TO_TICKS(2000));
            app_change_state(APP_STATE_IDLE);
            OLED_Clear();
            OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
            break;
            
        case RC522_EVENT_CARD_REJECTED:
            ESP_LOGI(TAG, "未注册卡片");
            app_handle_verify_failed(VERIFY_METHOD_CARD);
            break;
            
        case RC522_EVENT_ENROLL_TIMEOUT:  // 新增超时处理
            ESP_LOGI(TAG, "卡片录入超时");
            OLED_Clear();
            OLED_ShowString(2, 3, "TIME OUT");
            mqtt_send_ack("card_enroll", "failed", "ENROLL_TIMEOUT");
            buzzer_failure();
            vTaskDelay(pdMS_TO_TICKS(1000));
            app_change_state(APP_STATE_IDLE);
            OLED_Clear();
            OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
            break;
            
        default:
            break;
    }
}

/**
 * @brief MQTT命令回调
 */
static esp_err_t mqtt_command_callback(const char* cmd, cJSON* params)
{
    ESP_LOGI(TAG, "处理MQTT命令: %s", cmd);
    
    if (strcmp(cmd, "finger_enroll") == 0) {
        cJSON *id_json = cJSON_GetObjectItem(params, "id");
        if (!id_json) {
            mqtt_send_ack("finger_enroll", "failed", "MISSING_ID");
            return ESP_FAIL;
        }
        
        uint16_t user_id = (uint16_t)id_json->valueint;
        ESP_LOGI(TAG, "开始录入指纹，用户ID: %u", user_id);
        
        // 停止验证，开始录入
        zw111_stop_verification();
        app_change_state(APP_STATE_ENROLLING_FINGER);
        
        OLED_Clear();
        OLED_ShowPhrase(1, 3, PHRASE_ENROLL_FINGER);
        OLED_ShowPhrase(3, 3, PHRASE_FOLLOW_PROMPT);
        vTaskDelay(pdMS_TO_TICKS(1000));
        OLED_Clear();

        esp_err_t ret = zw111_start_enrollment(user_id, zw111_enroll_callback, 
                                             zw111_enroll_progress_callback);
        if (ret != ESP_OK) {
            mqtt_send_ack("finger_enroll", "failed", "START_FAILED");
            app_change_state(APP_STATE_IDLE);
            return ret;
        }
        
        mqtt_send_ack("finger_enroll", "success", NULL);
        } else if (strcmp(cmd, "card_enroll") == 0) {
        cJSON *id_json = cJSON_GetObjectItem(params, "id");
        if (!id_json) {
            mqtt_send_ack("card_enroll", "failed", "MISSING_ID");
            return ESP_FAIL;
        }
    
        uint8_t card_id = (uint8_t)id_json->valueint;
        ESP_LOGI(TAG, "开始录入卡片，ID: %u，请在10秒内刷卡", card_id);
    
        app_change_state(APP_STATE_ENROLLING_CARD);
    
        OLED_Clear();
        OLED_ShowPhrase(1, 3, PHRASE_ENROLL_CARD);
        OLED_ShowPhrase(2, 2, PHRASE_SWIPE_CARD);
        OLED_ShowString(3, 1, "Timeout: 10s");
    
        esp_err_t ret = rc522_start_enrollment(card_id);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "启动卡片录入失败: %d", ret);
            mqtt_send_ack("card_enroll", "failed", "START_FAILED");
            app_change_state(APP_STATE_IDLE);
            OLED_Clear();
            OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
            return ret;
        }
    
        mqtt_send_ack("card_enroll", "success", "WAITING_FOR_CARD");
        ESP_LOGI(TAG, "卡片录入模式已启动，等待刷卡...");
    
    } 
    else if (strcmp(cmd, "delete_finger") == 0) {
        cJSON *id_json = cJSON_GetObjectItem(params, "id");
        if (!id_json) {
            mqtt_send_ack("delete_finger", "failed", "MISSING_ID");
            return ESP_FAIL;
        }
        
        uint16_t user_id = (uint16_t)id_json->valueint;
        esp_err_t ret = zw111_delete_user(user_id);
        
        if (ret == ESP_OK) {
            mqtt_send_ack("delete_finger", "success", NULL);
        } else {
            mqtt_send_ack("delete_finger", "failed", "DELETE_FAILED");
        }
    } 
    else if (strcmp(cmd, "delete_card") == 0) {
        cJSON *id_json = cJSON_GetObjectItem(params, "id");
        if (!id_json) {
            mqtt_send_ack("delete_card", "failed", "MISSING_ID");
            return ESP_FAIL;
        }
        
        uint8_t card_id = (uint8_t)id_json->valueint;
        esp_err_t ret = rc522_remove_card_by_id(card_id);
        
        if (ret == ESP_OK) {
            mqtt_send_ack("delete_card", "success", NULL);
        } else {
            mqtt_send_ack("delete_card", "failed", "DELETE_FAILED");
        }
    } else if (strcmp(cmd, "open_door") == 0) {
        // 远程开锁
        buzzer_success();
        door_control(true);
        mqtt_send_ack("open_door", "success", NULL);
        mqtt_send_info("door_unlock", "remote", 0);
        OLED_Clear();
        OLED_ShowPhrase(1, 3, PHRASE_WELCOME_USE);
        
    } else if (strcmp(cmd, "reset_factory") == 0) {
        // 确认恢复出厂设置
        mqtt_send_ack("reset_factory", "success", NULL);
        app_perform_factory_reset();

    } else if (strcmp(cmd, "box_status_ack") == 0) {
        box_status_ack_received();
        mqtt_send_ack("box_status_ack", "success", NULL);
    } else {
        ESP_LOGW(TAG, "未知MQTT命令: %s", cmd);
        mqtt_send_ack(cmd, "failed", "UNKNOWN_COMMAND");
    }
    
    return ESP_OK;
}

// ========== 应用逻辑函数 ==========

/**
 * @brief 应用主任务
 */
static void app_main_task(void *arg)
{
    ESP_LOGI(TAG, "应用主任务启动");
    
    // 初始化显示
    OLED_Init();
    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_SYSTEM_STARTING);

    // 初始化柜门传感器
    box_sensor_init();
    box_sensor_register_closed_callback(on_box_closed);
    
    // 初始化蜂鸣器和继电器
    buzzer_init(GPIO_NUM_47);
    servo_init(GPIO_NUM_48);
    buzzer_operation();
    
    // 初始化指纹模块
    zw111_init();
    zw111_start_verification(zw111_verify_callback);
    
    rc522_init(NULL);
    rc522_register_callback(rc522_event_callback, NULL);
    rc522_start_detection();
    
    // 初始化MQTT
    snprintf(g_app.device_id, sizeof(g_app.device_id), "smartlock_001");
    smartlock_mqtt_init(g_app.device_id);
    smartlock_set_command_callback(mqtt_command_callback);
    
    mqtt_client_init(&g_mqtt_config);
    mqtt_client_start();
    
    // 显示就绪状态
    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
    OLED_ShowString(4, 1, "MQTT CONNECTING");
    
    
    g_app.initialized = true;
    ESP_LOGI(TAG, "智能储物柜应用程序启动完成");
    
    while (1) {
        // 主循环处理其他事件
        vTaskDelay(pdMS_TO_TICKS(1000));
    
        // 检查MQTT连接状态
        bool connected = mqtt_is_connected();
        if (connected != g_app.mqtt_connected) {
            g_app.mqtt_connected = connected;
            if (connected) {
                OLED_ShowString(4, 1, "MQTT CONNECTED");
            } else {
                OLED_ShowString(4, 1, "MQTT DISCONNECTED");
            }
        }
    
        // 检查WiFi状态并显示
        static wifi_state_t last_wifi_state = WIFI_STATE_DISCONNECTED;
        wifi_state_t current_wifi_state = wifi_get_connection_state();
    
        if (current_wifi_state != last_wifi_state) {
            last_wifi_state = current_wifi_state;

            switch (current_wifi_state) {
                case WIFI_STATE_CONNECTED:
                    OLED_ShowString(3, 1, "WiFi :)");
                    break;
                case WIFI_STATE_CONNECTING:
                    OLED_ShowString(3, 1, "WiFi Linking");
                    break;
                case WIFI_STATE_DISCONNECTED:
                    OLED_ShowString(3, 1, "WiFi :(");
                    break;
                default:
                    break;
            }
        }
    }
}

/**
 * @brief 柜门关闭回调：由 box_sensor 在检测到关门时调用
 */
static void on_box_closed(void) {
    ESP_LOGI(TAG, "柜门已关闭，开始上报状态");
    // send_box_status_with_retry(false);   // 原有上报
    // // 发送关门事件 info 包
    // cJSON *root = cJSON_CreateObject();
    // cJSON_AddStringToObject(root, "pkg", "info");
    // cJSON_AddStringToObject(root, "event", "door_closed");
    // cJSON_AddStringToObject(root, "device_id", g_app.device_id);
    // cJSON_AddNumberToObject(root, "timestamp", (double)time(NULL));

    // char *json_str = cJSON_PrintUnformatted(root);
    // mqtt_publish("device/smartlock_001/info", json_str, strlen(json_str), 1, 0);
    // free(json_str);
    // cJSON_Delete(root);

     // 发送关门 info 事件
    mqtt_send_info("door_closed", "system", 0);

    // 重置应用状态：回到空闲
    app_change_state(APP_STATE_IDLE);
    g_app.cool_down_end_time = 0; // 清除冷却时间
    
    // 更新OLED显示
    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
}
/**
 * @brief 构建并发送柜门状态 JSON
 */
static void send_box_status_json(bool is_open) {
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "type", "box_status");
    cJSON_AddStringToObject(root, "device_id", g_app.device_id);
    cJSON_AddStringToObject(root, "status", is_open ? "open" : "closed");
    cJSON_AddNumberToObject(root, "timestamp", (double)time(NULL));

    char *json_str = cJSON_PrintUnformatted(root);
    mqtt_publish("device/smartlock_001/box_status", json_str, strlen(json_str), 1, 0);
    free(json_str);
    cJSON_Delete(root);
}

/**
 * @brief 重试定时器回调
 */
static void box_status_retry_timer_cb(TimerHandle_t xTimer) {
    if (g_box_status_ack_received) {
        g_box_status_retry_count = 0;
        xTimerStop(g_box_status_timer, 0);
        return;
    }

    if (g_box_status_retry_count < BOX_STATUS_RETRY_MAX) {
        ESP_LOGW(TAG, "柜门状态上报未收到应答，重试 %d/%d", 
                 g_box_status_retry_count + 1, BOX_STATUS_RETRY_MAX);
        send_box_status_json(false);   // 关门状态
        g_box_status_retry_count++;
    } else {
        ESP_LOGE(TAG, "柜门状态上报失败，已达最大重试次数");
        xTimerStop(g_box_status_timer, 0);
        g_box_status_retry_count = 0;
        // 即使失败也断电（已经在 box_sensor 回调中调用 disable，这里无需操作）
    }
}

/**
 * @brief 启动带重试的上报（由关门回调调用）
 */
static void send_box_status_with_retry(bool is_open) {
    send_box_status_json(is_open);
    g_box_status_ack_received = false;
    g_box_status_retry_count = 1;

    if (g_box_status_timer == NULL) {
        g_box_status_timer = xTimerCreate("box_retry", 
                                          pdMS_TO_TICKS(BOX_STATUS_RETRY_INTERVAL),
                                          pdTRUE,
                                          NULL,
                                          box_status_retry_timer_cb);
    }
    xTimerStart(g_box_status_timer, 0);
}

/**
 * @brief 收到后端应答时调用（停止重试）
 */
void box_status_ack_received(void) {
    g_box_status_ack_received = true;
    if (g_box_status_timer) {
        xTimerStop(g_box_status_timer, 0);
    }
    g_box_status_retry_count = 0;
    ESP_LOGI(TAG, "柜门状态上报已确认");
}

/**
 * @brief 改变应用状态
 */
static void app_change_state(app_state_t new_state)
{
    if (xSemaphoreTake(g_app.state_mutex, portMAX_DELAY)) {
        g_app.prev_state = g_app.state;
        g_app.state = new_state;
        xSemaphoreGive(g_app.state_mutex);
    }
}

/**
 * @brief 处理验证成功
 */
static void app_handle_verify_success(verify_method_t method, uint16_t user_id)
{
    ESP_LOGI(TAG, "验证成功，方法: %d, 用户ID: %u", method, user_id);
    
    // 记录验证信息
    g_app.last_method = method;
    g_app.last_user_id = user_id;
    
    // 检查是否在冷却时间内
    bool in_cool_down = (g_app.state == APP_STATE_COOL_DOWN) && 
                       (xTaskGetTickCount() <= g_app.cool_down_end_time);
    
    if (in_cool_down) {
        // 冷却时间内：只发送MQTT信息，不执行开锁动作
        ESP_LOGI(TAG, "冷却时间内，跳过开锁动作");
        
        // 成功提示音（短促提示）
        buzzer_operation(); // 使用操作提示音而不是成功音
        
        // 更新显示（提示验证成功但不开锁）
        OLED_Clear();
        OLED_ShowPhrase(1, 3, PHRASE_VERIFY_SUCCESS);
        OLED_ShowPhrase(2, 3, PHRASE_SYSTEM_BUSY);
        
        // 发送MQTT状态（冷却模式）
        const char* method_str = "";
        switch (method) {
            case VERIFY_METHOD_FINGER: method_str = "finger"; break;
            case VERIFY_METHOD_CARD: method_str = "card"; break;
            case VERIFY_METHOD_PASSWORD: method_str = "password"; break;
            case VERIFY_METHOD_TEMP_PASSWORD: method_str = "temppassword"; break;
            default: break;
        }
        mqtt_send_info("verify_success_cooling", method_str, user_id);
        
        // 短暂显示后回到冷却状态
        vTaskDelay(pdMS_TO_TICKS(1500));
        app_change_state(APP_STATE_COOL_DOWN);
        OLED_Clear();
        OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
        
    } else {
        // 正常情况：执行完整的开锁流程
        ESP_LOGI(TAG, "正常开锁流程");
        
        //成功提示音
        buzzer_success();
        // 更新显示
        OLED_Clear();
        OLED_ShowPhrase(1, 3, PHRASE_VERIFY_SUCCESS);
        OLED_ShowPhrase(2, 3, PHRASE_DOOR_OPENED);
        
        OLED_ShowPhrase(1, 3, PHRASE_WELCOME_USE);
        // 开锁
        door_control(true);

        // 检测关门
        box_sensor_enable();  // 给传感器供电，开始监测关门
        
        // 发送MQTT状态
        const char* method_str = "";
        switch (method) {
            case VERIFY_METHOD_FINGER: method_str = "finger"; break;
            case VERIFY_METHOD_CARD: method_str = "card"; break;
            case VERIFY_METHOD_PASSWORD: method_str = "password"; break;
            case VERIFY_METHOD_TEMP_PASSWORD: method_str = "temppassword"; break;
            default: break;
        }
        mqtt_send_info("door_unlock", method_str, user_id);
        
        // 进入冷却时间（3秒）
        g_app.cool_down_end_time = xTaskGetTickCount() + pdMS_TO_TICKS(3000);
        app_change_state(APP_STATE_COOL_DOWN);
    }
}

/**
 * @brief 处理验证失败
 */
static void app_handle_verify_failed(verify_method_t method)
{
    ESP_LOGI(TAG, "验证失败，方法: %d", method);
    
    buzzer_failure();

    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_VERIFY_FAILED);
    OLED_ShowPhrase(3, 3, PHRASE_TRY_AGAIN);
    
    // 发送MQTT状态
    const char* method_str = "";
    switch (method) {
        case VERIFY_METHOD_FINGER: method_str = "finger"; break;
        case VERIFY_METHOD_CARD: method_str = "card"; break;
        case VERIFY_METHOD_PASSWORD: method_str = "password"; break;
        case VERIFY_METHOD_TEMP_PASSWORD: method_str = "temppassword"; break;
        default: break;
    }
    mqtt_send_info("valid_failed", method_str, 0);
    
    vTaskDelay(pdMS_TO_TICKS(500));
    
    // 回到就绪状态
    app_change_state(APP_STATE_IDLE);
    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
}

/**
 * @brief 处理特殊功能
 */
static void app_handle_special_function(uint8_t function_id)
{
    if (xTaskGetTickCount() > g_app.cool_down_end_time) {
        // 冷却时间结束，回到空闲状态
        app_change_state(APP_STATE_IDLE);
        OLED_Clear();
        OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
        return;
    }
    
    switch (function_id) {
        case 1: // 删除WiFi配置
            app_change_state(APP_STATE_CONFIRM_WIFI_RESET);
            OLED_Clear();
            OLED_ShowString(1, 1, "Confirm Del WiFi");
            OLED_ShowString(2, 1, "Press D OK");
            OLED_ShowString(3, 1, "Press C Cancel");
            break;
            
        case 2: // 恢复出厂设置
            app_change_state(APP_STATE_CONFIRM_RESET);
            OLED_Clear();
            OLED_ShowString(1, 1, "Confirm RST ALL");
            OLED_ShowString(2, 1, "Press D OK");
            OLED_ShowString(3, 1, "Press C Cancel");
            break;
            
        default:
            break;
    }
}

/**
 * @brief 执行恢复出厂设置
 */
static void app_perform_factory_reset(void)
{
    ESP_LOGI(TAG, "开始恢复出厂设置");
    
    app_change_state(APP_STATE_RESETTING);
    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_RESETING);
    
    // 停止所有验证
    zw111_stop_verification();
    rc522_stop_detection();
    
    // 清空指纹库
    zw111_clear_database();
    vTaskDelay(pdMS_TO_TICKS(1000));
    
    // 清空卡片
    rc522_clear_cards();
    vTaskDelay(pdMS_TO_TICKS(500));
    
    // 清空NVS所有数据
    nvs_flash_deinit();
    nvs_flash_erase();
    vTaskDelay(pdMS_TO_TICKS(1000));
    
    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_RESET_COMPLETE);
    buzzer_success();
    
    vTaskDelay(pdMS_TO_TICKS(2000));
    
    // 重启设备
    esp_restart();
}

/**
 * @brief 删除WiFi配置
 */
static void app_delete_wifi_config(void)
{
    ESP_LOGI(TAG, "删除WiFi配置");
    
    // 停止WiFi
    wifi_stop();
    vTaskDelay(pdMS_TO_TICKS(1000));
    
    // 删除NVS中的WiFi配置
    nvs_handle_t nvs_handle;
    if (nvs_open("wifi_config", NVS_READWRITE, &nvs_handle) == ESP_OK) {
        nvs_erase_all(nvs_handle);
        nvs_commit(nvs_handle);
        nvs_close(nvs_handle);
    }
    
    OLED_Clear();
    OLED_ShowString(2, 1, " WiFi Config Deleted ");
    buzzer_success();
    
    vTaskDelay(pdMS_TO_TICKS(2000));
    
    // 回到就绪状态
    app_change_state(APP_STATE_IDLE);
    OLED_Clear();
    OLED_ShowPhrase(2, 3, PHRASE_WELCOME_USE);
}

// ========== 公共API实现 ==========

esp_err_t app_init(void)
{
    if (g_app.initialized) {
        ESP_LOGW(TAG, "应用程序已经初始化");
        return ESP_OK;
    }
    
    ESP_LOGI(TAG, "初始化智能门锁应用程序");
    
    // 初始化应用上下文
    memset(&g_app, 0, sizeof(g_app));
    g_app.state = APP_STATE_IDLE;
    g_app.initialized = false;
    
    // 创建状态互斥锁
    g_app.state_mutex = xSemaphoreCreateMutex();
    if (g_app.state_mutex == NULL) {
        ESP_LOGE(TAG, "创建状态互斥锁失败");
        return ESP_FAIL;
    }
    
    // 创建事件队列
    g_app.event_queue = xQueueCreate(10, sizeof(uint32_t));
    if (g_app.event_queue == NULL) {
        ESP_LOGE(TAG, "创建事件队列失败");
        vSemaphoreDelete(g_app.state_mutex);
        return ESP_FAIL;
    }
    
    // 创建主任务
    BaseType_t task_ret = xTaskCreate(app_main_task, "app_main", 8192, NULL, 4, &g_app.main_task_handle);
    if (task_ret != pdPASS) {
        ESP_LOGE(TAG, "创建应用主任务失败");
        vSemaphoreDelete(g_app.state_mutex);
        vQueueDelete(g_app.event_queue);
        return ESP_FAIL;
    }
    
    ESP_LOGI(TAG, "智能储物柜应用程序初始化成功");
    return ESP_OK;
}

esp_err_t app_stop(void)
{
    ESP_LOGI(TAG, "停止智能储物柜应用程序");
    
    // 停止MQTT服务
    smartlock_mqtt_stop();
    
    // 停止各驱动
    zw111_stop_verification();
    rc522_stop_detection();
    
    return ESP_OK;
}