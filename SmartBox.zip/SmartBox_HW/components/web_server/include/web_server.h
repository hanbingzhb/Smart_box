/**
 * *****************************************************************************
 * @file web_server.h
 * @brief Web服务器组件
 * @version 1.1
 * @date 2025-11-08
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * *****************************************************************************
 */

#ifndef __WEB_SERVER_H__
#define __WEB_SERVER_H__

#include "esp_err.h"
#include "esp_http_server.h"

// WiFi配置回调
typedef esp_err_t (*wifi_config_callback_t)(const char* ssid, const char* password);

/**
 * @brief 初始化Web服务器
 * @return esp_err_t 错误代码
 */
esp_err_t web_server_init(void);

/**
 * @brief 启动Web服务器
 * @return esp_err_t 错误代码
 */
esp_err_t web_server_start(void);

/**
 * @brief 停止Web服务器
 * @return esp_err_t 错误代码
 */
esp_err_t web_server_stop(void);

/**
 * @brief 设置WiFi配置回调
 * @param callback 回调函数
 */
void web_server_set_wifi_callback(wifi_config_callback_t callback);

/**
 * @brief 设置设备ID
 * @param device_id 设备ID字符串
 */
void web_server_set_device_id(const char* device_id);

#endif /* __WEB_SERVER_H__ */