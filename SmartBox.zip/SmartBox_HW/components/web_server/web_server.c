/**
 * *****************************************************************************
 * @file web_server.c
 * @brief Web服务器组件实现
 * @version 1.1
 * @date 2025-11-08
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * *****************************************************************************
 */

#include "web_server.h"
#include "esp_log.h"
#include "esp_http_server.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "cJSON.h"
#include "wifi_config.h"

static const char *TAG = "Web_Server";

static httpd_handle_t g_server = NULL;
static wifi_config_callback_t g_wifi_callback = NULL;
static char g_device_id[32] = "SL-UNKNOWN"; // 默认设备ID

// 配网页面HTML - 简化版，移除随机生成设备ID的代码
static const char* WEB_HTML = 
"<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><title>智能储物柜配置</title><style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:Arial,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px}.container{background:white;border-radius:15px;box-shadow:0 20px 40px rgba(0,0,0,0.1);padding:30px;width:100%;max-width:500px}.header{text-align:center;margin-bottom:30px}.header h1{color:#333;margin-bottom:10px;font-size:28px}.header p{color:#666;font-size:16px}.status-card{background:#f8f9fa;border-radius:10px;padding:20px;margin-bottom:20px;border-left:4px solid #007bff}.status-item{display:flex;justify-content:space-between;margin-bottom:8px;font-size:14px}.status-label{color:#666;font-weight:500}.status-value{color:#333;font-weight:600}.form-group{margin-bottom:20px}.form-group label{display:block;margin-bottom:8px;color:#333;font-weight:500}.form-control{width:100%;padding:12px 15px;border:2px solid #e9ecef;border-radius:8px;font-size:16px;transition:border-color 0.3s}.form-control:focus{outline:none;border-color:#007bff}.btn{width:100%;padding:12px;border:none;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer;transition:background-color 0.3s}.btn-primary{background:#007bff;color:white}.btn-primary:hover{background:#0056b3}.btn-secondary{background:#6c757d;color:white;margin-top:10px}.btn-secondary:hover{background:#545b62}.scan-section{margin-bottom:20px}.network-list{max-height:200px;overflow-y:auto;border:1px solid #e9ecef;border-radius:8px;margin-bottom:15px}.network-item{padding:12px 15px;border-bottom:1px solid #e9ecef;cursor:pointer;transition:background-color 0.2s}.network-item:hover{background:#f8f9fa}.network-item:last-child{border-bottom:none}.network-ssid{font-weight:600;color:#333}.network-rssi{color:#666;font-size:14px}.encrypted{color:#dc3545;font-size:12px;margin-left:10px}.alert{padding:12px;border-radius:8px;margin-bottom:20px;display:none}.alert-success{background:#d4edda;color:#155724;border:1px solid #c3e6cb}.alert-error{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb}.loading{display:none;margin-top:10px;text-align:center;color:#666}.spinner{border:3px solid #f3f3f3;border-top:3px solid #007bff;border-radius:50%;width:30px;height:30px;animation:spin 1s linear infinite;margin:0 auto 10px}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}</style></head><body><div class=\"container\"><div class=\"header\"><h1>智能门锁配置</h1><p>配置WiFi网络连接</p></div><div class=\"status-card\"><div class=\"status-item\"><span class=\"status-label\">设备ID:</span><span class=\"status-value\" id=\"deviceId\">-</span></div><div class=\"status-item\"><span class=\"status-label\">WiFi状态:</span><span class=\"status-value\" id=\"wifiStatus\">-</span></div><div class=\"status-item\"><span class=\"status-label\">IP地址:</span><span class=\"status-value\" id=\"ipAddress\">-</span></div></div><div class=\"alert\" id=\"alert\"></div><div class=\"scan-section\"><button class=\"btn btn-secondary\" onclick=\"scanNetworks()\">扫描2.4G WiFi网络</button><div class=\"loading\" id=\"scanLoading\"><div class=\"spinner\"></div>正在扫描网络...</div><div class=\"network-list\" id=\"networkList\" style=\"display:none\"></div></div><form id=\"wifiForm\"><div class=\"form-group\"><label for=\"ssid\">WiFi名称 (SSID)</label><input type=\"text\" id=\"ssid\" class=\"form-control\" required placeholder=\"输入WiFi名称\"></div><div class=\"form-group\"><label for=\"password\">WiFi密码</label><input type=\"password\" id=\"password\" class=\"form-control\" placeholder=\"输入WiFi密码 (如无需密码请留空)\"></div><button type=\"submit\" class=\"btn btn-primary\">连接WiFi</button></form><div class=\"loading\" id=\"connectLoading\"><div class=\"spinner\"></div>正在连接网络...</div></div><script>let currentStatus='disconnected';document.addEventListener('DOMContentLoaded',function(){updateStatus();setInterval(updateStatus,5000)});async function updateStatus(){try{const response=await fetch('/api/wifi/status');const data=await response.json();document.getElementById('deviceId').textContent=data.device_id||'-';const statusMap={0:'未连接',1:'连接中',2:'已连接',3:'配网中'};currentStatus=data.state;document.getElementById('wifiStatus').textContent=statusMap[data.state]||'未知';document.getElementById('ipAddress').textContent=data.ip||'-'}catch(error){console.error('获取状态失败:',error)}}async function scanNetworks(){const scanBtn=document.querySelector('.btn-secondary');const loading=document.getElementById('scanLoading');const networkList=document.getElementById('networkList');scanBtn.disabled=true;loading.style.display='block';networkList.style.display='none';try{const response=await fetch('/api/wifi/scan');const data=await response.json();if(data.networks&&data.networks.length>0){displayNetworks(data.networks)}else{showAlert('未找到可用WiFi网络','error')}}catch(error){console.error('扫描失败:',error);showAlert('扫描WiFi网络失败','error')}finally{scanBtn.disabled=false;loading.style.display='none'}}function displayNetworks(networks){const networkList=document.getElementById('networkList');networkList.innerHTML='';networks.forEach(network=>{const networkItem=document.createElement('div');networkItem.className='network-item';networkItem.onclick=()=>selectNetwork(network);networkItem.innerHTML=`<div class=\"network-ssid\">${network.ssid}${network.encrypted?'<span class=\"encrypted\">加密</span>':''}</div><div class=\"network-rssi\">信号强度: ${network.rssi} dBm</div>`;networkList.appendChild(networkItem)});networkList.style.display='block'}function selectNetwork(network){document.getElementById('ssid').value=network.ssid;document.getElementById('password').focus();document.querySelectorAll('.network-item').forEach(item=>{item.style.background=''});event.currentTarget.style.background='#e3f2fd'}document.getElementById('wifiForm').addEventListener('submit',async function(e){e.preventDefault();const ssid=document.getElementById('ssid').value.trim();const password=document.getElementById('password').value;const loading=document.getElementById('connectLoading');if(!ssid){showAlert('请输入WiFi名称','error');return}loading.style.display='block';try{const response=await fetch('/api/wifi/connect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ssid:ssid,password:password})});const result=await response.json();if(result.success){showAlert('WiFi连接成功！','success');setTimeout(()=>{window.location.reload()},2000)}else{showAlert('WiFi连接失败: '+(result.error||'未知错误'),'error')}}catch(error){console.error('连接失败:',error);showAlert('连接WiFi失败','error')}finally{loading.style.display='none'}});function showAlert(message,type){const alert=document.getElementById('alert');alert.textContent=message;alert.className=`alert alert-${type}`;alert.style.display='block';setTimeout(()=>{alert.style.display='none'},5000)}</script></body></html>";

// WiFi状态API
static esp_err_t api_wifi_status_handler(httpd_req_t *req)
{
    cJSON *root = cJSON_CreateObject();
    char ip_addr[16] = {0};
    char ap_ip_addr[16] = {0};
    
    wifi_get_ip_address(ip_addr, sizeof(ip_addr));
    wifi_get_ap_ip_address(ap_ip_addr, sizeof(ap_ip_addr));
    
    // 状态映射：0-未连接, 1-连接中, 2-已连接, 3-配网中
    int state = 0;
    wifi_mode_t mode = wifi_get_mode();
    
    if (mode == WIFI_MODE_APSTA || mode == WIFI_MODE_AP) {
        state = 3; // 配网中
    } else if (mode == WIFI_MODE_STA) {
        if (wifi_is_connected()) {
            state = 2; // 已连接
        } else {
            wifi_state_t conn_state = wifi_get_connection_state();
            state = (conn_state == WIFI_STATE_CONNECTING) ? 1 : 0;
        }
    } else {
        state = 0; // 未连接
    }
    
    cJSON_AddNumberToObject(root, "state", state);
    cJSON_AddStringToObject(root, "ip", ip_addr);
    cJSON_AddStringToObject(root, "ap_ip", ap_ip_addr);
    cJSON_AddStringToObject(root, "device_id", g_device_id);
    cJSON_AddStringToObject(root, "mode", 
        mode == WIFI_MODE_APSTA ? "APSTA" : 
        mode == WIFI_MODE_AP ? "AP" : 
        mode == WIFI_MODE_STA ? "STA" : "NULL");
    
    const char *response = cJSON_Print(root);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_send(req, response, strlen(response));
    
    cJSON_Delete(root);
    free((void*)response);
    
    return ESP_OK;
}

// WiFi扫描API
static esp_err_t api_wifi_scan_handler(httpd_req_t *req)
{
    uint16_t ap_count = 0;
    wifi_ap_record_t *ap_info = wifi_scan_networks(&ap_count);
    
    cJSON *root = cJSON_CreateObject();
    cJSON *networks = cJSON_CreateArray();
    
    if (ap_info && ap_count > 0) {
        for (int i = 0; i < ap_count; i++) {
            cJSON *network = cJSON_CreateObject();
            cJSON_AddStringToObject(network, "ssid", (char*)ap_info[i].ssid);
            cJSON_AddNumberToObject(network, "rssi", ap_info[i].rssi);
            cJSON_AddBoolToObject(network, "encrypted", ap_info[i].authmode != WIFI_AUTH_OPEN);
            cJSON_AddItemToArray(networks, network);
        }
        free(ap_info);
    }
    
    cJSON_AddItemToObject(root, "networks", networks);
    
    const char *response = cJSON_Print(root);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_send(req, response, strlen(response));
    
    cJSON_Delete(root);
    free((void*)response);
    
    return ESP_OK;
}

// WiFi连接API
static esp_err_t api_wifi_connect_handler(httpd_req_t *req)
{
    char buf[1024];
    int ret, remaining = req->content_len;
    
    if (remaining >= sizeof(buf)) {
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "内容过长");
        return ESP_FAIL;
    }
    
    ret = httpd_req_recv(req, buf, remaining);
    if (ret <= 0) {
        return ESP_FAIL;
    }
    
    buf[ret] = '\0';
    
    cJSON *root = cJSON_Parse(buf);
    if (!root) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "无效的JSON");
        return ESP_FAIL;
    }
    
    cJSON *ssid = cJSON_GetObjectItem(root, "ssid");
    cJSON *password = cJSON_GetObjectItem(root, "password");
    
    if (!ssid) {
        cJSON_Delete(root);
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "缺少SSID");
        return ESP_FAIL;
    }
    
    cJSON *response_json = cJSON_CreateObject();
    
    if (g_wifi_callback) {
        esp_err_t result = g_wifi_callback(ssid->valuestring, 
                                         password ? password->valuestring : "");
        cJSON_AddBoolToObject(response_json, "success", result == ESP_OK);
        if (result != ESP_OK) {
            cJSON_AddStringToObject(response_json, "error", "连接失败");
        }
    } else {
        cJSON_AddBoolToObject(response_json, "success", false);
        cJSON_AddStringToObject(response_json, "error", "回调未设置");
    }
    
    const char *response = cJSON_Print(response_json);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_send(req, response, strlen(response));
    
    cJSON_Delete(root);
    cJSON_Delete(response_json);
    free((void*)response);
    
    return ESP_OK;
}

// 根路径处理 - 返回配网页面
static esp_err_t root_get_handler(httpd_req_t *req)
{
    httpd_resp_set_type(req, "text/html");
    httpd_resp_send(req, WEB_HTML, strlen(WEB_HTML));
    return ESP_OK;
}

// URI处理器
static const httpd_uri_t root = {
    .uri       = "/",
    .method    = HTTP_GET,
    .handler   = root_get_handler,
    .user_ctx  = NULL
};

static const httpd_uri_t wifi_status = {
    .uri       = "/api/wifi/status",
    .method    = HTTP_GET,
    .handler   = api_wifi_status_handler,
    .user_ctx  = NULL
};

static const httpd_uri_t wifi_scan = {
    .uri       = "/api/wifi/scan",
    .method    = HTTP_GET,
    .handler   = api_wifi_scan_handler,
    .user_ctx  = NULL
};

static const httpd_uri_t wifi_connect = {
    .uri       = "/api/wifi/connect",
    .method    = HTTP_POST,
    .handler   = api_wifi_connect_handler,
    .user_ctx  = NULL
};

esp_err_t web_server_init(void)
{
    ESP_LOGI(TAG, "初始化Web服务器");
    
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.ctrl_port = 32768;
    config.max_uri_handlers = 16;
    
    esp_err_t ret = httpd_start(&g_server, &config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动Web服务器失败: 0x%x", ret);
        return ret;
    }
    
    // 注册URI处理器
    httpd_register_uri_handler(g_server, &root);
    httpd_register_uri_handler(g_server, &wifi_status);
    httpd_register_uri_handler(g_server, &wifi_scan);
    httpd_register_uri_handler(g_server, &wifi_connect);
    
    ESP_LOGI(TAG, "Web服务器初始化成功，端口: %d", config.server_port);
    return ESP_OK;
}

esp_err_t web_server_start(void)
{
    // 在init时已经启动
    return ESP_OK;
}

esp_err_t web_server_stop(void)
{
    if (g_server) {
        httpd_stop(g_server);
        g_server = NULL;
        ESP_LOGI(TAG, "Web服务器已停止");
    }
    return ESP_OK;
}

void web_server_set_wifi_callback(wifi_config_callback_t callback)
{
    g_wifi_callback = callback;
}

void web_server_set_device_id(const char* device_id)
{
    if (device_id) {
        strncpy(g_device_id, device_id, sizeof(g_device_id) - 1);
        g_device_id[sizeof(g_device_id) - 1] = '\0';
        ESP_LOGI(TAG, "设置设备ID: %s", g_device_id);
    }
}