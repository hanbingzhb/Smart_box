/**
 * *****************************************************************************
 * @file rc522_driver.c
 * @brief RC522 NFC识别驱动 - 极致精简版
 * @version 3.0
 * @date 2025-11-08
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * 
 * @par 修改日志:
 * Date       Version     Author      Description
 * 2025-11-08 3.0         zhanhuangbin  极致精简，优化存储
 * *****************************************************************************
 */

#include "rc522_driver.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include <string.h>
#include <stdlib.h>

static const char *TAG = "RC522";

// ========== 硬件配置 ==========
#define RC522_DEFAULT_MISO_GPIO      GPIO_NUM_18
#define RC522_DEFAULT_MOSI_GPIO      GPIO_NUM_17
#define RC522_DEFAULT_SCLK_GPIO      GPIO_NUM_16
#define RC522_DEFAULT_CS_GPIO        GPIO_NUM_15
#define RC522_DEFAULT_RST_GPIO       GPIO_NUM_8
#define RC522_DEFAULT_SPI_HOST       SPI2_HOST

// ========== 操作状态码 ==========
#define RC522_OK                  0
#define RC522_NOTAGERR            1
#define RC522_ERR                 2

// ========== 寄存器地址 ==========
#define RC522_REG_COMMAND            0x01
#define RC522_REG_COMM_IE_N          0x02
#define RC522_REG_COMM_IRQ           0x04
#define RC522_REG_DIV_IRQ            0x05
#define RC522_REG_ERROR              0x06
#define RC522_REG_FIFO_DATA          0x09
#define RC522_REG_FIFO_LEVEL         0x0A
#define RC522_REG_CONTROL            0x0C
#define RC522_REG_BIT_FRAMING        0x0D
#define RC522_REG_MODE               0x11
#define RC522_REG_TX_CONTROL         0x14
#define RC522_REG_TX_AUTO            0x15
#define RC522_REG_RX_THRESHOLD       0x18
#define RC522_REG_CRC_RESULT_M       0x21
#define RC522_REG_CRC_RESULT_L       0x22
#define RC522_REG_RF_CFG             0x26
#define RC522_REG_T_MODE             0x2A
#define RC522_REG_T_PRESCALER        0x2B
#define RC522_REG_T_RELOAD_L         0x2D

// ========== PCD命令 ==========
#define RC522_PCD_IDLE               0x00
#define RC522_PCD_TRANSCEIVE         0x0C
#define RC522_PCD_RESETPHASE         0x0F
#define RC522_PCD_CALCCRC            0x03

// ========== PICC命令 ==========
#define RC522_PICC_REQIDL            0x26
#define RC522_PICC_ANTICOLL          0x93
#define RC522_PICC_HALT              0x50

// ========== 卡片存储结构 ==========
typedef struct {
    uint8_t card_id[RC522_CARD_ID_SIZE];
    uint8_t id;
} rc522_card_t;

// ========== RC522驱动句柄 ==========
typedef struct {
    spi_device_handle_t spi;
    rc522_config_t config;
    nvs_handle_t nvs_handle;
    TaskHandle_t detection_task;
    rc522_event_callback_t event_cb;
    void *user_data;
    bool detection_running;
    
    // 状态管理
    bool is_enrolling;
    uint8_t enroll_id;
    uint32_t enroll_start_time;
    
    // 防重复检测
    uint8_t last_card_id[RC522_CARD_ID_SIZE];
    uint32_t last_card_time;
    
    // 卡片存储
    rc522_card_t cards[RC522_MAX_CARDS];
    uint8_t card_count;
} rc522_handle_t;

static rc522_handle_t *g_handle = NULL;

// ========== 内部函数声明 ==========
static esp_err_t _configure_gpio(const rc522_config_t *cfg);
static esp_err_t _configure_spi(rc522_handle_t *h, const rc522_config_t *cfg);
static void _cs_select(rc522_handle_t *h);
static void _cs_deselect(rc522_handle_t *h);
static uint8_t _spi_transfer(rc522_handle_t *h, uint8_t data);
static esp_err_t _write_reg(rc522_handle_t *h, uint8_t addr, uint8_t val);
static uint8_t _read_reg(rc522_handle_t *h, uint8_t addr);
static void _set_bitmask(rc522_handle_t *h, uint8_t reg, uint8_t mask);
static void _clear_bitmask(rc522_handle_t *h, uint8_t reg, uint8_t mask);
static void _calculate_crc(rc522_handle_t *h, uint8_t *in, uint8_t len, uint8_t *out);
static uint8_t _to_card(rc522_handle_t *h, uint8_t command, uint8_t *send_data, uint8_t send_len, uint8_t *back_data, uint16_t *back_len);
static uint8_t _request(rc522_handle_t *h, uint8_t req_mode, uint8_t *tag_type);
static uint8_t _anticoll(rc522_handle_t *h, uint8_t *ser_num);
static void _halt(rc522_handle_t *h);
static esp_err_t _init_hw(rc522_handle_t *h);
static void _detection_task(void *arg);
static void _send_event(rc522_event_t *ev);
static esp_err_t _nvs_open(rc522_handle_t *h);
static bool _is_duplicate_card(uint8_t *card_id);
static esp_err_t _load_cards(rc522_handle_t *h);
static esp_err_t _save_cards(rc522_handle_t *h);
static int _find_card_by_id(uint8_t *card_id);
static int _find_card_by_num(uint8_t id);

// ========== NVS存储管理 ==========
static esp_err_t _nvs_open(rc522_handle_t *h)
{
    return nvs_open("rc522", NVS_READWRITE, &h->nvs_handle);
}

static esp_err_t _load_cards(rc522_handle_t *h)
{
    size_t size = sizeof(h->cards);
    esp_err_t ret = nvs_get_blob(h->nvs_handle, "cards", h->cards, &size);
    
    if (ret == ESP_OK) {
        ret = nvs_get_u8(h->nvs_handle, "count", &h->card_count);
        if (ret != ESP_OK) {
            h->card_count = 0;
        }
    } else {
        h->card_count = 0;
        memset(h->cards, 0, sizeof(h->cards));
    }
    
    return ESP_OK;
}

static esp_err_t _save_cards(rc522_handle_t *h)
{
    esp_err_t ret = nvs_set_blob(h->nvs_handle, "cards", h->cards, sizeof(h->cards));
    if (ret != ESP_OK) return ret;
    
    ret = nvs_set_u8(h->nvs_handle, "count", h->card_count);
    if (ret != ESP_OK) return ret;
    
    return nvs_commit(h->nvs_handle);
}

// ========== 卡片管理 ==========
static int _find_card_by_id(uint8_t *card_id)
{
    for (int i = 0; i < g_handle->card_count; i++) {
        if (memcmp(g_handle->cards[i].card_id, card_id, RC522_CARD_ID_SIZE) == 0) {
            return i;
        }
    }
    return -1;
}

static int _find_card_by_num(uint8_t id)
{
    for (int i = 0; i < g_handle->card_count; i++) {
        if (g_handle->cards[i].id == id) {
            return i;
        }
    }
    return -1;
}

static esp_err_t _add_card(uint8_t *card_id, uint8_t id)
{
    if (g_handle->card_count >= RC522_MAX_CARDS) {
        return ESP_ERR_NO_MEM;
    }
    
    if (_find_card_by_id(card_id) >= 0) {
        return ESP_ERR_INVALID_STATE;
    }
    
    if (_find_card_by_num(id) >= 0) {
        return ESP_ERR_INVALID_STATE;
    }
    
    memcpy(g_handle->cards[g_handle->card_count].card_id, card_id, RC522_CARD_ID_SIZE);
    g_handle->cards[g_handle->card_count].id = id;
    g_handle->card_count++;
    
    return _save_cards(g_handle);
}

static esp_err_t _remove_card(uint8_t *card_id)
{
    int index = _find_card_by_id(card_id);
    if (index < 0) {
        return ESP_ERR_NOT_FOUND;
    }
    
    for (int i = index; i < g_handle->card_count - 1; i++) {
        memcpy(&g_handle->cards[i], &g_handle->cards[i + 1], sizeof(rc522_card_t));
    }
    
    g_handle->card_count--;
    return _save_cards(g_handle);
}

static esp_err_t _remove_card_by_num(uint8_t id)
{
    int index = _find_card_by_num(id);
    if (index < 0) {
        return ESP_ERR_NOT_FOUND;
    }
    
    for (int i = index; i < g_handle->card_count - 1; i++) {
        memcpy(&g_handle->cards[i], &g_handle->cards[i + 1], sizeof(rc522_card_t));
    }
    
    g_handle->card_count--;
    return _save_cards(g_handle);
}

static esp_err_t _clear_cards(void)
{
    g_handle->card_count = 0;
    memset(g_handle->cards, 0, sizeof(g_handle->cards));
    return _save_cards(g_handle);
}

// ========== 基础硬件操作 ==========
static void _cs_select(rc522_handle_t *h) 
{ 
    gpio_set_level(h->config.cs_io, 0); 
}

static void _cs_deselect(rc522_handle_t *h) 
{ 
    gpio_set_level(h->config.cs_io, 1); 
}

static uint8_t _spi_transfer(rc522_handle_t *h, uint8_t data)
{
    spi_transaction_t t = {
        .length = 8,
        .tx_buffer = &data,
        .rx_buffer = &data
    };
    
    spi_device_transmit(h->spi, &t);
    return data;
}

static esp_err_t _write_reg(rc522_handle_t *h, uint8_t addr, uint8_t val)
{
    _cs_select(h);
    _spi_transfer(h, (addr << 1) & 0x7E);
    _spi_transfer(h, val);
    _cs_deselect(h);
    return ESP_OK;
}

static uint8_t _read_reg(rc522_handle_t *h, uint8_t addr)
{
    _cs_select(h);
    _spi_transfer(h, ((addr << 1) & 0x7E) | 0x80);
    uint8_t val = _spi_transfer(h, 0x00);
    _cs_deselect(h);
    return val;
}

static void _set_bitmask(rc522_handle_t *h, uint8_t reg, uint8_t mask)
{
    uint8_t tmp = _read_reg(h, reg);
    _write_reg(h, reg, tmp | mask);
}

static void _clear_bitmask(rc522_handle_t *h, uint8_t reg, uint8_t mask)
{
    uint8_t tmp = _read_reg(h, reg);
    _write_reg(h, reg, tmp & (~mask));
}

static void _calculate_crc(rc522_handle_t *h, uint8_t *in, uint8_t len, uint8_t *out)
{
    _clear_bitmask(h, RC522_REG_DIV_IRQ, 0x04);
    _set_bitmask(h, RC522_REG_FIFO_LEVEL, 0x80);
    
    for (uint8_t i = 0; i < len; i++) {
        _write_reg(h, RC522_REG_FIFO_DATA, in[i]);
    }
    
    _write_reg(h, RC522_REG_COMMAND, RC522_PCD_CALCCRC);
    
    uint8_t i = 0xFF;
    do {
        i--;
    } while ((i != 0) && !(_read_reg(h, RC522_REG_DIV_IRQ) & 0x04));
    
    out[0] = _read_reg(h, RC522_REG_CRC_RESULT_L);
    out[1] = _read_reg(h, RC522_REG_CRC_RESULT_M);
}

static uint8_t _to_card(rc522_handle_t *h, uint8_t command, uint8_t *send_data, uint8_t send_len, uint8_t *back_data, uint16_t *back_len)
{
    uint8_t status = RC522_ERR;
    uint8_t irq_en = 0x00;
    uint8_t wait_irq = 0x00;
    
    if (command == RC522_PCD_TRANSCEIVE) {
        irq_en = 0x77;
        wait_irq = 0x30;
    }
    
    _write_reg(h, RC522_REG_COMM_IE_N, irq_en | 0x80);
    _clear_bitmask(h, RC522_REG_COMM_IRQ, 0x80);
    _set_bitmask(h, RC522_REG_FIFO_LEVEL, 0x80);
    _write_reg(h, RC522_REG_COMMAND, RC522_PCD_IDLE);
    
    for (uint16_t i = 0; i < send_len; i++) {
        _write_reg(h, RC522_REG_FIFO_DATA, send_data[i]);
    }
    
    _write_reg(h, RC522_REG_COMMAND, command);
    
    if (command == RC522_PCD_TRANSCEIVE) {
        _set_bitmask(h, RC522_REG_BIT_FRAMING, 0x80);
    }
    
    uint16_t i = 2000;
    uint8_t n;
    do {
        n = _read_reg(h, RC522_REG_COMM_IRQ);
        i--;
    } while ((i != 0) && !(n & 0x01) && !(n & wait_irq));
    
    _clear_bitmask(h, RC522_REG_BIT_FRAMING, 0x80);
    
    if (i != 0 && !(_read_reg(h, RC522_REG_ERROR) & 0x1B)) {
        status = RC522_OK;
        if (n & irq_en & 0x01) {
            status = RC522_NOTAGERR;
        }
        
        if (command == RC522_PCD_TRANSCEIVE) {
            n = _read_reg(h, RC522_REG_FIFO_LEVEL);
            uint8_t last_bits = _read_reg(h, RC522_REG_CONTROL) & 0x07;
            
            if (last_bits) {
                *back_len = (n - 1) * 8 + last_bits;
            } else {
                *back_len = n * 8;
            }
            
            if (n > 16) n = 16;
            
            for (uint16_t i2 = 0; i2 < n; i2++) {
                back_data[i2] = _read_reg(h, RC522_REG_FIFO_DATA);
            }
        }
    }
    
    return status;
}

static uint8_t _request(rc522_handle_t *h, uint8_t req_mode, uint8_t *tag_type)
{
    uint8_t status;
    uint16_t back_bits;
    
    _write_reg(h, RC522_REG_BIT_FRAMING, 0x07);
    tag_type[0] = req_mode;
    status = _to_card(h, RC522_PCD_TRANSCEIVE, tag_type, 1, tag_type, &back_bits);
    
    if ((status != RC522_OK) || (back_bits != 0x10)) {
        status = RC522_ERR;
    }
    
    return status;
}

static uint8_t _anticoll(rc522_handle_t *h, uint8_t *ser_num)
{
    uint8_t status;
    uint16_t un_len;
    
    _write_reg(h, RC522_REG_BIT_FRAMING, 0x00);
    ser_num[0] = RC522_PICC_ANTICOLL;
    ser_num[1] = 0x20;
    status = _to_card(h, RC522_PCD_TRANSCEIVE, ser_num, 2, ser_num, &un_len);
    
    if (status == RC522_OK) {
        uint8_t check = 0;
        for (uint8_t i = 0; i < 4; i++) {
            check ^= ser_num[i];
        }
        if (check != ser_num[4]) {
            status = RC522_ERR;
        }
    }
    
    return status;
}

static void _halt(rc522_handle_t *h)
{
    uint8_t buff[4];
    uint16_t un_len;
    
    buff[0] = RC522_PICC_HALT;
    buff[1] = 0;
    _calculate_crc(h, buff, 2, &buff[2]);
    _to_card(h, RC522_PCD_TRANSCEIVE, buff, 4, buff, &un_len);
}

static esp_err_t _init_hw(rc522_handle_t *h)
{
    _write_reg(h, RC522_REG_COMMAND, RC522_PCD_RESETPHASE);
    vTaskDelay(pdMS_TO_TICKS(10));
    
    _write_reg(h, RC522_REG_T_MODE, 0x8D);
    _write_reg(h, RC522_REG_T_PRESCALER, 0x3E);
    _write_reg(h, RC522_REG_T_RELOAD_L, 30);
    
    _write_reg(h, RC522_REG_RF_CFG, 0x7F);
    _write_reg(h, RC522_REG_RX_THRESHOLD, 0x84);
    _write_reg(h, RC522_REG_TX_AUTO, 0x40);
    _write_reg(h, RC522_REG_MODE, 0x3D);
    
    if (!(_read_reg(h, RC522_REG_TX_CONTROL) & 0x03)) {
        _set_bitmask(h, RC522_REG_TX_CONTROL, 0x03);
    }
    
    return ESP_OK;
}

// ========== GPIO和SPI配置 ==========
static esp_err_t _configure_gpio(const rc522_config_t *cfg)
{
    gpio_config_t io_cfg = {
        .pin_bit_mask = (1ULL << cfg->cs_io) | (1ULL << cfg->rst_io),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    
    esp_err_t ret = gpio_config(&io_cfg);
    if (ret == ESP_OK) {
        gpio_set_level(cfg->cs_io, 1);
        gpio_set_level(cfg->rst_io, 1);
    }
    
    return ret;
}

static esp_err_t _configure_spi(rc522_handle_t *h, const rc522_config_t *cfg)
{
    spi_bus_config_t buscfg = {
        .miso_io_num = cfg->miso_io,
        .mosi_io_num = cfg->mosi_io,
        .sclk_io_num = cfg->sclk_io,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
    };
    
    esp_err_t ret = spi_bus_initialize(cfg->spi_host, &buscfg, SPI_DMA_CH_AUTO);
    if (ret != ESP_OK) return ret;
    
    spi_device_interface_config_t devcfg = {
        .clock_speed_hz = 1000000,
        .mode = 0,
        .spics_io_num = -1,
        .queue_size = 3,
    };
    
    return spi_bus_add_device(cfg->spi_host, &devcfg, &h->spi);
}

// ========== 卡片读取功能 ==========
static esp_err_t _read_card(rc522_handle_t *h, uint8_t *card_id)
{
    uint8_t status = _request(h, RC522_PICC_REQIDL, card_id);
    if (status != RC522_OK) return ESP_ERR_NOT_FOUND;
    
    status = _anticoll(h, card_id);
    _halt(h);
    
    return (status == RC522_OK) ? ESP_OK : ESP_ERR_NOT_FOUND;
}

// ========== 事件处理 ==========
static void _send_event(rc522_event_t *ev)
{
    if (g_handle->event_cb) {
        g_handle->event_cb(ev, g_handle->user_data);
    }
}

// ========== 防重复检测 ==========
static bool _is_duplicate_card(uint8_t *card_id)
{
    static uint32_t s_last_time = 0;
    uint32_t current_time = xTaskGetTickCount();
    
    if (memcmp(g_handle->last_card_id, card_id, RC522_CARD_ID_SIZE) == 0) {
        if ((current_time - s_last_time) < 50) { // 50ms防抖
            return true;
        }
    }
    
    memcpy(g_handle->last_card_id, card_id, RC522_CARD_ID_SIZE);
    s_last_time = current_time;
    return false;
}

// ========== 检测任务 ==========
static void _detection_task(void *arg)
{
    uint8_t card_id[RC522_CARD_ID_SIZE];
    
    while (1) {
        if (!g_handle->detection_running) {
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }
        
        // 检查录入超时
        if (g_handle->is_enrolling) {
            uint32_t current_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
            if ((current_time - g_handle->enroll_start_time) >= RC522_ENROLL_TIMEOUT_MS) {
                // 录入超时
                rc522_event_t ev;
                memset(&ev, 0, sizeof(ev));
                ev.type = RC522_EVENT_ENROLL_TIMEOUT;
                ev.id = g_handle->enroll_id;
                g_handle->is_enrolling = false;
                _send_event(&ev);
                continue;
            }
        }
        
        // 在录入模式下持续检测卡片
        esp_err_t read_result = _read_card(g_handle, card_id);
        
        if (read_result == ESP_OK) {
            if (!_is_duplicate_card(card_id)) {
                rc522_event_t ev;
                memset(&ev, 0, sizeof(ev));
                memcpy(ev.card_id, card_id, RC522_CARD_ID_SIZE);
                
                if (g_handle->is_enrolling) {
                    // 录入模式
                    if (_add_card(card_id, g_handle->enroll_id) == ESP_OK) {
                        ev.type = RC522_EVENT_CARD_ADDED;
                        ev.id = g_handle->enroll_id;
                        g_handle->is_enrolling = false;
                    } else {
                        ev.type = RC522_EVENT_ERROR;
                        ev.error = ESP_FAIL;
                    }
                    _send_event(&ev);
                } else {
                    // 验证模式
                    int index = _find_card_by_id(card_id);
                    if (index >= 0) {
                        ev.type = RC522_EVENT_CARD_VERIFIED;
                        ev.id = g_handle->cards[index].id;
                    } else {
                        ev.type = RC522_EVENT_CARD_REJECTED;
                    }
                    _send_event(&ev);
                }
            }
        } else if (read_result != ESP_ERR_NOT_FOUND) {
            // 读取错误（不是没有找到卡片的正常情况）
            ESP_LOGE(TAG, "读取卡片失败: %d", read_result);
        }
        
        vTaskDelay(pdMS_TO_TICKS(RC522_SCAN_INTERVAL_MS));
    }
}

// ========== 公共API实现 ==========
esp_err_t rc522_init(const rc522_config_t *cfg)
{
    if (g_handle) return ESP_OK;
    
    g_handle = calloc(1, sizeof(rc522_handle_t));
    if (!g_handle) return ESP_ERR_NO_MEM;
    
    // 设置配置
    if (cfg) {
        memcpy(&g_handle->config, cfg, sizeof(rc522_config_t));
    } else {
        g_handle->config = (rc522_config_t){
            .spi_host = RC522_DEFAULT_SPI_HOST,
            .miso_io = RC522_DEFAULT_MISO_GPIO,
            .mosi_io = RC522_DEFAULT_MOSI_GPIO,
            .sclk_io = RC522_DEFAULT_SCLK_GPIO,
            .cs_io   = RC522_DEFAULT_CS_GPIO,
            .rst_io  = RC522_DEFAULT_RST_GPIO
        };
    }
    
    // 初始化状态
    g_handle->detection_running = false;
    g_handle->is_enrolling = false;
    g_handle->card_count = 0;
    
    // 配置硬件
    esp_err_t ret = _configure_gpio(&g_handle->config);
    if (ret != ESP_OK) goto error;
    
    ret = _configure_spi(g_handle, &g_handle->config);
    if (ret != ESP_OK) goto error;
    
    ret = _init_hw(g_handle);
    if (ret != ESP_OK) goto error;
    
    // 打开NVS并加载卡片
    if (_nvs_open(g_handle) == ESP_OK) {
        _load_cards(g_handle);
    }
    
    // 启动检测任务
    if (xTaskCreate(_detection_task, "rc522", 3072, NULL, 5, &g_handle->detection_task) != pdPASS) {
        ret = ESP_FAIL;
        goto error;
    }
    
    ESP_LOGI(TAG, "RC522初始化成功，卡片数量: %d", g_handle->card_count);
    return ESP_OK;

error:
    free(g_handle);
    g_handle = NULL;
    return ret;
}

void rc522_deinit(void)
{
    if (!g_handle) return;
    
    g_handle->detection_running = false;
    vTaskDelay(pdMS_TO_TICKS(200));
    
    if (g_handle->spi) {
        spi_bus_remove_device(g_handle->spi);
        spi_bus_free(g_handle->config.spi_host);
    }
    
    if (g_handle->nvs_handle) {
        nvs_close(g_handle->nvs_handle);
    }
    
    free(g_handle);
    g_handle = NULL;
}

void rc522_register_callback(rc522_event_callback_t cb, void *user_data)
{
    if (g_handle) {
        g_handle->event_cb = cb;
        g_handle->user_data = user_data;
    }
}

esp_err_t rc522_start_detection(void)
{
    if (!g_handle) return ESP_ERR_INVALID_STATE;
    g_handle->detection_running = true;
    return ESP_OK;
}

esp_err_t rc522_stop_detection(void)
{
    if (!g_handle) return ESP_ERR_INVALID_STATE;
    g_handle->detection_running = false;
    return ESP_OK;
}

esp_err_t rc522_add_card(const uint8_t *card_id, uint8_t id)
{
    if (!g_handle || !card_id) return ESP_ERR_INVALID_ARG;
    return _add_card((uint8_t*)card_id, id);
}

esp_err_t rc522_remove_card(const uint8_t *card_id)
{
    if (!g_handle || !card_id) return ESP_ERR_INVALID_ARG;
    return _remove_card((uint8_t*)card_id);
}

esp_err_t rc522_remove_card_by_id(uint8_t id)
{
    if (!g_handle) return ESP_ERR_INVALID_STATE;
    return _remove_card_by_num(id);
}

esp_err_t rc522_clear_cards(void)
{
    if (!g_handle) return ESP_ERR_INVALID_STATE;
    return _clear_cards();
}

uint8_t rc522_get_card_count(void)
{
    return g_handle ? g_handle->card_count : 0;
}

esp_err_t rc522_read_once(uint8_t *card_id)
{
    if (!g_handle || !card_id) return ESP_ERR_INVALID_ARG;
    return _read_card(g_handle, card_id);
}

esp_err_t rc522_start_enrollment(uint8_t id)
{
    if (!g_handle) return ESP_ERR_INVALID_STATE;
    if (g_handle->is_enrolling) return ESP_ERR_INVALID_STATE;
    
    // 确保检测任务在运行
    if (!g_handle->detection_running) {
        rc522_start_detection();
    }
    
    g_handle->is_enrolling = true;
    g_handle->enroll_id = id;
    g_handle->enroll_start_time = xTaskGetTickCount() * portTICK_PERIOD_MS;
    
    ESP_LOGI(TAG, "开始卡片录入模式，ID: %d, 超时时间: %dms", id, RC522_ENROLL_TIMEOUT_MS);
    return ESP_OK;
}
esp_err_t rc522_cancel_enrollment(void)
{
    if (!g_handle) return ESP_ERR_INVALID_STATE;
    g_handle->is_enrolling = false;
    g_handle->enroll_start_time = 0;  // 重置开始时间
    return ESP_OK;
}

bool rc522_is_enrolling(void)
{
    return g_handle ? g_handle->is_enrolling : false;
}