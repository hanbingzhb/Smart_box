/**
 * *****************************************************************************
 * @file rc522_driver.h
 * @brief RC522 NFC识别驱动 - 极致精简版
 * @version 3.0
 * @date 2025-11-08
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * 
 * @par 修改日志:
 * Date       Version     Author      Description
 * 2025-11-08 3.0         zhanhuangbin  极致精简，优化存储
 * *****************************************************************************
 */

#ifndef __RC522_DRIVER_H__
#define __RC522_DRIVER_H__

#pragma once

#include "esp_err.h"
#include "driver/spi_master.h"
#include "driver/gpio.h"

#define RC522_MAX_CARDS              10      /**< 最大存储卡片数量 */
#define RC522_CARD_ID_SIZE           5       /**< 卡片ID字节数 */
#define RC522_SCAN_INTERVAL_MS       200     /**< 扫描间隔(ms) */
#define RC522_ENROLL_TIMEOUT_MS      10000   /**< 录入超时时间(ms) */

/**
 * 事件类型定义
 */
typedef enum {
    RC522_EVENT_CARD_DETECTED,   /**< 检测到卡片 */
    RC522_EVENT_CARD_VERIFIED,   /**< 卡片验证通过 */
    RC522_EVENT_CARD_REJECTED,   /**< 未注册卡片 */
    RC522_EVENT_CARD_ADDED,      /**< 新卡片已添加 */
    RC522_EVENT_CARD_REMOVED,    /**< 卡片已移除 */
    RC522_EVENT_ENROLL_TIMEOUT,  /**< 录入超时 */
    RC522_EVENT_ERROR            /**< 发生错误 */
} rc522_event_type_t;

/**
 * 事件结构体
 */
typedef struct {
    rc522_event_type_t type;     /**< 事件类型 */
    uint8_t card_id[RC522_CARD_ID_SIZE]; /**< 卡片ID */
    uint8_t id;                  /**< 卡片编号ID */
    esp_err_t error;             /**< 错误代码 */
} rc522_event_t;

/**
 * 事件回调函数类型
 */
typedef void (*rc522_event_callback_t)(rc522_event_t *event, void *user_data);

/**
 * RC522硬件配置结构体
 */
typedef struct {
    spi_host_device_t spi_host;  /**< SPI主机设备 */
    gpio_num_t miso_io;          /**< MISO引脚 */
    gpio_num_t mosi_io;          /**< MOSI引脚 */
    gpio_num_t sclk_io;          /**< SCLK引脚 */
    gpio_num_t cs_io;            /**< 片选引脚 */
    gpio_num_t rst_io;           /**< 复位引脚 */
} rc522_config_t;

// ========== 公共API函数 ==========

esp_err_t rc522_init(const rc522_config_t *cfg);
void rc522_deinit(void);
void rc522_register_callback(rc522_event_callback_t cb, void *user_data);

esp_err_t rc522_start_detection(void);
esp_err_t rc522_stop_detection(void);

esp_err_t rc522_add_card(const uint8_t *card_id, uint8_t id);
esp_err_t rc522_remove_card(const uint8_t *card_id);
esp_err_t rc522_remove_card_by_id(uint8_t id);
esp_err_t rc522_clear_cards(void);

uint8_t rc522_get_card_count(void);
esp_err_t rc522_read_once(uint8_t *card_id);

esp_err_t rc522_start_enrollment(uint8_t id);
esp_err_t rc522_cancel_enrollment(void);
bool rc522_is_enrolling(void);

#endif