/**
 * *****************************************************************************
 * @file smartlock_mqtt.c
 * @brief 智能储物柜MQTT管理器实现
 * @version 1.0
 * @date 2025-11-08
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * *****************************************************************************
 */

#include "smartlock_mqtt.h"
#include "esp_log.h"
#include "esp_system.h"
#include "string.h"
#include "mqtt_client.h"

static const char *TAG = "SmartLock_MQTT";

static esp_mqtt_client_handle_t g_mqtt_client = NULL;
static bool g_mqtt_connected = false;

// 智能门锁相关变量
static char g_device_id[32] = {0};
static char g_cmd_topic[64] = {0};
static char g_ack_topic[64] = {0};
static char g_info_topic[64] = {0};
static mqtt_command_callback_t g_command_callback = NULL;

// MQTT事件处理
static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data)
{
    esp_mqtt_event_handle_t event = event_data;
    
    switch (event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "MQTT连接成功");
            g_mqtt_connected = true;
            // 连接成功后订阅命令主题
            if (g_cmd_topic[0] != '\0') {
                mqtt_subscribe(g_cmd_topic, 1);
            }
            break;
            
        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGI(TAG, "MQTT连接断开");
            g_mqtt_connected = false;
            break;
            
        case MQTT_EVENT_SUBSCRIBED:
            ESP_LOGI(TAG, "订阅成功, msg_id=%d", event->msg_id);
            break;
            
        case MQTT_EVENT_UNSUBSCRIBED:
            ESP_LOGI(TAG, "取消订阅成功, msg_id=%d", event->msg_id);
            break;
            
        case MQTT_EVENT_PUBLISHED:
            ESP_LOGI(TAG, "消息发布成功, msg_id=%d", event->msg_id);
            break;
            
            case MQTT_EVENT_DATA:
                ESP_LOGI(TAG, "收到消息, topic=%.*s, data=%.*s", 
                event->topic_len, event->topic,
                event->data_len, event->data);
    
                if (event->topic && event->data) {
                    // 安全地复制数据，确保null终止
                    char *topic = malloc(event->topic_len + 1);
                    char *data = malloc(event->data_len + 1);
        
                    if (topic && data) {
                        memcpy(topic, event->topic, event->topic_len);
                        topic[event->topic_len] = '\0';
                        memcpy(data, event->data, event->data_len);
                        data[event->data_len] = '\0';
            
                        // 处理智能门锁消息
                        if (strstr(topic, g_cmd_topic)) {
                            cJSON *root = cJSON_Parse(data);
                            if (!root) {
                                ESP_LOGE(TAG, "解析JSON失败: %s", data);
                            } else {
                                cJSON *pkg = cJSON_GetObjectItem(root, "pkg");
                                cJSON *cmd = cJSON_GetObjectItem(root, "cmd");
                    
                                if (pkg && cmd && strcmp(pkg->valuestring, "cmd") == 0) {
                                    ESP_LOGI(TAG, "处理MQTT命令: %s", cmd->valuestring);
                        
                                    if (g_command_callback) {
                                        g_command_callback(cmd->valuestring, root);
                                    }
                                }
                    
                                cJSON_Delete(root);
                            }
                        }

                        free(topic);
                        free(data);
                    } else {
                        ESP_LOGE(TAG, "内存分配失败");
                    }
                }
        break;
            
        case MQTT_EVENT_ERROR:
            ESP_LOGE(TAG, "MQTT错误");
            if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
                ESP_LOGE(TAG, "传输错误: errno=%d", event->error_handle->esp_transport_sock_errno);
                ESP_LOGE(TAG, "传输错误: esp_tls_last_esp_err=0x%x", event->error_handle->esp_tls_last_esp_err);
            }
        break;
            
        default:
            break;
    }
}

esp_err_t mqtt_client_init(mqtt_config_t *config)
{
    if (!config) {
        ESP_LOGE(TAG, "MQTT配置为空");
        return ESP_ERR_INVALID_ARG;
    }
    
    ESP_LOGI(TAG, "初始化MQTT客户端");
    ESP_LOGI(TAG, "服务器: %s", config->uri);
    ESP_LOGI(TAG, "客户端ID: %s", config->client_id);
    
    esp_mqtt_client_config_t mqtt_cfg = {
        .broker.address.uri = config->uri,
        .credentials.client_id = config->client_id,
        .credentials.username = config->username,
        .credentials.authentication.password = config->password,
        .session.keepalive = config->keepalive,
        .network.disable_auto_reconnect = false,  // 启用自动重连
        .network.reconnect_timeout_ms = 10000,    // 重连超时
    };
    
    // 如果是SSL连接，配置证书验证
    if (config->use_ssl) {
        mqtt_cfg.broker.verification.certificate = config->cert_pem;
        mqtt_cfg.network.timeout_ms = 30000;  // SSL连接需要更长时间
    }
    
    g_mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    if (!g_mqtt_client) {
        ESP_LOGE(TAG, "MQTT客户端初始化失败");
        return ESP_FAIL;
    }
    
    // 注册事件处理器
    esp_mqtt_client_register_event(g_mqtt_client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    
    return ESP_OK;
}

esp_err_t mqtt_client_start(void)
{
    if (!g_mqtt_client) {
        ESP_LOGE(TAG, "MQTT客户端未初始化");
        return ESP_ERR_INVALID_STATE;
    }
    
    ESP_LOGI(TAG, "启动MQTT客户端");
    esp_err_t ret = esp_mqtt_client_start(g_mqtt_client);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动MQTT客户端失败: 0x%x", ret);
    }
    
    return ret;
}

esp_err_t mqtt_client_stop(void)
{
    if (!g_mqtt_client) {
        return ESP_OK;
    }
    
    ESP_LOGI(TAG, "停止MQTT客户端");
    esp_err_t ret = esp_mqtt_client_stop(g_mqtt_client);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "停止MQTT客户端失败: 0x%x", ret);
    }
    
    g_mqtt_connected = false;
    return ret;
}

int mqtt_publish(const char* topic, const char* data, int len, int qos, int retain)
{
    if (!g_mqtt_client || !g_mqtt_connected) {
        ESP_LOGE(TAG, "MQTT未连接，无法发布消息");
        return -1;
    }
    
    if (!topic || !data) {
        ESP_LOGE(TAG, "主题或数据为空");
        return -1;
    }
    
    int msg_id = esp_mqtt_client_publish(g_mqtt_client, topic, data, len, qos, retain);
    if (msg_id < 0) {
        ESP_LOGE(TAG, "发布消息失败");
    }
    
    return msg_id;
}

int mqtt_subscribe(const char* topic, int qos)
{
    if (!g_mqtt_client || !g_mqtt_connected) {
        ESP_LOGE(TAG, "MQTT未连接，无法订阅");
        return -1;
    }
    
    if (!topic) {
        ESP_LOGE(TAG, "主题为空");
        return -1;
    }
    
    int msg_id = esp_mqtt_client_subscribe(g_mqtt_client, topic, qos);
    if (msg_id < 0) {
        ESP_LOGE(TAG, "订阅主题失败: %s", topic);
    } else {
        ESP_LOGI(TAG, "订阅主题: %s", topic);
    }
    
    return msg_id;
}

int mqtt_unsubscribe(const char* topic)
{
    if (!g_mqtt_client || !g_mqtt_connected) {
        ESP_LOGE(TAG, "MQTT未连接，无法取消订阅");
        return -1;
    }
    
    if (!topic) {
        ESP_LOGE(TAG, "主题为空");
        return -1;
    }
    
    int msg_id = esp_mqtt_client_unsubscribe(g_mqtt_client, topic);
    if (msg_id < 0) {
        ESP_LOGE(TAG, "取消订阅失败: %s", topic);
    }
    
    return msg_id;
}

bool mqtt_is_connected(void)
{
    return g_mqtt_connected;
}

esp_err_t smartlock_mqtt_init(const char* device_id)
{
    if (!device_id) {
        ESP_LOGE(TAG, "设备ID为空");
        return ESP_ERR_INVALID_ARG;
    }
    
    strncpy(g_device_id, device_id, sizeof(g_device_id) - 1);
    
    // 构建主题
    snprintf(g_cmd_topic, sizeof(g_cmd_topic), "device/%s/cmd", device_id);
    snprintf(g_ack_topic, sizeof(g_ack_topic), "device/%s/ack", device_id);
    snprintf(g_info_topic, sizeof(g_info_topic), "device/%s/ack", device_id);
    
    ESP_LOGI(TAG, "初始化智能门锁MQTT, 设备ID: %s", device_id);
    ESP_LOGI(TAG, "命令主题: %s", g_cmd_topic);
    ESP_LOGI(TAG, "应答主题: %s", g_ack_topic);
    ESP_LOGI(TAG, "状态主题: %s", g_info_topic);
    
    return ESP_OK;
}

esp_err_t smartlock_mqtt_start(void)
{
    ESP_LOGI(TAG, "启动智能储物柜MQTT服务");
    
    // 如果已经连接，订阅命令主题
    if (g_mqtt_connected) {
        int ret = mqtt_subscribe(g_cmd_topic, 1);
        if (ret < 0) {
            ESP_LOGE(TAG, "订阅命令主题失败");
            return ESP_FAIL;
        }
    }
    
    // 发送上线状态
    mqtt_send_info("device_online", "system", 0);
    
    return ESP_OK;
}

esp_err_t smartlock_mqtt_stop(void)
{
    ESP_LOGI(TAG, "停止智能储物柜MQTT服务");
    
    // 发送离线状态
    mqtt_send_info("device_offline", "system", 0);
    
    // 取消订阅
    if (g_mqtt_connected) {
        mqtt_unsubscribe(g_cmd_topic);
    }
    
    return ESP_OK;
}

esp_err_t mqtt_send_ack(const char* app, const char* result, const char* message)
{
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "pkg", "ack");
    cJSON_AddStringToObject(root, "app", app);
    cJSON_AddStringToObject(root, "result", result);
    
    if (message && strlen(message) > 0) {
        cJSON_AddStringToObject(root, "message", message);
    }
    
    const char *json_str = cJSON_PrintUnformatted(root);
    int ret = mqtt_publish(g_ack_topic, json_str, strlen(json_str), 1, 0);
    
    cJSON_Delete(root);
    free((void*)json_str);
    
    return (ret >= 0) ? ESP_OK : ESP_FAIL;
}

esp_err_t mqtt_send_info(const char* event, const char* method, uint32_t user_id)
{
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "pkg", "info");
    cJSON_AddStringToObject(root, "event", event);
    
    const char *json_str = cJSON_PrintUnformatted(root);
    int ret = mqtt_publish(g_info_topic, json_str, strlen(json_str), 1, 0);
    
    cJSON_Delete(root);
    free((void*)json_str);
    
    return (ret >= 0) ? ESP_OK : ESP_FAIL;
}

void smartlock_set_command_callback(mqtt_command_callback_t callback)
{
    g_command_callback = callback;
}