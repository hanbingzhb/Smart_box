/**
 * *****************************************************************************
 * @file smartlock_mqtt.h
 * @brief 智能储物柜MQTT管理器
 * @version 1.0
 * @date 2025-11-08
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * *****************************************************************************
 */

#ifndef __SMARTLOCK_MQTT_H__
#define __SMARTLOCK_MQTT_H__

#include "esp_err.h"
#include "cJSON.h"
#include "mqtt_client.h"

#ifdef __cplusplus
extern "C" {
#endif

// MQTT配置结构体
typedef struct {
    char uri[128];
    char client_id[64];
    char username[64];
    char password[64];
    char cert_pem[2048];
    int keepalive;
    bool use_ssl;
} mqtt_config_t;

// MQTT命令回调
typedef esp_err_t (*mqtt_command_callback_t)(const char* cmd, cJSON* params);

/**
 * @brief 初始化MQTT客户端
 * @param config MQTT配置
 * @return esp_err_t 错误代码
 */
esp_err_t mqtt_client_init(mqtt_config_t *config);

/**
 * @brief 启动MQTT客户端
 * @return esp_err_t 错误代码
 */
esp_err_t mqtt_client_start(void);

/**
 * @brief 停止MQTT客户端
 * @return esp_err_t 错误代码
 */
esp_err_t mqtt_client_stop(void);

/**
 * @brief 发布MQTT消息
 * @param topic 主题
 * @param data 数据
 * @param len 数据长度
 * @param qos QoS等级
 * @param retain 保留标志
 * @return int 消息ID
 */
int mqtt_publish(const char* topic, const char* data, int len, int qos, int retain);

/**
 * @brief 订阅MQTT主题
 * @param topic 主题
 * @param qos QoS等级
 * @return int 消息ID
 */
int mqtt_subscribe(const char* topic, int qos);

/**
 * @brief 取消订阅MQTT主题
 * @param topic 主题
 * @return int 消息ID
 */
int mqtt_unsubscribe(const char* topic);

/**
 * @brief 检查MQTT连接状态
 * @return bool 连接状态
 */
bool mqtt_is_connected(void);

/**
 * @brief 初始化智能储物柜MQTT
 * @param device_id 设备ID
 * @return esp_err_t 错误代码
 */
esp_err_t smartlock_mqtt_init(const char* device_id);

/**
 * @brief 启动MQTT服务
 * @return esp_err_t 错误代码
 */
esp_err_t smartlock_mqtt_start(void);

/**
 * @brief 停止MQTT服务
 * @return esp_err_t 错误代码
 */
esp_err_t smartlock_mqtt_stop(void);

/**
 * @brief 发送应答包
 * @param app 应用名称
 * @param result 结果(success/failed)
 * @param message 消息(可选)
 * @return esp_err_t 错误代码
 */
esp_err_t mqtt_send_ack(const char* app, const char* result, const char* message);

/**
 * @brief 发送状态包
 * @param event 事件
 * @param method 方法
 * @param user_id 用户ID(可选)
 * @return esp_err_t 错误代码
 */
esp_err_t mqtt_send_info(const char* event, const char* method, uint32_t user_id);

/**
 * @brief 设置命令回调
 * @param callback 回调函数
 */
void smartlock_set_command_callback(mqtt_command_callback_t callback);

#ifdef __cplusplus
}
#endif

#endif /* __SMARTLOCK_MQTT_H__ */