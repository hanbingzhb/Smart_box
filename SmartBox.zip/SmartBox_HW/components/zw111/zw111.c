/**
 * *****************************************************************************
 * @file zw111.c
 * @brief 
 * @version 1.0
 * @date 2025-11-02
 * 
 * @copyright Copyright (c) 2025  zhanhuangbin
 * 
 * @par 修改日志:
 * Date       Version     Author      Description
 * 2025-11-02 1.0         zhanhuangbin  初始版本
 * 2025-11-02 1.0         zhanhuangbin  基本功能实现
 * 2025-11-07 1.0         zhanhuangbin  增加低功耗控制
 * 2025-11-08 1.0         zhanhuangbin  修复UART重复安装和电源管理问题
 * 2025-11-08 1.0         zhanhuangbin  增加阻塞机制
 * *****************************************************************************
 */

#include "zw111.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "string.h"

static const char *TAG = "ZW111";

// ========== 模块内部状态 ==========
static struct {
    zw111_state_t state;                      // 当前状态
    zw111_callback_t verify_callback;         // 验证回调函数
    zw111_callback_t enroll_callback;         // 录入回调函数
    uint16_t enroll_user_id;                  // 录入用户ID
    TaskHandle_t task_handle;                 // 任务句柄
    QueueHandle_t event_queue;                // 事件队列
    SemaphoreHandle_t operation_mutex;        // 操作互斥锁
    SemaphoreHandle_t enroll_complete_sem;    // 录入完成信号量
    bool initialized;                         // 初始化标志
    bool uart_initialized;                    // UART初始化标志
    uint32_t device_addr;                     // 设备地址
    esp_timer_handle_t timeout_timer;         // 超时定时器
    bool power_on;                            // 电源状态
    uint64_t last_touch_time;                 // 最后触摸时间 (防抖)
    esp_err_t enroll_result;                  // 录入结果
    bool enroll_in_progress;                  // 录入进行中标志
    zw111_enroll_progress_callback_t enroll_progress_callback;
} zw111_ctx = {
    .state = ZW111_STATE_POWER_OFF,
    .verify_callback = NULL,
    .enroll_callback = NULL,
    .enroll_user_id = 0,
    .task_handle = NULL,
    .event_queue = NULL,
    .operation_mutex = NULL,
    .enroll_complete_sem = NULL,
    .initialized = false,
    .uart_initialized = false,
    .device_addr = ZW111_DEFAULT_ADDR,
    .timeout_timer = NULL,
    .power_on = false,
    .last_touch_time = 0,
    .enroll_result = ESP_FAIL,
    .enroll_in_progress = false,
    .enroll_progress_callback = NULL
};

// ========== 内部函数声明 ==========
static esp_err_t zw111_power_on(void);
static esp_err_t zw111_power_off(void);
static bool zw111_check_touch(void);
static esp_err_t zw111_uart_init(void);
static esp_err_t zw111_uart_deinit(void);
static esp_err_t zw111_send_package(uint8_t pkg_id, const uint8_t *data, uint16_t data_len);
static esp_err_t zw111_receive_package(uint8_t *pkg_id, uint8_t *data, uint16_t *data_len, uint32_t timeout_ms);
static esp_err_t zw111_send_command(uint8_t cmd, const uint8_t *params, uint8_t param_len, 
                                   uint8_t *response, uint16_t *resp_len);
static uint16_t zw111_calculate_checksum(const uint8_t *data, uint16_t len);
static esp_err_t zw111_wait_for_wakeup(void);
static uint16_t zw111_allocate_user_id(void);
static void zw111_timeout_callback(void* arg);
static void zw111_task(void *arg);
static void zw111_clear_uart_buffer(void);
static esp_err_t zw111_perform_enrollment(uint16_t user_id, uint32_t timeout_ms,
                                   zw111_enroll_progress_callback_t progress_callback);

// ========== 电源管理函数 ==========

/**
 * @brief 初始化电源控制引脚
 */
static esp_err_t zw111_init_power_control(void) {
    ESP_LOGI(TAG, "初始化电源控制引脚");
    
    // 先配置电源控制引脚为输出，并设置为高电平（断电状态）
    gpio_config_t power_pin_cfg = {
        .pin_bit_mask = (1ULL << ZW111_POWER_CONTROL_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&power_pin_cfg);
    
    // 设置为高电平，确保指纹模块断电
    gpio_set_level(ZW111_POWER_CONTROL_PIN, 1);
    
    // 短暂延时确保电源稳定关闭
    vTaskDelay(pdMS_TO_TICKS(50));
    
    ESP_LOGI(TAG, "电源控制引脚初始化完成，初始状态: 断电");
    return ESP_OK;
}


/**
 * @brief 打开指纹模块电源
 */
static esp_err_t zw111_power_on(void) {
    ESP_LOGI(TAG, "打开指纹模块电源（模拟）");
    zw111_ctx.power_on = true;
    zw111_ctx.state = ZW111_STATE_IDLE;
    if (!zw111_ctx.uart_initialized) {
        zw111_uart_init();
        zw111_ctx.uart_initialized = true;
    }
    return ESP_OK;
}

/**
 * @brief 关闭指纹模块电源
 */
static esp_err_t zw111_power_off(void) {
    ESP_LOGI(TAG, "关闭指纹模块电源（模拟）");
    zw111_ctx.power_on = false;          // 标志为断电状态
    zw111_ctx.state = ZW111_STATE_POWER_OFF;  // 状态重置
    return ESP_OK;
}

/**
 * @brief 强制关闭指纹模块电源 (用于初始化等场景)
 */
static esp_err_t zw111_force_power_off(void) {
    ESP_LOGI(TAG, "强制关闭指纹模块电源");
    
    // 直接设置为高电平断电，不发送任何命令
    gpio_set_level(ZW111_POWER_CONTROL_PIN, 1);
    
    // 短暂延时确保电源断开
    vTaskDelay(pdMS_TO_TICKS(100));
    
    zw111_ctx.power_on = false;
    zw111_ctx.state = ZW111_STATE_POWER_OFF;
    
    ESP_LOGI(TAG, "指纹模块强制断电完成");
    return ESP_OK;
}

/**
 * @brief 检查触摸信号 (带防抖)
 */
static bool zw111_check_touch(void) {
    if (zw111_ctx.enroll_in_progress) {
        return false;
    }
    // 简单防抖：连续两次读取都为高才认为有效
    static uint32_t last_high_time = 0;
    bool current = (gpio_get_level(ZW111_TOUCH_CHECK_PIN) == 1);
    if (current) {
        uint32_t now = esp_timer_get_time() / 1000;
        if (last_high_time == 0) {
            last_high_time = now;
            return false;
        } else if ((now - last_high_time) > 50) {  // 50ms防抖
            return true;
        }
    } else {
        last_high_time = 0;
    }
    return false;
}

/**
 * @brief 清空UART缓冲区
 */
static void zw111_clear_uart_buffer(void) {
    uint8_t dummy;
    while (uart_read_bytes(ZW111_UART_PORT, &dummy, 1, 0) > 0) {
        // 清空所有可用数据
    }
}

// ========== UART通信函数 ==========

/**
 * @brief 初始化UART接口
 */
static esp_err_t zw111_uart_init(void) {
    if (zw111_ctx.uart_initialized) {
        ESP_LOGW(TAG, "UART已经初始化");
        return ESP_OK;
    }
    
    // 先尝试卸载驱动 (确保干净状态)
    uart_driver_delete(ZW111_UART_PORT);
    vTaskDelay(pdMS_TO_TICKS(50));
    
    uart_config_t uart_config = {
        .baud_rate = ZW111_UART_BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    
    esp_err_t ret = uart_param_config(ZW111_UART_PORT, &uart_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "UART参数配置失败: 0x%x", ret);
        return ret;
    }
    
    ret = uart_set_pin(ZW111_UART_PORT, ZW111_UART_TX_PIN, ZW111_UART_RX_PIN, 
                       UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "UART引脚配置失败: 0x%x", ret);
        return ret;
    }
    
    ret = uart_driver_install(ZW111_UART_PORT, ZW111_UART_BUF_SIZE, 
                             ZW111_UART_BUF_SIZE, 0, NULL, 0);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "UART驱动安装失败: 0x%x", ret);
        return ret;
    }
    
    // 清空缓冲区
    zw111_clear_uart_buffer();
    
    zw111_ctx.uart_initialized = true;
    ESP_LOGI(TAG, "UART初始化成功");
    return ESP_OK;
}

/**
 * @brief 反初始化UART接口
 */
static esp_err_t zw111_uart_deinit(void) {
    if (!zw111_ctx.uart_initialized) {
        return ESP_OK;
    }
    
    ESP_LOGI(TAG, "反初始化UART");
    uart_driver_delete(ZW111_UART_PORT);
    zw111_ctx.uart_initialized = false;
    return ESP_OK;
}

/**
 * @brief 计算校验和
 */
static uint16_t zw111_calculate_checksum(const uint8_t *data, uint16_t len) {
    uint16_t sum = 0;
    for (int i = 0; i < len; i++) {
        sum += data[i];
    }
    return sum;
}

/**
 * @brief 发送数据包
 */
static esp_err_t zw111_send_package(uint8_t pkg_id, const uint8_t *data, uint16_t data_len) {
    uint8_t buf[ZW111_UART_BUF_SIZE];
    uint16_t idx = 0;

    // 1. 包头 (0xEF01)
    buf[idx++] = ZW111_HEADER_HIGH;
    buf[idx++] = ZW111_HEADER_LOW;

    // 2. 设备地址 (4 bytes)
    buf[idx++] = (zw111_ctx.device_addr >> 24) & 0xFF;
    buf[idx++] = (zw111_ctx.device_addr >> 16) & 0xFF;
    buf[idx++] = (zw111_ctx.device_addr >> 8) & 0xFF;
    buf[idx++] = zw111_ctx.device_addr & 0xFF;

    // 3. 包标识 (1 byte)
    buf[idx++] = pkg_id;

    // 4. 包长度 (2 bytes) = 数据长度 + 2 (校验和)
    uint16_t pkg_len = data_len + 2;
    buf[idx++] = (pkg_len >> 8) & 0xFF;
    buf[idx++] = pkg_len & 0xFF;

    // 5. 数据 (data_len bytes)
    if (data && data_len) {
        memcpy(&buf[idx], data, data_len);
        idx += data_len;
    }

    // 6. 校验和 (2 bytes)
    uint16_t sum = zw111_calculate_checksum(&buf[6], 3 + data_len);
    buf[idx++] = (sum >> 8) & 0xFF;
    buf[idx++] = sum & 0xFF;

    int sent = uart_write_bytes(ZW111_UART_PORT, (const char*)buf, idx);
    if (sent != idx) {
        ESP_LOGE(TAG, "UART写入失败，期望%d字节，实际%d字节", idx, sent);
        return ESP_FAIL;
    }

    esp_err_t ret = uart_wait_tx_done(ZW111_UART_PORT, pdMS_TO_TICKS(100));
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "UART发送完成等待超时");
        return ESP_FAIL;
    }
    
    return ESP_OK;
}

/**
 * @brief 接收数据包
 */
static esp_err_t zw111_receive_package(uint8_t *pkg_id, uint8_t *data, uint16_t *data_len, uint32_t timeout_ms) {
    uint8_t header[9];
    uint8_t checksum_buf[2];
    int64_t start_time = esp_timer_get_time();
    int read_len;

    // 循环查找包头 0xEF01
    while (esp_timer_get_time() - start_time < (int64_t)timeout_ms * 1000) {
        int remaining_time = timeout_ms - (esp_timer_get_time() - start_time) / 1000;
        if (remaining_time <= 0) return ESP_ERR_TIMEOUT;
        
        read_len = uart_read_bytes(ZW111_UART_PORT, header, 1, pdMS_TO_TICKS(remaining_time));
        if (read_len != 1) continue;

        if (header[0] == ZW111_HEADER_HIGH) {
            remaining_time = timeout_ms - (esp_timer_get_time() - start_time) / 1000;
            if (remaining_time <= 0) return ESP_ERR_TIMEOUT;
            
            read_len = uart_read_bytes(ZW111_UART_PORT, &header[1], 1, pdMS_TO_TICKS(remaining_time));
            if (read_len == 1 && header[1] == ZW111_HEADER_LOW) {
                break; // 包头匹配
            }
        }
    }

    if (header[0] != ZW111_HEADER_HIGH || header[1] != ZW111_HEADER_LOW) {
        ESP_LOGE(TAG, "未找到数据包头");
        return ESP_ERR_TIMEOUT;
    }

    // 读取剩余包头
    int remaining_time = timeout_ms - (esp_timer_get_time() - start_time) / 1000;
    if (remaining_time <= 0) return ESP_ERR_TIMEOUT;
    
    read_len = uart_read_bytes(ZW111_UART_PORT, &header[2], 7, pdMS_TO_TICKS(remaining_time));
    if (read_len != 7) {
        ESP_LOGE(TAG, "读取包头失败，已读取%d/7字节", read_len);
        return ESP_FAIL;
    }

    // 解析包标识和长度
    *pkg_id = header[6];
    uint16_t pkg_len = (header[7] << 8) | header[8];
    uint16_t data_length = pkg_len > 2 ? pkg_len - 2 : 0;
    
    if (data_length > ZW111_UART_BUF_SIZE) {
        ESP_LOGE(TAG, "数据包长度过大: %d", data_length);
        return ESP_FAIL;
    }
    
    // 读取数据
    if (data_length > 0) {
        if (!data) return ESP_FAIL;
        remaining_time = timeout_ms - (esp_timer_get_time() - start_time) / 1000;
        if (remaining_time <= 0) return ESP_ERR_TIMEOUT;

        read_len = uart_read_bytes(ZW111_UART_PORT, data, data_length, pdMS_TO_TICKS(remaining_time));
        if (read_len != data_length) {
            ESP_LOGE(TAG, "读取数据失败，期望%d字节，实际%d字节", data_length, read_len);
            return ESP_FAIL;
        }
    }
    *data_len = data_length;

    // 读取校验和
    remaining_time = timeout_ms - (esp_timer_get_time() - start_time) / 1000;
    if (remaining_time <= 0) return ESP_ERR_TIMEOUT;
    
    read_len = uart_read_bytes(ZW111_UART_PORT, checksum_buf, 2, pdMS_TO_TICKS(remaining_time));
    if (read_len != 2) {
        ESP_LOGE(TAG, "读取校验和失败");
        return ESP_FAIL;
    }
    
    uint16_t recv_sum = (checksum_buf[0] << 8) | checksum_buf[1];

    // 验证校验和
    uint16_t calc_sum = zw111_calculate_checksum(&header[6], 3); // PkgID + PkgLen
    if (data_length > 0) {
        calc_sum += zw111_calculate_checksum(data, data_length);
    }

    if (calc_sum != recv_sum) {
        ESP_LOGE(TAG, "校验和错误，接收: 0x%04X，计算: 0x%04X", recv_sum, calc_sum);
        return ESP_FAIL;
    }

    return ESP_OK;
}

/**
 * @brief 发送命令并等待应答
 */
static esp_err_t zw111_send_command(uint8_t cmd, const uint8_t *params, uint8_t param_len, 
                                   uint8_t *response, uint16_t *resp_len) {
    uint8_t data[256];
    uint8_t idx = 0;
    
    // 组装命令包: [CMD] [PARAMS]
    data[idx++] = cmd;
    if (params && param_len) {
        memcpy(&data[idx], params, param_len);
        idx += param_len;
    }
    
    // 发送命令包
    esp_err_t ret = zw111_send_package(ZW111_PKG_CMD, data, idx);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "发送命令0x%02X失败", cmd);
        return ret;
    }

    // 多步骤命令由上层处理
    if (cmd == ZW111_CMD_AUTO_ENROLL || cmd == ZW111_CMD_AUTO_IDENTIFY) {
        ESP_LOGI(TAG, "多步骤命令0x%02X已发送，等待上层处理", cmd);
        return ESP_OK;
    }

    // 单步命令，接收应答包
    uint8_t pkg_id;
    uint8_t recv_buf[ZW111_UART_BUF_SIZE];
    uint16_t recv_data_len;
    
    ret = zw111_receive_package(&pkg_id, recv_buf, &recv_data_len, ZW111_COMMAND_TIMEOUT);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "接收命令0x%02X的响应失败", cmd);
        return ret;
    }

    if (pkg_id != ZW111_PKG_ACK) {
        ESP_LOGE(TAG, "命令0x%02X收到非ACK数据包0x%02X", cmd, pkg_id);
        return ESP_FAIL;
    }
    
    if (recv_data_len < 1) {
        ESP_LOGE(TAG, "命令0x%02X的ACK数据包过短", cmd);
        return ESP_FAIL;
    }

    uint8_t ack_code = recv_buf[0];
    if (ack_code != ZW111_OK) {
        ESP_LOGE(TAG, "命令0x%02X执行失败，错误代码: 0x%02X", cmd, ack_code);
        return (esp_err_t)ack_code;
    }

    // 返回数据
    if (response && resp_len) {
        uint16_t data_to_copy = recv_data_len - 1;
        if (data_to_copy > 0) {
            memcpy(response, &recv_buf[1], data_to_copy);
        }
        *resp_len = data_to_copy;
    }
    
    ESP_LOGI(TAG, "命令0x%02X执行成功", cmd);
    return ESP_OK;
}

// ========== 业务逻辑函数 ==========

/**
 * @brief 等待模块唤醒
 */
static esp_err_t zw111_wait_for_wakeup(void) {
    ESP_LOGI(TAG, "等待指纹模块唤醒");
    
    // 清空UART缓冲区
    zw111_clear_uart_buffer();
    
    // 尝试发送握手指令，直到收到应答
    for (int retry = 0; retry < 5; retry++) {
        uint8_t handshake = ZW111_CMD_HANDSHAKE; // 需要定义 0x35
        esp_err_t ret = zw111_send_package(ZW111_PKG_CMD, &handshake, 1);
        if (ret != ESP_OK) {
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }
        
        uint8_t pkg_id;
        uint8_t response[10];
        uint16_t resp_len;
        ret = zw111_receive_package(&pkg_id, response, &resp_len, 500);
        if (ret == ESP_OK && pkg_id == ZW111_PKG_ACK && response[0] == ZW111_OK) {
            ESP_LOGI(TAG, "指纹模块唤醒成功");
            return ESP_OK;
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    
    ESP_LOGW(TAG, "模块未响应握手，尝试继续");
    return ESP_OK; // 仍返回成功，后续指令可能会失败
}

/**
 * @brief 分配用户ID
 */
static uint16_t zw111_allocate_user_id(void) {
    nvs_handle_t nvs_handle;
    uint16_t next_user_id = 1;
    
    // 打开NVS命名空间
    esp_err_t err = nvs_open("zw111_storage", NVS_READWRITE, &nvs_handle);
    if (err == ESP_OK) {
        // 读取下一个用户ID
        nvs_get_u16(nvs_handle, "next_user_id", &next_user_id);
        
        // 更新用户ID
        next_user_id++;
        nvs_set_u16(nvs_handle, "next_user_id", next_user_id);
        nvs_commit(nvs_handle);
        nvs_close(nvs_handle);
    }
    
    ESP_LOGI(TAG, "分配用户ID: %u", next_user_id);
    return next_user_id;
}

/**
 * @brief 超时回调函数
 */
static void zw111_timeout_callback(void* arg) {
    ESP_LOGI(TAG, "操作超时，关闭电源");
    zw111_power_off();
    
    // 如果正在录入，设置录入结果
    if (zw111_ctx.enroll_in_progress) {
        zw111_ctx.enroll_result = ESP_ERR_TIMEOUT;
        xSemaphoreGive(zw111_ctx.enroll_complete_sem);
    }
}

/**
 * @brief 启动超时定时器
 */
static esp_err_t zw111_start_timeout_timer(uint32_t timeout_ms) {
    if (zw111_ctx.timeout_timer == NULL) {
        esp_timer_create_args_t timer_args = {
            .callback = zw111_timeout_callback,
            .arg = NULL,
            .name = "zw111_timeout"
        };
        esp_err_t ret = esp_timer_create(&timer_args, &zw111_ctx.timeout_timer);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "创建超时定时器失败: 0x%x", ret);
            return ret;
        }
    }
    
    return esp_timer_start_once(zw111_ctx.timeout_timer, timeout_ms * 1000);
}

/**
 * @brief 指纹验证流程
 */
static void zw111_verification_process(void) {
    ESP_LOGI(TAG, "开始指纹验证流程");
    
    zw111_search_result_t result;
    uint8_t recv_buf[16];
    uint16_t recv_data_len;
    uint8_t pkg_id;
    int64_t start_time = esp_timer_get_time();
    esp_err_t final_ret = ESP_FAIL;  // 记录最终结果
    
    uint8_t params[5] = {0x02, 0xFF, 0xFF, 0x00, 0x01};
    esp_err_t ret = zw111_send_command(ZW111_CMD_AUTO_IDENTIFY, params, 5, NULL, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动自动验证失败: 0x%x", ret);
        final_ret = ret;
        goto exit_verify;  // 使用 goto 统一清理
    }
    
    while (esp_timer_get_time() - start_time < ZW111_VERIFY_TIMEOUT * 1000) {
        ret = zw111_receive_package(&pkg_id, recv_buf, &recv_data_len, 100);
        if (ret == ESP_ERR_TIMEOUT) continue;
        if (ret != ESP_OK) continue;
        if (pkg_id != ZW111_PKG_ACK || recv_data_len < 1) continue;
        
        uint8_t ack_code = recv_buf[0];
        switch(ack_code) {
            case ZW111_OK:
                if (recv_data_len >= 6 && recv_buf[1] == 0x05) {
                    result.page_id = (recv_buf[2] << 8) | recv_buf[3];
                    result.score = (recv_buf[4] << 8) | recv_buf[5];
                    ESP_LOGI(TAG, "指纹验证成功，用户ID: %u，匹配分数: %u", result.page_id, result.score);
                    if (zw111_ctx.verify_callback) {
                        zw111_ctx.verify_callback(result.page_id, result.score, ESP_OK);
                    }
                    final_ret = ESP_OK;
                    goto exit_verify;
                }
                break;
                
            case ZW111_ERR_NOT_FOUND:
                ESP_LOGI(TAG, "指纹验证失败: 未找到匹配指纹");
                if (zw111_ctx.verify_callback) {
                    zw111_ctx.verify_callback(0, 0, ESP_FAIL);
                }
                final_ret = ESP_FAIL;
                goto exit_verify;
                
            case ZW111_ERR_TIMEOUT:
                ESP_LOGI(TAG, "指纹验证失败: 操作超时");
                if (zw111_ctx.verify_callback) {
                    zw111_ctx.verify_callback(0, 0, ESP_ERR_TIMEOUT);
                }
                final_ret = ESP_ERR_TIMEOUT;
                goto exit_verify;
                
            case ZW111_ERR_NO_FINGER:
                ESP_LOGI(TAG, "请放置手指");
                break;
                
            default:
                ESP_LOGW(TAG, "指纹验证中间状态: 0x%02X", ack_code);
                break;
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    
    ESP_LOGI(TAG, "指纹验证超时");
    if (zw111_ctx.verify_callback) {
        zw111_ctx.verify_callback(0, 0, ESP_ERR_TIMEOUT);
    }
    final_ret = ESP_ERR_TIMEOUT;

exit_verify:
    zw111_power_off();                        // 重置状态为 POWER_OFF
}

/**
 * @brief 执行指纹录入 （带内部阻塞
 */
static esp_err_t zw111_perform_enrollment(uint16_t user_id, uint32_t timeout_ms, 
                                        zw111_enroll_progress_callback_t progress_callback) {
    ESP_LOGI(TAG, "开始指纹录入流程，用户ID: %u", user_id);
    
    // 组装自动注册参数
    uint8_t params[5];
    params[0] = (user_id >> 8) & 0xFF;
    params[1] = user_id & 0xFF;
    params[2] = 5; // 录入5次
    params[3] = 0x00; // 参数高字节
    params[4] = 0x19; // 参数低字节: 允许覆盖, 不允许重复, LED灭
    
    uint8_t recv_buf[16];
    uint16_t recv_data_len;
    uint8_t pkg_id;
    int64_t start_time = esp_timer_get_time();
    
    uint8_t current_step = 0;
    uint8_t total_steps = 5; // 总共5次录入
    bool step_completed[3] = {false, false, false};
    
    // 发送开始录入进度
    if (progress_callback) {
        progress_callback(0, total_steps, "请触摸指纹模块开始录入");
    }
    
    esp_err_t ret = zw111_send_command(ZW111_CMD_AUTO_ENROLL, params, 5, NULL, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动自动注册失败: 0x%x", ret);
        if (progress_callback) {
            progress_callback(0, total_steps, "启动录入失败");
        }
        return ret;
    }
    
    // 循环接收录入结果
    while (esp_timer_get_time() - start_time < timeout_ms * 1000) {
        ret = zw111_receive_package(&pkg_id, recv_buf, &recv_data_len, 100);
        if (ret == ESP_ERR_TIMEOUT) {
            continue;
        }
        
        if (ret != ESP_OK) {
            continue;
        }
        
        if (pkg_id != ZW111_PKG_ACK || recv_data_len < 1) {
            continue;
        }
        
        uint8_t ack_code = recv_buf[0];
        uint8_t param1 = recv_data_len >= 2 ? recv_buf[1] : 0xFF;
        uint8_t param2 = recv_data_len >= 3 ? recv_buf[2] : 0xFF;
        
        // 处理各种状态码并更新进度
        if (ack_code == ZW111_OK) {
            // 根据 param1 和 param2 的组合处理
            if (param1 == 0x01) {
                // 第 param2 次获取图像成功
                current_step = param2;
                step_completed[param2-1] = true;
                if (progress_callback) {
                    char msg[64];
                    snprintf(msg, sizeof(msg), "第%d次录入图像成功", param2);
                    progress_callback(current_step, total_steps, msg);
                }
            }
            else if (param1 == 0x02) {
                // 第 param2 次生成特征成功
                if (progress_callback) {
                    char msg[64];
                    snprintf(msg, sizeof(msg), "第%d次特征生成成功", param2);
                    progress_callback(current_step, total_steps, msg);
                }
            }
            else if (param1 == 0x03) {
                // 手指离开，第 param2 次完成，提示准备下一次
                if (progress_callback && param2 < total_steps) {
                    char msg[64];
                    snprintf(msg, sizeof(msg), "请进行第%d次按压", param2+1);
                    progress_callback(param2, total_steps, msg);
                }
            }
            else if (param1 == 0x04 && param2 == 0xF0) {
                // 合并模板
                if (progress_callback) {
                    progress_callback(total_steps, total_steps, "正在合并模板...");
                }
            }
            else if (param1 == 0x05 && param2 == 0xF1) {
                // 重复检查
                if (progress_callback) {
                    progress_callback(total_steps, total_steps, "检查指纹是否重复...");
                }
            }
            else if (param1 == 0x06 && param2 == 0xF2) {
                // 录入完成
                if (progress_callback) {
                    progress_callback(total_steps, total_steps, "录入成功！");
                }
                ESP_LOGI(TAG, "指纹录入完成，用户ID: %u", user_id);
                return ESP_OK;
            }
            else {
                // 其他组合（如指令合法性检测 param1=0x00）
                ESP_LOGD(TAG, "中间状态: ack=0x%02X, p1=0x%02X, p2=0x%02X", 
                        ack_code, param1, param2);
            }
        }
        else {
            // 非零确认码处理（错误情况）
            switch (ack_code) {
                case ZW111_ERR_FINGER_EXIST:
                    ESP_LOGE(TAG, "指纹已存在");
                    if (progress_callback) {
                        progress_callback(current_step, total_steps, "指纹已存在，录入失败");
                    }
                    return ESP_FAIL;
                case ZW111_ERR_DB_FULL:
                    ESP_LOGE(TAG, "指纹库已满");
                    if (progress_callback) {
                        progress_callback(current_step, total_steps, "指纹库已满");
                    }
                    return ESP_FAIL;
                case ZW111_ERR_TIMEOUT:
                    ESP_LOGE(TAG, "操作超时");
                    if (progress_callback) {
                        progress_callback(current_step, total_steps, "录入超时");
                    }
                    return ESP_ERR_TIMEOUT;
                default:
                    ESP_LOGW(TAG, "错误代码: 0x%02X", ack_code);
                    break;
            }
        }
        
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    

    ESP_LOGI(TAG, "指纹录入超时");
    if (progress_callback) {
        progress_callback(current_step, total_steps, "录入超时，请重试");
    }
    return ESP_ERR_TIMEOUT;
}

/**
 * @brief 指纹录入流程 （非阻塞
 */
static void zw111_enrollment_process(void) {
    ESP_LOGI(TAG, "开始指纹录入流程，用户ID: %u", zw111_ctx.enroll_user_id);
    
    // 执行录入
    esp_err_t result = zw111_perform_enrollment(zw111_ctx.enroll_user_id, 
                                              ZW111_ENROLL_TIMEOUT,
                                              zw111_ctx.enroll_progress_callback);
    
    // 调用回调函数
    if (zw111_ctx.enroll_callback) {
        zw111_ctx.enroll_callback(zw111_ctx.enroll_user_id, 0, result);
    }
    
    // 清除录入状态
    zw111_ctx.enroll_in_progress = false;
    
    // 关闭电源
    zw111_power_off();
    
    // 如果是阻塞模式，发送完成信号
    if (zw111_ctx.enroll_complete_sem) {
        zw111_ctx.enroll_result = result;
        xSemaphoreGive(zw111_ctx.enroll_complete_sem);
    }
}

/**
 * @brief 主任务函数
 */
static void zw111_task(void *arg) {
    ESP_LOGI(TAG, "ZW111任务启动");
    
    // 初始化触摸检测引脚
    gpio_config_t touch_pin_cfg = {
        .pin_bit_mask = (1ULL << ZW111_TOUCH_CHECK_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&touch_pin_cfg);
    
    while (1) {
        // 检查触摸信号 (仅在电源关闭状态且不在录入中)
        if (zw111_check_touch() && !zw111_ctx.power_on && 
            zw111_ctx.state == ZW111_STATE_POWER_OFF && !zw111_ctx.enroll_in_progress) {
            
            ESP_LOGI(TAG, "检测到触摸信号，启动指纹验证");
            
            // 获取操作锁
            if (xSemaphoreTake(zw111_ctx.operation_mutex, pdMS_TO_TICKS(1000))) {
                // 打开电源
                if (zw111_power_on() == ESP_OK) {
                    // 等待模块唤醒
                    if (zw111_wait_for_wakeup() == ESP_OK) {
                        // 启动验证流程
                        zw111_ctx.state = ZW111_STATE_VERIFYING;
                        if (zw111_start_timeout_timer(ZW111_VERIFY_TIMEOUT) == ESP_OK) {
                            esp_timer_stop(zw111_ctx.timeout_timer);
                            zw111_verification_process();
                        } else {
                            ESP_LOGE(TAG, "启动超时定时器失败");
                            zw111_power_off();
                        }
                    } else {
                        ESP_LOGE(TAG, "模块唤醒失败");
                        zw111_power_off();
                    }
                }
                xSemaphoreGive(zw111_ctx.operation_mutex);
            }
        }
        
        // 检查录入状态
        if (zw111_ctx.state == ZW111_STATE_ENROLLING && !zw111_ctx.power_on && !zw111_ctx.enroll_in_progress) {
            ESP_LOGI(TAG, "开始指纹录入流程");
            
            // 获取操作锁
            if (xSemaphoreTake(zw111_ctx.operation_mutex, pdMS_TO_TICKS(1000))) {
                zw111_ctx.enroll_in_progress = true;
                
                // 打开电源
                if (zw111_power_on() == ESP_OK) {
                    // 等待模块唤醒
                    if (zw111_wait_for_wakeup() == ESP_OK) {
                        // 启动录入流程
                        zw111_ctx.state = ZW111_STATE_ENROLLING;
                        if (zw111_start_timeout_timer(ZW111_ENROLL_TIMEOUT) == ESP_OK) {
                            zw111_enrollment_process();
                        } else {
                            ESP_LOGE(TAG, "启动超时定时器失败");
                            zw111_ctx.enroll_in_progress = false;
                            zw111_power_off();
                        }
                    } else {
                        ESP_LOGE(TAG, "模块唤醒失败");
                        zw111_ctx.enroll_in_progress = false;
                        zw111_power_off();
                    }
                } else {
                    zw111_ctx.enroll_in_progress = false;
                }
                xSemaphoreGive(zw111_ctx.operation_mutex);
            }
        }
        
        vTaskDelay(pdMS_TO_TICKS(50)); // 降低检测频率
    }
}

// ========== 公共API函数实现 ==========

esp_err_t zw111_init(void) {
    if (zw111_ctx.initialized) {
        ESP_LOGW(TAG, "ZW111已经初始化");
        return ESP_OK;
    }
    
    ESP_LOGI(TAG, "初始化ZW111指纹模块");
    
    // 首先初始化电源控制，确保指纹模块断电
    esp_err_t ret = zw111_init_power_control();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "电源控制初始化失败");
        return ret;
    }
    
    // 强制确保指纹模块断电
    zw111_force_power_off();
    
    // 初始化NVS
    ret = nvs_flash_init();
    if (ret != ESP_OK && ret != ESP_ERR_NVS_NO_FREE_PAGES) {
        ESP_LOGE(TAG, "NVS初始化失败: 0x%x", ret);
        return ret;
    }
    
    // 创建操作互斥锁
    zw111_ctx.operation_mutex = xSemaphoreCreateMutex();
    if (zw111_ctx.operation_mutex == NULL) {
        ESP_LOGE(TAG, "创建操作互斥锁失败");
        return ESP_FAIL;
    }
    
    // 创建录入完成信号量
    zw111_ctx.enroll_complete_sem = xSemaphoreCreateBinary();
    if (zw111_ctx.enroll_complete_sem == NULL) {
        ESP_LOGE(TAG, "创建录入完成信号量失败");
        vSemaphoreDelete(zw111_ctx.operation_mutex);
        return ESP_FAIL;
    }
    
    // 创建事件队列
    zw111_ctx.event_queue = xQueueCreate(10, sizeof(uint32_t));
    if (zw111_ctx.event_queue == NULL) {
        ESP_LOGE(TAG, "创建事件队列失败");
        vSemaphoreDelete(zw111_ctx.operation_mutex);
        vSemaphoreDelete(zw111_ctx.enroll_complete_sem);
        return ESP_FAIL;
    }
    
    // 初始化触摸检测引脚
    gpio_config_t touch_pin_cfg = {
        .pin_bit_mask = (1ULL << ZW111_TOUCH_CHECK_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,  // 下拉确保默认低电平
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&touch_pin_cfg);
    
    // 8. 创建主任务
    BaseType_t task_ret = xTaskCreate(zw111_task, "zw111_task", 4096, NULL, 5, &zw111_ctx.task_handle);
    if (task_ret != pdPASS) {
        ESP_LOGE(TAG, "创建ZW111任务失败");
        vSemaphoreDelete(zw111_ctx.operation_mutex);
        vSemaphoreDelete(zw111_ctx.enroll_complete_sem);
        vQueueDelete(zw111_ctx.event_queue);
        return ESP_FAIL;
    }
    
    // 初始状态为电源关闭
    zw111_ctx.state = ZW111_STATE_POWER_OFF;
    zw111_ctx.power_on = false;
    zw111_ctx.initialized = true;
    
    ESP_LOGI(TAG, "ZW111初始化成功，指纹模块处于断电状态");
    return ESP_OK;
}

esp_err_t zw111_deinit(void) {
    if (!zw111_ctx.initialized) {
        return ESP_OK;
    }
    
    ESP_LOGI(TAG, "反初始化ZW111指纹模块");
    
    // 关闭电源
    zw111_power_off();
    
    // 删除任务
    if (zw111_ctx.task_handle) {
        vTaskDelete(zw111_ctx.task_handle);
        zw111_ctx.task_handle = NULL;
    }
    
    // 删除队列
    if (zw111_ctx.event_queue) {
        vQueueDelete(zw111_ctx.event_queue);
        zw111_ctx.event_queue = NULL;
    }
    
    // 删除信号量
    if (zw111_ctx.operation_mutex) {
        vSemaphoreDelete(zw111_ctx.operation_mutex);
        zw111_ctx.operation_mutex = NULL;
    }
    
    if (zw111_ctx.enroll_complete_sem) {
        vSemaphoreDelete(zw111_ctx.enroll_complete_sem);
        zw111_ctx.enroll_complete_sem = NULL;
    }
    
    // 删除定时器
    if (zw111_ctx.timeout_timer) {
        esp_timer_delete(zw111_ctx.timeout_timer);
        zw111_ctx.timeout_timer = NULL;
    }
    
    // 反初始化UART
    zw111_uart_deinit();
    
    zw111_ctx.initialized = false;
    zw111_ctx.uart_initialized = false;
    ESP_LOGI(TAG, "ZW111反初始化成功");
    return ESP_OK;
}

esp_err_t zw111_start_verification(zw111_callback_t callback) {
    if (!zw111_ctx.initialized) {
        ESP_LOGE(TAG, "ZW111未初始化");
        return ESP_ERR_INVALID_STATE;
    }
    
    if (zw111_ctx.enroll_in_progress) {
        ESP_LOGE(TAG, "指纹录入进行中，无法启动验证");
        return ESP_ERR_INVALID_STATE;
    }
    
    ESP_LOGI(TAG, "启动指纹验证");
    zw111_ctx.verify_callback = callback;
    
    return ESP_OK;
}

esp_err_t zw111_stop_verification(void) {
    if (zw111_ctx.state == ZW111_STATE_VERIFYING) {
        ESP_LOGI(TAG, "停止指纹验证");
        zw111_power_off();
        return ESP_OK;
    }
    
    return ESP_ERR_INVALID_STATE;
}

esp_err_t zw111_enroll_user_blocking(uint16_t user_id, uint32_t timeout_ms,
                                   zw111_enroll_progress_callback_t progress_callback) {
    if (!zw111_ctx.initialized) {
        ESP_LOGE(TAG, "ZW111未初始化");
        return ESP_ERR_INVALID_STATE;
    }
    
    if (zw111_ctx.enroll_in_progress) {
        ESP_LOGE(TAG, "指纹录入正在进行中");
        return ESP_ERR_INVALID_STATE;
    }
    
    // 获取操作锁
    if (xSemaphoreTake(zw111_ctx.operation_mutex, pdMS_TO_TICKS(timeout_ms)) == pdFALSE) {
        ESP_LOGE(TAG, "获取操作锁超时");
        return ESP_ERR_TIMEOUT;
    }
    
    ESP_LOGI(TAG, "开始阻塞式指纹录入，用户ID: %u", user_id);
    
    // 分配用户ID
    if (user_id == 0) {
        user_id = zw111_allocate_user_id();
    }
    
    // 重置信号量
    xSemaphoreTake(zw111_ctx.enroll_complete_sem, 0);
    
    // 设置录入参数
    zw111_ctx.enroll_user_id = user_id;
    zw111_ctx.enroll_in_progress = true;
    zw111_ctx.state = ZW111_STATE_ENROLLING;
    
    // 打开电源
    esp_err_t ret = zw111_power_on();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "打开电源失败");
        zw111_ctx.enroll_in_progress = false;
        xSemaphoreGive(zw111_ctx.operation_mutex);
        return ret;
    }
    
    // 等待模块唤醒
    ret = zw111_wait_for_wakeup();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "模块唤醒失败");
        zw111_power_off();
        zw111_ctx.enroll_in_progress = false;
        xSemaphoreGive(zw111_ctx.operation_mutex);
        return ret;
    }
    
    // 启动超时定时器
    if (zw111_start_timeout_timer(timeout_ms) != ESP_OK) {
        ESP_LOGE(TAG, "启动超时定时器失败");
        zw111_power_off();
        zw111_ctx.enroll_in_progress = false;
        xSemaphoreGive(zw111_ctx.operation_mutex);
        return ESP_FAIL;
    }
    
    // 执行录入
    ret = zw111_perform_enrollment(user_id, timeout_ms, progress_callback);
    
    // 清理状态
    zw111_power_off();
    zw111_ctx.enroll_in_progress = false;
    
    // 释放操作锁
    xSemaphoreGive(zw111_ctx.operation_mutex);
    
    ESP_LOGI(TAG, "阻塞式指纹录入完成，结果: 0x%x", ret);
    return ret;
}

esp_err_t zw111_start_enrollment(uint16_t user_id, zw111_callback_t callback,
                               zw111_enroll_progress_callback_t progress_callback)  {
    if (!zw111_ctx.initialized) {
        ESP_LOGE(TAG, "ZW111未初始化");
        return ESP_ERR_INVALID_STATE;
    }
    
    if (zw111_ctx.enroll_in_progress) {
        ESP_LOGE(TAG, "指纹录入正在进行中");
        return ESP_ERR_INVALID_STATE;
    }
    
    ESP_LOGI(TAG, "启动指纹录入");
    
    zw111_ctx.enroll_user_id = user_id;
    zw111_ctx.enroll_callback = callback;
    zw111_ctx.enroll_progress_callback = progress_callback;  // 新增进度回调
    zw111_ctx.state = ZW111_STATE_ENROLLING;
    
    return ESP_OK;
}

esp_err_t zw111_stop_enrollment(void) {
    if (zw111_ctx.state == ZW111_STATE_ENROLLING) {
        ESP_LOGI(TAG, "停止指纹录入");
        zw111_power_off();
        zw111_ctx.enroll_in_progress = false;
        return ESP_OK;
    }
    
    return ESP_ERR_INVALID_STATE;
}

esp_err_t zw111_clear_database(void) {
    if (!zw111_ctx.initialized) {
        return ESP_ERR_INVALID_STATE;
    }
    
    ESP_LOGI(TAG, "清空指纹库");
    
    // 如果当前有操作，先停止
    if (zw111_ctx.state != ZW111_STATE_POWER_OFF) {
        zw111_power_off();
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    
    // 打开电源
    esp_err_t ret = zw111_power_on();
    if (ret != ESP_OK) {
        return ret;
    }
    
    // 等待模块唤醒
    zw111_wait_for_wakeup();
    
    // 发送清空命令
    ret = zw111_send_command(ZW111_CMD_EMPTY, NULL, 0, NULL, NULL);
    
    // 关闭电源
    zw111_power_off();
    
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "指纹库清空成功");
    } else {
        ESP_LOGE(TAG, "指纹库清空失败");
    }
    
    return ret;
}

esp_err_t zw111_get_user_count(uint16_t *count) {
    if (!zw111_ctx.initialized || !count) {
        return ESP_ERR_INVALID_ARG;
    }
    
    // 如果当前有操作，先停止
    if (zw111_ctx.state != ZW111_STATE_POWER_OFF) {
        zw111_power_off();
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    
    // 打开电源
    esp_err_t ret = zw111_power_on();
    if (ret != ESP_OK) {
        return ret;
    }
    
    // 等待模块唤醒
    zw111_wait_for_wakeup();
    
    // 发送读取命令
    uint8_t response[2];
    uint16_t resp_len;
    ret = zw111_send_command(ZW111_CMD_GET_USER_COUNT, NULL, 0, response, &resp_len);
    
    // 关闭电源
    zw111_power_off();
    
    if (ret == ESP_OK && resp_len >= 2) {
        *count = (response[0] << 8) | response[1];
        ESP_LOGI(TAG, "指纹库中有效模板数量: %u", *count);
    } else {
        ESP_LOGE(TAG, "读取模板数量失败");
        *count = 0;
    }
    
    return ret;
}

esp_err_t zw111_delete_user(uint16_t user_id) {
    if (!zw111_ctx.initialized) {
        return ESP_ERR_INVALID_STATE;
    }
    
    ESP_LOGI(TAG, "删除用户指纹，用户ID: %u", user_id);
    
    // 如果当前有操作，先停止
    if (zw111_ctx.state != ZW111_STATE_POWER_OFF) {
        zw111_power_off();
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    
    // 打开电源
    esp_err_t ret = zw111_power_on();
    if (ret != ESP_OK) {
        return ret;
    }
    
    // 等待模块唤醒
    zw111_wait_for_wakeup();
    
    // 发送删除命令
    uint8_t params[4];
    params[0] = (user_id >> 8) & 0xFF;
    params[1] = user_id & 0xFF;
    params[2] = 0x00; // 删除数量1
    params[3] = 0x01;
    
    ret = zw111_send_command(ZW111_CMD_DELETE_USER, params, 4, NULL, NULL);
    
    // 关闭电源
    zw111_power_off();
    
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "用户指纹删除成功");
    } else {
        ESP_LOGE(TAG, "用户指纹删除失败");
    }
    
    return ret;
}

esp_err_t zw111_read_sys_params(zw111_sys_params_t *params) {
    if (!zw111_ctx.initialized || !params) {
        return ESP_ERR_INVALID_ARG;
    }
    
    // 如果当前有操作，先停止
    if (zw111_ctx.state != ZW111_STATE_POWER_OFF) {
        zw111_power_off();
        vTaskDelay(pdMS_TO_TICKS(100));
    }
    
    // 打开电源
    esp_err_t ret = zw111_power_on();
    if (ret != ESP_OK) {
        return ret;
    }
    
    // 等待模块唤醒
    zw111_wait_for_wakeup();
    
    // 发送读取命令
    uint8_t response[16];
    uint16_t resp_len;
    ret = zw111_send_command(ZW111_CMD_READ_SYS_PARA, NULL, 0, response, &resp_len);
    
    // 关闭电源
    zw111_power_off();
    
    if (ret == ESP_OK && resp_len >= 16) {
        params->enroll_times = (response[0] << 8) | response[1];
        params->template_size = (response[2] << 8) | response[3];
        params->database_size = (response[4] << 8) | response[5];
        params->score_level = (response[6] << 8) | response[7];
        params->device_addr = (response[8] << 24) | (response[9] << 16) | (response[10] << 8) | response[11];
        params->pkt_size = (response[12] << 8) | response[13];
        params->baud_rate = (response[14] << 8) | response[15];
        
        ESP_LOGI(TAG, "系统参数读取成功");
        ESP_LOGI(TAG, "注册次数: %u, 模板大小: %u, 库容量: %u", 
                params->enroll_times, params->template_size, params->database_size);
    } else {
        ESP_LOGE(TAG, "系统参数读取失败");
    }
    
    return ret;
}

bool zw111_is_busy(void) {
    return zw111_ctx.enroll_in_progress || 
           zw111_ctx.state == ZW111_STATE_VERIFYING || 
           zw111_ctx.state == ZW111_STATE_ENROLLING;
}

esp_err_t zw111_set_device_addr(uint32_t addr) {
    // 预留功能，后续实现
    ESP_LOGI(TAG, "设置设备地址: 0x%08lX", addr);
    zw111_ctx.device_addr = addr;
    return ESP_OK;
}

esp_err_t zw111_set_password(uint32_t password) {
    // 预留功能，后续实现
    ESP_LOGI(TAG, "设置设备口令: 0x%08lX", password);
    return ESP_OK;
}

zw111_state_t zw111_get_state(void) {
    return zw111_ctx.state;
}