/**
 * *****************************************************************************
 * @file zw111.h
 * @brief ZW111半导体指纹模块驱动头文件
 * @author zhanhuangbin (awa@azxi.link)
 * @version 1.0
 * @date 2025-11-02
 *  * 
 * @par 修改日志:
 * Date       Version     Author      Description
 * 2025-11-02 1.0         zhanhuangbin  初始版本
 * 2025-11-07 1.0         zhanhuangbin  增加低功耗函数，优化函数指令
 * *****************************************************************************
 */

#ifndef __ZW111_H__
#define __ZW111_H__

#include "esp_err.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "nvs_flash.h"
#include <stdint.h>
#include <stdbool.h>

// ========== 硬件引脚配置 ==========
#define ZW111_POWER_CONTROL_PIN      GPIO_NUM_7   // 电源控制引脚
#define ZW111_TOUCH_CHECK_PIN        GPIO_NUM_6   // 触摸检测引脚
#define ZW111_UART_TX_PIN            GPIO_NUM_5   // UART发送引脚
#define ZW111_UART_RX_PIN            GPIO_NUM_4   // UART接收引脚
#define ZW111_UART_PORT              UART_NUM_1   // UART端口
#define ZW111_UART_BAUD_RATE         57600        // 波特率
#define ZW111_UART_BUF_SIZE          512          // UART缓冲区大小

// ========== 超时配置 (毫秒) ==========
#define ZW111_TOUCH_TIMEOUT          3000         // 触摸检测超时
#define ZW111_ENROLL_TIMEOUT         20000         // 录入超时
#define ZW111_VERIFY_TIMEOUT         3000         // 验证超时
#define ZW111_COMMAND_TIMEOUT        2000         // 命令超时

// ========== 协议定义 ==========
#define ZW111_HEADER_HIGH            0xEF         // 包头高字节
#define ZW111_HEADER_LOW             0x01         // 包头低字节
#define ZW111_DEFAULT_ADDR           0xFFFFFFFF   // 默认设备地址

// 包标识符
#define ZW111_PKG_CMD                0x01         // 命令包
#define ZW111_PKG_DATA               0x02         // 数据包
#define ZW111_PKG_END_DATA           0x08         // 结束数据包
#define ZW111_PKG_ACK                0x07         // 应答包

// 命令代码
#define ZW111_CMD_EMPTY              0x0D         // 清空指纹库
#define ZW111_CMD_GET_USER_COUNT     0x1D         // 读取有效模板个数
#define ZW111_CMD_DELETE_USER        0x0C         // 删除单个用户
#define ZW111_CMD_READ_SYS_PARA      0x0F         // 读取系统参数
#define ZW111_CMD_SEARCH             0x04         // 搜索指纹
#define ZW111_CMD_MATCH              0x03         // 比对特征
#define ZW111_CMD_CANCEL             0x30         // 取消指令
#define ZW111_CMD_AUTO_ENROLL        0x31         // 自动注册
#define ZW111_CMD_AUTO_IDENTIFY      0x32         // 自动验证
#define ZW111_CMD_HANDSHAKE          0x35

// 确认码/错误码
#define ZW111_OK                     0x00         // 成功
#define ZW111_ERR_NO_FINGER          0x02         // 无手指
#define ZW111_ERR_GET_IMAGE          0x03         // 获取图像失败
#define ZW111_ERR_NOT_FOUND          0x09         // 未找到匹配
#define ZW111_ERR_DB_FULL            0x1F         // 指纹库已满
#define ZW111_ERR_TIMEOUT            0x26         // 操作超时
#define ZW111_ERR_FINGER_EXIST       0x27         // 指纹已存在
#define ZW111_ERR_DB_EMPTY           0x24         // 指纹库为空

// ========== 数据结构定义 ==========

/**
 * @brief 系统参数结构体
 */
typedef struct {
    uint16_t enroll_times;    // 注册次数
    uint16_t template_size;   // 模板大小
    uint16_t database_size;   // 指纹库容量
    uint16_t score_level;     // 安全等级
    uint32_t device_addr;     // 设备地址
    uint16_t pkt_size;        // 包大小
    uint16_t baud_rate;       // 波特率
} zw111_sys_params_t;

/**
 * @brief 搜索结果结构体
 */
typedef struct {
    uint16_t page_id;         // 指纹ID
    uint16_t score;           // 匹配分数
} zw111_search_result_t;

/**
 * @brief 指纹操作回调函数类型
 */
typedef void (*zw111_callback_t)(uint16_t user_id, uint16_t score, esp_err_t result);

/**
 * @brief 指纹模块状态
 */
typedef enum {
    ZW111_STATE_POWER_OFF = 0,    // 电源关闭
    ZW111_STATE_IDLE,             // 空闲状态
    ZW111_STATE_VERIFYING,        // 验证中
    ZW111_STATE_ENROLLING,        // 录入中
    ZW111_STATE_CLEARING,         // 清空中
} zw111_state_t;

// ========== 公共API函数 ==========

/**
 * @brief 初始化ZW111指纹模块
 * 
 * @return esp_err_t 初始化结果
 */
esp_err_t zw111_init(void);

/**
 * @brief 反初始化ZW111指纹模块
 * 
 * @return esp_err_t 反初始化结果
 */
esp_err_t zw111_deinit(void);

/**
 * @brief 启动指纹识别流程
 * 
 * @param callback 识别结果回调函数
 * @return esp_err_t 启动结果
 */
esp_err_t zw111_start_verification(zw111_callback_t callback);

/**
 * @brief 停止指纹识别流程
 * 
 * @return esp_err_t 停止结果
 */
esp_err_t zw111_stop_verification(void);

/**
 * @brief 指纹录入进度回调函数类型
 */
typedef void (*zw111_enroll_progress_callback_t)(uint8_t current_step, uint8_t total_steps, const char* status);

/**
 * @brief 启动指纹录入流程 (阻塞版本)
 * 
 * @param user_id 用户ID (0表示自动分配)
 * @param timeout_ms 超时时间(毫秒)
 * @param progress_callback 进度回调函数
 * @return esp_err_t 录入结果
 */
esp_err_t zw111_enroll_user_blocking(uint16_t user_id, uint32_t timeout_ms, 
                                   zw111_enroll_progress_callback_t progress_callback);

/**
 * @brief 启动指纹录入流程 (非阻塞版本)
 * 
 * @param user_id 用户ID (0表示自动分配)
 * @param callback 录入结果回调函数
 * @param progress_callback 进度回调函数
 * @return esp_err_t 启动结果
 */
esp_err_t zw111_start_enrollment(uint16_t user_id, zw111_callback_t callback,
                               zw111_enroll_progress_callback_t progress_callback);

/**
 * @brief 停止指纹录入流程
 * 
 * @return esp_err_t 停止结果
 */
esp_err_t zw111_stop_enrollment(void);

/**
 * @brief 清空指纹库
 * 
 * @return esp_err_t 清空结果
 */
esp_err_t zw111_clear_database(void);

/**
 * @brief 获取指纹库中有效模板数量
 * 
 * @param count 返回的数量
 * @return esp_err_t 获取结果
 */
esp_err_t zw111_get_user_count(uint16_t *count);

/**
 * @brief 删除指定用户指纹
 * 
 * @param user_id 用户ID
 * @return esp_err_t 删除结果
 */
esp_err_t zw111_delete_user(uint16_t user_id);

/**
 * @brief 读取系统参数
 * 
 * @param params 返回的参数
 * @return esp_err_t 读取结果
 */
esp_err_t zw111_read_sys_params(zw111_sys_params_t *params);

/**
 * @brief 设置设备地址 (预留安全功能)
 * 
 * @param addr 设备地址
 * @return esp_err_t 设置结果
 */
esp_err_t zw111_set_device_addr(uint32_t addr);

/**
 * @brief 设置设备口令 (预留安全功能)
 * 
 * @param password 设备口令
 * @return esp_err_t 设置结果
 */
esp_err_t zw111_set_password(uint32_t password);

/**
 * @brief 获取当前模块状态
 * 
 * @return zw111_state_t 模块状态
 */
zw111_state_t zw111_get_state(void);

/**
 * @brief 检查是否正在操作中
 * 
 * @return true 正在操作
 * @return false 空闲状态
 */
bool zw111_is_busy(void);

#endif /* __ZW111_H__ */