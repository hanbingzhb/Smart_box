/**
 * @file box_sensor.h
 * @brief 柜门状态检测模块（按需供电版本）
 */

#ifndef __BOX_SENSOR_H__
#define __BOX_SENSOR_H__

#include "esp_err.h"
#include "driver/gpio.h"

// 引脚定义
#define BOX_SENSOR_PIN        GPIO_NUM_9   // 信号输入
#define BOX_SENSOR_POWER_PIN  GPIO_NUM_10  // 供电控制（高电平供电）

/**
 * @brief 初始化柜门传感器 GPIO（供电引脚默认断电）
 * @return ESP_OK 成功，否则失败
 */
esp_err_t box_sensor_init(void);

/**
 * @brief 给传感器供电，并开始检测关门事件
 * @note 调用后传感器上电，等待柜门关闭信号
 */
void box_sensor_enable(void);

/**
 * @brief 关闭传感器供电，停止检测
 */
void box_sensor_disable(void);

/**
 * @brief 获取当前柜门状态（需在供电状态下调用）
 * @return true=柜门打开, false=柜门关闭
 */
bool box_sensor_is_open(void);

/**
 * @brief 柜门关闭事件回调函数类型
 * @param is_closed 柜门是否已关闭
 */
typedef void (*box_closed_cb_t)(void);

/**
 * @brief 注册柜门关闭回调（当检测到门关闭时触发）
 * @param cb 回调函数指针
 */
void box_sensor_register_closed_callback(box_closed_cb_t cb);

#endif /* __BOX_SENSOR_H__ */