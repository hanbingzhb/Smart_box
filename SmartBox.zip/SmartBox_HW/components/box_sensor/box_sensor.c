/**
 * @file box_sensor.c
 * @brief 柜门状态检测模块（按需供电版本）
 */

#include "box_sensor.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "driver/gpio.h"

static const char *TAG = "BoxSensor";

static box_closed_cb_t g_closed_callback = NULL;
static bool g_enabled = false;          // 当前是否已使能（供电）
static bool g_last_level = 0;           // 上一次读取的电平

// 中断处理队列（用于将中断事件传递到任务）
static QueueHandle_t g_event_queue = NULL;

// 事件类型
typedef enum {
    BOX_EVENT_EDGE = 1,   // 电平变化
} box_event_t;

/**
 * @brief GPIO 中断服务函数
 */
static void IRAM_ATTR box_sensor_isr_handler(void *arg) {
    int level = gpio_get_level(BOX_SENSOR_PIN);
    // 向队列发送事件（带电平值）
    box_event_t ev = BOX_EVENT_EDGE;
    xQueueSendFromISR(g_event_queue, &level, NULL);
}

/**
 * @brief 监控任务：处理中断事件，检测关门
 */
static void box_sensor_monitor_task(void *arg) {
    int level;
    while (1) {
        if (xQueueReceive(g_event_queue, &level, portMAX_DELAY)) {
            // 只在使能状态下处理
            if (!g_enabled) continue;

            // 检测下降沿（高->低，即门关闭）
            if (g_last_level == 1 && level == 0) {
                ESP_LOGI(TAG, "检测到柜门关闭");
                // 先断电
                box_sensor_disable();
                // 触发回调
                if (g_closed_callback) {
                    g_closed_callback();
                }
            }
            g_last_level = level;
        }
    }
}

esp_err_t box_sensor_init(void) {
    // 配置供电引脚为输出，默认低电平（断电）
    gpio_config_t power_conf = {
        .pin_bit_mask = (1ULL << BOX_SENSOR_POWER_PIN),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    esp_err_t ret = gpio_config(&power_conf);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "供电引脚配置失败");
        return ret;
    }
    gpio_set_level(BOX_SENSOR_POWER_PIN, 0);  // 初始断电

    // 配置信号引脚为输入
    gpio_config_t signal_conf = {
        .pin_bit_mask = (1ULL << BOX_SENSOR_PIN),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,   // 下拉，确保无信号时读低电平
        .intr_type = GPIO_INTR_ANYEDGE,
    };
    ret = gpio_config(&signal_conf);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "信号引脚配置失败");
        return ret;
    }

    // 创建事件队列
    g_event_queue = xQueueCreate(10, sizeof(int));
    if (g_event_queue == NULL) {
        ESP_LOGE(TAG, "事件队列创建失败");
        return ESP_ERR_NO_MEM;
    }

    // 安装中断服务并添加处理函数
    gpio_install_isr_service(0);
    gpio_isr_handler_add(BOX_SENSOR_PIN, box_sensor_isr_handler, NULL);

    // 创建监控任务
    xTaskCreate(box_sensor_monitor_task, "box_monitor", 4096, NULL, 5, NULL);

    ESP_LOGI(TAG, "柜门传感器初始化完成（默认断电）");
    return ESP_OK;
}

void box_sensor_enable(void) {
    if (g_enabled) return;
    
    // 先读取当前电平作为基准（此时还未供电，传感器可能输出不确定，供电后再读一次）
    gpio_set_level(BOX_SENSOR_POWER_PIN, 1);   // 供电
    vTaskDelay(pdMS_TO_TICKS(50));             // 等待传感器稳定
    
    g_last_level = gpio_get_level(BOX_SENSOR_PIN);
    g_enabled = true;
    
    ESP_LOGI(TAG, "传感器已供电，当前电平: %d (1=开门, 0=关门)", g_last_level);
}

void box_sensor_disable(void) {
    if (!g_enabled) return;
    
    gpio_set_level(BOX_SENSOR_POWER_PIN, 0);   // 断电
    g_enabled = false;
    g_last_level = 0;
    
    ESP_LOGI(TAG, "传感器已断电");
}

bool box_sensor_is_open(void) {
    if (!g_enabled) return false;   // 未供电时返回默认关门
    return (gpio_get_level(BOX_SENSOR_PIN) == 1);
}

void box_sensor_register_closed_callback(box_closed_cb_t cb) {
    g_closed_callback = cb;
}