/**
 * *****************************************************************************
 * @file wifi_config.h
 * @brief WiFi 配置组件（ESP-IDF v5.5.1 官方标准）
 * @author 
 * @version 1.2
 * @date 2025-11-10
 * *****************************************************************************
 */

#pragma once

#include "esp_err.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief WiFi连接状态枚举
 */
typedef enum {
    WIFI_STATE_DISCONNECTED = 0,
    WIFI_STATE_CONNECTING,
    WIFI_STATE_CONNECTED,
    WIFI_STATE_ERROR
} wifi_state_t;

/**
 * @brief WiFi事件回调函数类型
 */
typedef void (*wifi_event_callback_t)(wifi_event_t event, void* data);

/**
 * @brief AP配置结构体 - 重命名避免冲突
 */
typedef struct {
    char ssid[32];
    char password[64];
    uint8_t channel;
    wifi_auth_mode_t authmode;
    uint8_t max_connection;
} wifi_ap_config_custom_t;

/**
 * @brief STA配置结构体 - 重命名避免冲突
 */
typedef struct {
    char ssid[32];
    char password[64];
} wifi_sta_config_custom_t;

/**
 * @brief APSTA配置结构体
 */
typedef struct {
    wifi_ap_config_custom_t ap;
    wifi_sta_config_custom_t sta;
} wifi_apsta_config_t;

/**
 * @brief 初始化 WiFi（创建事件循环并初始化驱动）
 */
esp_err_t wifi_config_init(void);

/**
 * @brief 启动 APSTA 模式（同时开启AP和STA）
 * @param config 指向 wifi_apsta_config_t 结构体的指针
 */
esp_err_t wifi_start_apsta(wifi_apsta_config_t *config);

/**
 * @brief 启动 STA 模式
 * @param config 指向 wifi_sta_config_custom_t 结构体的指针
 */
esp_err_t wifi_start_sta(wifi_sta_config_custom_t *config);

/**
 * @brief 启动 AP 模式
 * @param config 指向 wifi_ap_config_custom_t 结构体的指针
 */
esp_err_t wifi_start_ap(wifi_ap_config_custom_t *config);

/**
 * @brief 停止 WiFi
 */
esp_err_t wifi_stop(void);

/**
 * @brief 切换到纯STA模式（关闭AP）
 */
esp_err_t wifi_switch_to_sta_mode(void);

/**
 * @brief 获取当前 WiFi 模式
 */
wifi_mode_t wifi_get_mode(void);

/**
 * @brief 获取当前 STA 模式下的 IPv4 地址字符串
 */
esp_err_t wifi_get_ip_address(char *ip_addr, size_t len);

/**
 * @brief 获取当前 AP 模式下的 IPv4 地址字符串
 */
esp_err_t wifi_get_ap_ip_address(char *ip_addr, size_t len);

/**
 * @brief 注册自定义事件回调（可用于上层通知）
 */
void wifi_set_event_callback(wifi_event_callback_t callback);

/**
 * @brief 判断是否已连接 WiFi（仅 STA 模式）
 */
bool wifi_is_connected(void);

/**
 * @brief 获取WiFi连接状态
 */
wifi_state_t wifi_get_connection_state(void);

/**
 * @brief 启动自动重连机制
 */
esp_err_t wifi_start_auto_reconnect(void);

/**
 * @brief 扫描周围 WiFi 网络
 * @param ap_count 返回发现的 AP 数量
 * @return wifi_ap_record_t* 扫描结果数组（需 free()）
 */
wifi_ap_record_t* wifi_scan_networks(uint16_t *ap_count);

/**
 * @brief 保存 WiFi STA 配置到 NVS
 */
esp_err_t wifi_save_config(wifi_sta_config_custom_t *config);

/**
 * @brief 从 NVS 加载 WiFi STA 配置
 */
esp_err_t wifi_load_config(wifi_sta_config_custom_t *config);

/**
 * @brief 连接指定 WiFi 网络
 */
esp_err_t wifi_connect_to_ap(const char *ssid, const char *password);

#ifdef __cplusplus
}
#endif