/**
 * *****************************************************************************
 * @file wifi_config.c
 * @brief WiFi配置组件实现 (ESP-IDF v5.5.1标准)
 * @author 
 * @version 1.2
 * @date 2025-11-10
 * *****************************************************************************
 */

#include "wifi_config.h"
#include "esp_log.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_mac.h"
#include "nvs_flash.h"
#include <string.h>

static const char *TAG = "WiFi_Config";

static wifi_event_callback_t g_wifi_callback = NULL;
static bool g_wifi_connected = false;
static char g_ip_address[16] = {0};
static char g_ap_ip_address[16] = "192.168.4.1";

// 添加自动重连相关变量
static wifi_state_t g_wifi_state = WIFI_STATE_DISCONNECTED;
static uint8_t g_reconnect_attempts = 0;
static const uint8_t MAX_RECONNECT_ATTEMPTS = 5;
static TimerHandle_t g_reconnect_timer = NULL;

// 网络接口
static esp_netif_t *g_sta_netif = NULL;
static esp_netif_t *g_ap_netif = NULL;

// WiFi事件处理
static void wifi_event_handler(void* arg, esp_event_base_t event_base, 
                              int32_t event_id, void* event_data)
{
    if (event_base == WIFI_EVENT) {
        switch (event_id) {
            case WIFI_EVENT_STA_START:
                ESP_LOGI(TAG, "WiFi STA启动");
                g_wifi_state = WIFI_STATE_CONNECTING;
                break;
                
            case WIFI_EVENT_STA_CONNECTED:
                ESP_LOGI(TAG, "WiFi已连接到AP");
                g_wifi_state = WIFI_STATE_CONNECTED;
                break;
                
            case WIFI_EVENT_STA_DISCONNECTED:
            {
                wifi_event_sta_disconnected_t* disconnected = (wifi_event_sta_disconnected_t*) event_data;
                ESP_LOGI(TAG, "WiFi断开连接, 原因: %d", disconnected->reason);
                g_wifi_connected = false;
                g_wifi_state = WIFI_STATE_DISCONNECTED;
                memset(g_ip_address, 0, sizeof(g_ip_address));
                
                // 自动重连逻辑
                if (g_reconnect_attempts < MAX_RECONNECT_ATTEMPTS) {
                    g_reconnect_attempts++;
                    ESP_LOGI(TAG, "尝试第 %d 次重连...", g_reconnect_attempts);
                    
                    // 使用指数退避算法
                    uint32_t delay_ms = 1000 * (1 << (g_reconnect_attempts - 1));
                    if (delay_ms > 30000) delay_ms = 30000;
                    
                    if (g_reconnect_timer) {
                        xTimerChangePeriod(g_reconnect_timer, pdMS_TO_TICKS(delay_ms), 0);
                        xTimerStart(g_reconnect_timer, 0);
                    }
                } else {
                    ESP_LOGW(TAG, "达到最大重连次数(%d)，停止自动重连", MAX_RECONNECT_ATTEMPTS);
                }
                break;
            }
                
            case WIFI_EVENT_AP_STACONNECTED:
            {
                wifi_event_ap_staconnected_t* connected = (wifi_event_ap_staconnected_t*) event_data;
                ESP_LOGI(TAG, "设备连接到AP, MAC: " MACSTR, MAC2STR(connected->mac));
                break;
            }
                
            case WIFI_EVENT_AP_STADISCONNECTED:
            {
                wifi_event_ap_stadisconnected_t* disconnected = (wifi_event_ap_stadisconnected_t*) event_data;
                ESP_LOGI(TAG, "设备从AP断开, MAC: " MACSTR, MAC2STR(disconnected->mac));
                break;
            }
        }
    } else if (event_base == IP_EVENT) {
        if (event_id == IP_EVENT_STA_GOT_IP) {
            ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
            esp_ip4addr_ntoa(&event->ip_info.ip, g_ip_address, sizeof(g_ip_address));
            ESP_LOGI(TAG, "获取到IP地址: %s", g_ip_address);
            g_wifi_connected = true;
            g_wifi_state = WIFI_STATE_CONNECTED;
            g_reconnect_attempts = 0; // 重置重连计数
        } else if (event_id == IP_EVENT_STA_LOST_IP) {
            ESP_LOGI(TAG, "丢失IP地址");
            g_wifi_connected = false;
            g_wifi_state = WIFI_STATE_DISCONNECTED;
            memset(g_ip_address, 0, sizeof(g_ip_address));
        } else if (event_id == IP_EVENT_AP_STAIPASSIGNED) {
            ESP_LOGI(TAG, "AP分配IP给客户端");
        }
    }
    
    if (g_wifi_callback) {
        g_wifi_callback((wifi_event_t)event_id, event_data);
    }
}

// 重连定时器回调
static void reconnect_timer_callback(TimerHandle_t xTimer)
{
    if (g_wifi_state == WIFI_STATE_DISCONNECTED) {
        ESP_LOGI(TAG, "执行自动重连");
        esp_wifi_connect();
    }
}

esp_err_t wifi_config_init(void)
{
    ESP_LOGI(TAG, "初始化WiFi配置");
    
    esp_err_t ret = esp_netif_init();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "网络接口初始化失败: 0x%x", ret);
        return ret;
    }
    
    ret = esp_event_loop_create_default();
    if (ret != ESP_OK && ret != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "事件循环创建失败: 0x%x", ret);
        return ret;
    }
    
    // 创建STA和AP网络接口
    g_sta_netif = esp_netif_create_default_wifi_sta();
    g_ap_netif = esp_netif_create_default_wifi_ap();
    
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ret = esp_wifi_init(&cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi初始化失败: 0x%x", ret);
        return ret;
    }
    
    // 创建重连定时器
    g_reconnect_timer = xTimerCreate("wifi_reconnect", 
                                   pdMS_TO_TICKS(3000), 
                                   pdFALSE, 
                                   NULL, 
                                   reconnect_timer_callback);
    if (g_reconnect_timer == NULL) {
        ESP_LOGE(TAG, "创建重连定时器失败");
        return ESP_FAIL;
    }
    
    // 注册事件处理器
    esp_event_handler_instance_t instance_any_id;
    esp_event_handler_instance_t instance_got_ip;
    
    ret = esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                              &wifi_event_handler, NULL, &instance_any_id);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "注册WIFI事件处理器失败: 0x%x", ret);
        return ret;
    }
    
    ret = esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP,
                                              &wifi_event_handler, NULL, &instance_got_ip);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "注册IP事件处理器失败: 0x%x", ret);
        return ret;
    }

    // 注册AP IP分配事件
    ret = esp_event_handler_instance_register(IP_EVENT, IP_EVENT_AP_STAIPASSIGNED,
                                              &wifi_event_handler, NULL, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "注册AP IP事件处理器失败: 0x%x", ret);
        return ret;
    }
    
    ret = esp_wifi_set_storage(WIFI_STORAGE_RAM);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置WiFi存储模式失败: 0x%x", ret);
        return ret;
    }
    
    ESP_LOGI(TAG, "WiFi配置初始化成功");
    return ESP_OK;
}

esp_err_t wifi_switch_to_sta_mode(void)
{
    ESP_LOGI(TAG, "切换到纯STA模式");
    
    // 停止WiFi
    esp_err_t ret = esp_wifi_stop();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "停止WiFi失败: 0x%x", ret);
        return ret;
    }
    
    vTaskDelay(pdMS_TO_TICKS(1000));
    
    // 设置STA模式
    ret = esp_wifi_set_mode(WIFI_MODE_STA);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置STA模式失败: 0x%x", ret);
        return ret;
    }
    
    // 重新启动WiFi
    ret = esp_wifi_start();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动WiFi失败: 0x%x", ret);
        return ret;
    }
    
    // 重新连接
    ret = esp_wifi_connect();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "重新连接失败: 0x%x", ret);
        return ret;
    }
    
    ESP_LOGI(TAG, "已切换到纯STA模式");
    return ESP_OK;
}

esp_err_t wifi_start_apsta(wifi_apsta_config_t *config)
{
    if (!config) {
        ESP_LOGE(TAG, "APSTA配置为空");
        return ESP_ERR_INVALID_ARG;
    }
    
    ESP_LOGI(TAG, "启动APSTA模式");
    ESP_LOGI(TAG, "AP SSID: %s", config->ap.ssid);
    if (strlen(config->sta.ssid) > 0) {
        ESP_LOGI(TAG, "STA SSID: %s", config->sta.ssid);
    }
    
    // 设置APSTA模式
    esp_err_t ret = esp_wifi_set_mode(WIFI_MODE_APSTA);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置APSTA模式失败: 0x%x", ret);
        return ret;
    }
    
    // 配置AP
    wifi_config_t ap_config = {
        .ap = {
            .ssid_len = strlen(config->ap.ssid),
            .channel = config->ap.channel,
            .max_connection = config->ap.max_connection,
            .authmode = config->ap.authmode,
        },
    };
    
    strncpy((char*)ap_config.ap.ssid, config->ap.ssid, sizeof(ap_config.ap.ssid));
    strncpy((char*)ap_config.ap.password, config->ap.password, sizeof(ap_config.ap.password));
    
    if (strlen(config->ap.password) == 0) {
        ap_config.ap.authmode = WIFI_AUTH_OPEN;
    }
    
    ret = esp_wifi_set_config(WIFI_IF_AP, &ap_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置AP配置失败: 0x%x", ret);
        return ret;
    }
    
    // 配置STA（如果提供了STA配置）
    if (strlen(config->sta.ssid) > 0) {
        wifi_config_t sta_config = {
            .sta = {
                .scan_method = WIFI_FAST_SCAN,
                .sort_method = WIFI_CONNECT_AP_BY_SIGNAL,
                .threshold.rssi = -127,
                .threshold.authmode = WIFI_AUTH_OPEN,
            },
        };
        
        strncpy((char*)sta_config.sta.ssid, config->sta.ssid, sizeof(sta_config.sta.ssid));
        strncpy((char*)sta_config.sta.password, config->sta.password, sizeof(sta_config.sta.password));
        
        ret = esp_wifi_set_config(WIFI_IF_STA, &sta_config);
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "设置STA配置失败: 0x%x", ret);
            return ret;
        }
    }
    
    // 启动WiFi
    ret = esp_wifi_start();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动WiFi失败: 0x%x", ret);
        return ret;
    }
    
    // 如果提供了STA配置，开始连接
    if (strlen(config->sta.ssid) > 0) {
        ret = esp_wifi_connect();
        if (ret != ESP_OK) {
            ESP_LOGE(TAG, "启动WiFi连接失败: 0x%x", ret);
            return ret;
        }
        g_wifi_state = WIFI_STATE_CONNECTING;
    }
    
    g_reconnect_attempts = 0;
    
    return ESP_OK;
}

esp_err_t wifi_start_sta(wifi_sta_config_custom_t *config)
{
    if (!config) {
        ESP_LOGE(TAG, "STA配置为空");
        return ESP_ERR_INVALID_ARG;
    }
    
    ESP_LOGI(TAG, "启动STA模式, SSID: %s", (const char*)config->ssid);
    
    // 先设置模式
    esp_err_t ret = esp_wifi_set_mode(WIFI_MODE_STA);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置STA模式失败: 0x%x", ret);
        return ret;
    }
    
    // 配置WiFi
    wifi_config_t wifi_config = {
        .sta = {
            .scan_method = WIFI_FAST_SCAN,
            .sort_method = WIFI_CONNECT_AP_BY_SIGNAL,
            .threshold.rssi = -127,
            .threshold.authmode = WIFI_AUTH_OPEN,
        },
    };
    
    strncpy((char*)wifi_config.sta.ssid, (const char*)config->ssid, sizeof(wifi_config.sta.ssid));
    strncpy((char*)wifi_config.sta.password, (const char*)config->password, sizeof(wifi_config.sta.password));
    
    ret = esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置STA配置失败: 0x%x", ret);
        return ret;
    }
    
    // 启动WiFi
    ret = esp_wifi_start();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动WiFi失败: 0x%x", ret);
        return ret;
    }
    
    // 开始连接
    ret = esp_wifi_connect();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动WiFi连接失败: 0x%x", ret);
        return ret;
    }
    
    g_wifi_state = WIFI_STATE_CONNECTING;
    g_reconnect_attempts = 0;
    
    return ESP_OK;
}

esp_err_t wifi_start_ap(wifi_ap_config_custom_t *config)
{
    if (!config) {
        ESP_LOGE(TAG, "AP配置为空");
        return ESP_ERR_INVALID_ARG;
    }
    
    ESP_LOGI(TAG, "启动AP模式, SSID: %s", (const char*)config->ssid);
    
    // 先设置模式
    esp_err_t ret = esp_wifi_set_mode(WIFI_MODE_AP);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置AP模式失败: 0x%x", ret);
        return ret;
    }
    
    // 配置AP
    wifi_config_t wifi_config = {
        .ap = {
            .ssid_len = strlen((const char*)config->ssid),
            .channel = config->channel,
            .max_connection = config->max_connection,
            .authmode = config->authmode,
        },
    };
    
    strncpy((char*)wifi_config.ap.ssid, (const char*)config->ssid, sizeof(wifi_config.ap.ssid));
    strncpy((char*)wifi_config.ap.password, (const char*)config->password, sizeof(wifi_config.ap.password));
    
    if (strlen((const char*)config->password) == 0) {
        wifi_config.ap.authmode = WIFI_AUTH_OPEN;
    }
    
    ret = esp_wifi_set_config(WIFI_IF_AP, &wifi_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置AP配置失败: 0x%x", ret);
        return ret;
    }
    
    ret = esp_wifi_start();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动AP模式失败: 0x%x", ret);
        return ret;
    }
    
    return ESP_OK;
}

esp_err_t wifi_connect_to_ap(const char *ssid, const char *password)
{
    if (!ssid || strlen(ssid) == 0) {
        return ESP_ERR_INVALID_ARG;
    }
    
    ESP_LOGI(TAG, "连接WiFi: %s", ssid);
    
    // 配置STA
    wifi_config_t wifi_config = {
        .sta = {
            .scan_method = WIFI_FAST_SCAN,
            .sort_method = WIFI_CONNECT_AP_BY_SIGNAL,
            .threshold.rssi = -127,
            .threshold.authmode = WIFI_AUTH_OPEN,
        },
    };
    
    strncpy((char*)wifi_config.sta.ssid, ssid, sizeof(wifi_config.sta.ssid));
    if (password) {
        strncpy((char*)wifi_config.sta.password, password, sizeof(wifi_config.sta.password));
    }
    
    esp_err_t ret = esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置STA配置失败: 0x%x", ret);
        return ret;
    }
    
    // 开始连接
    ret = esp_wifi_connect();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动WiFi连接失败: 0x%x", ret);
        return ret;
    }
    
    g_wifi_state = WIFI_STATE_CONNECTING;
    g_reconnect_attempts = 0;
    
    return ESP_OK;
}

esp_err_t wifi_stop(void)
{
    ESP_LOGI(TAG, "停止WiFi");
    g_wifi_connected = false;
    g_wifi_state = WIFI_STATE_DISCONNECTED;
    memset(g_ip_address, 0, sizeof(g_ip_address));
    
    if (g_reconnect_timer) {
        xTimerStop(g_reconnect_timer, 0);
    }
    
    return esp_wifi_stop();
}

wifi_mode_t wifi_get_mode(void)
{
    wifi_mode_t mode;
    if (esp_wifi_get_mode(&mode) == ESP_OK) {
        return mode;
    }
    return WIFI_MODE_NULL;
}

esp_err_t wifi_get_ip_address(char* ip_addr, size_t len)
{
    if (!ip_addr || len < 16) return ESP_ERR_INVALID_ARG;
    if (strlen(g_ip_address) > 0) {
        strncpy(ip_addr, g_ip_address, len);
        return ESP_OK;
    }
    return ESP_ERR_NOT_FOUND;
}

esp_err_t wifi_get_ap_ip_address(char* ip_addr, size_t len)
{
    if (!ip_addr || len < 16) return ESP_ERR_INVALID_ARG;
    strncpy(ip_addr, g_ap_ip_address, len);
    return ESP_OK;
}

void wifi_set_event_callback(wifi_event_callback_t callback)
{
    g_wifi_callback = callback;
}

bool wifi_is_connected(void)
{
    return g_wifi_connected;
}

wifi_state_t wifi_get_connection_state(void)
{
    return g_wifi_state;
}

wifi_ap_record_t* wifi_scan_networks(uint16_t *ap_count)
{
    ESP_LOGI(TAG, "开始扫描WiFi网络");
    
    uint16_t number = 20;
    wifi_ap_record_t *ap_info = malloc(sizeof(wifi_ap_record_t) * number);
    if (!ap_info) {
        ESP_LOGE(TAG, "分配内存失败");
        return NULL;
    }
    
    memset(ap_info, 0, sizeof(wifi_ap_record_t) * number);
    
    wifi_scan_config_t scan_config = {
        .ssid = NULL,
        .bssid = NULL,
        .channel = 0,
        .show_hidden = true,
        .scan_type = WIFI_SCAN_TYPE_ACTIVE,
        .scan_time.active.min = 100,
        .scan_time.active.max = 300
    };
    
    esp_err_t ret = esp_wifi_scan_start(&scan_config, true);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi扫描失败: 0x%x", ret);
        free(ap_info);
        return NULL;
    }
    
    ret = esp_wifi_scan_get_ap_records(&number, ap_info);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "获取扫描结果失败: 0x%x", ret);
        free(ap_info);
        return NULL;
    }
    
    *ap_count = number;
    ESP_LOGI(TAG, "扫描完成，发现 %d 个网络", number);
    
    return ap_info;
}

esp_err_t wifi_save_config(wifi_sta_config_custom_t *config)
{
    if (!config) return ESP_ERR_INVALID_ARG;
    
    nvs_handle_t nvs_handle;
    esp_err_t ret = nvs_open("wifi_config", NVS_READWRITE, &nvs_handle);
    if (ret != ESP_OK) return ret;
    
    ret = nvs_set_str(nvs_handle, "ssid", (const char*)config->ssid);
    if (ret == ESP_OK)
        ret = nvs_set_str(nvs_handle, "password", (const char*)config->password);
    
    if (ret == ESP_OK)
        ret = nvs_commit(nvs_handle);
    
    nvs_close(nvs_handle);
    return ret;
}

esp_err_t wifi_load_config(wifi_sta_config_custom_t *config)
{
    if (!config) return ESP_ERR_INVALID_ARG;
    
    nvs_handle_t nvs_handle;
    esp_err_t ret = nvs_open("wifi_config", NVS_READONLY, &nvs_handle);
    if (ret != ESP_OK) return ret;
    
    size_t required_size = 0;
    
    ret = nvs_get_str(nvs_handle, "ssid", NULL, &required_size);
    if (ret == ESP_OK && required_size > 0)
        ret = nvs_get_str(nvs_handle, "ssid", (char*)config->ssid, &required_size);
    
    if (ret == ESP_OK) {
        ret = nvs_get_str(nvs_handle, "password", NULL, &required_size);
        if (ret == ESP_OK && required_size > 0)
            ret = nvs_get_str(nvs_handle, "password", (char*)config->password, &required_size);
    }
    
    nvs_close(nvs_handle);
    return ret;
}

// 自动重连启动函数
esp_err_t wifi_start_auto_reconnect(void)
{
    ESP_LOGI(TAG, "启动WiFi自动重连");
    g_reconnect_attempts = 0;
    g_wifi_state = WIFI_STATE_CONNECTING;
    
    // 设置WiFi为STA模式并启动
    esp_err_t ret = esp_wifi_set_mode(WIFI_MODE_STA);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置STA模式失败: 0x%x", ret);
        return ret;
    }
    
    ret = esp_wifi_start();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动WiFi失败: 0x%x", ret);
        return ret;
    }
    
    return esp_wifi_connect();
}