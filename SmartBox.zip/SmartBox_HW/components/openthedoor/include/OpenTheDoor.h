/**
 * *****************************************************************************
 * @file buzzer_relay.h
 * @brief 蜂鸣器和继电器控制组件
 * @version 1.0
 * @date 2025-11-08
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * 
 * @par 修改日志:
 * Date       Version     Author      Description
 * 2025-11-08 1.0         zhanhuangbin  初始版本
 * *****************************************************************************
 */

#ifndef __OPENTHEDOOR_H__
#define __OPENTHEDOOR_H__

#include "esp_err.h"
#include "driver/gpio.h"

// 默认引脚定义
#define BUZZER_DEFAULT_PIN     GPIO_NUM_47
#define SERVO_DEFAULT_PIN      GPIO_NUM_12

/**
 * @brief 初始化蜂鸣器
 * @param buzzer_pin 蜂鸣器引脚
 * @return esp_err_t 错误代码
 */
esp_err_t buzzer_init(gpio_num_t buzzer_pin);

/**
 * @brief 蜂鸣器鸣叫
 * @param duration_ms 鸣叫持续时间(ms)
 */
void buzzer_beep(uint32_t duration_ms);

/**
 * @brief 播放成功提示音
 */
void buzzer_success(void);

/**
 * @brief 播放失败提示音
 */
void buzzer_failure(void);

/**
 * @brief 播放操作提示音
 */
void buzzer_operation(void);

/**
 * @brief 初始化舵机（SG90）
 * @param servo_pin 舵机信号引脚
 * @return esp_err_t 错误代码
 */
esp_err_t servo_init(gpio_num_t servo_pin);

/**
 * @brief 设置舵机角度
 * @param angle 目标角度（0~180）
 * @note 0° 对应 0.5ms 脉宽，180° 对应 2.5ms 脉宽
 */
void servo_set_angle(int angle);

/**
 * @brief 控制门锁（舵机模拟）
 * @param open true: 开门（转到180°），false: 关门（转到0°）
 */
void door_control(bool open);

#endif /* __OPENTHEDOOR_H__ */