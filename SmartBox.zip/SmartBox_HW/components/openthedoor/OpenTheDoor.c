/**
 * *****************************************************************************
 * @file OpenTheDoor.c
 * @brief 蜂鸣器和门锁 GPIO 控制组件
 * @version 3.0
 * @date 2026-04-19
 *
 * @copyright Copyright (c) 2025 zhanhuangbin
 *
 * @par 修改日志:
 * Date       Version     Author      Description
 * 2025-11-08 1.0         zhanhuangbin  初始版本（继电器）
 * 2026-04-19 3.0         zhanhuangbin  替换舵机为 GPIO 高电平输出
 * *****************************************************************************
 */

#include "OpenTheDoor.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"

static const char *TAG = "BuzzerLock";

// 蜂鸣器状态
static gpio_num_t s_buzzer_pin = BUZZER_DEFAULT_PIN;
static bool s_buzzer_initialized = false;

// 门锁控制状态
static gpio_num_t s_lock_pin = SERVO_DEFAULT_PIN;
static bool s_lock_initialized = false;

// ==================== 蜂鸣器部分（保持不变） ====================
esp_err_t buzzer_init(gpio_num_t buzzer_pin)
{
    s_buzzer_pin = buzzer_pin;
    
    gpio_config_t buzzer_cfg = {
        .pin_bit_mask = (1ULL << s_buzzer_pin),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    esp_err_t ret = gpio_config(&buzzer_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "配置蜂鸣器引脚失败");
        return ret;
    }
    
    // 初始状态：不响（低电平触发蜂鸣器，故初始为高电平）
    gpio_set_level(s_buzzer_pin, 1);
    s_buzzer_initialized = true;
    ESP_LOGI(TAG, "蜂鸣器初始化成功，引脚：%d", s_buzzer_pin);
    return ESP_OK;
}

void buzzer_beep(uint32_t duration_ms)
{
    if (!s_buzzer_initialized) return;
    
    gpio_set_level(s_buzzer_pin, 0); // 低电平触发
    vTaskDelay(pdMS_TO_TICKS(duration_ms));
    gpio_set_level(s_buzzer_pin, 1); // 停止
}

void buzzer_success(void)
{
    ESP_LOGI(TAG, "播放成功提示音");
    buzzer_beep(200);
}

void buzzer_failure(void)
{
    ESP_LOGI(TAG, "播放失败提示音");
    for (int i = 0; i < 3; i++) {
        buzzer_beep(100);
        if (i < 2) vTaskDelay(pdMS_TO_TICKS(50));
    }
}

void buzzer_operation(void)
{
    ESP_LOGI(TAG, "播放操作提示音");
    buzzer_beep(50);
}

// ==================== 门锁控制部分（替换为 GPIO 高/低电平） ====================
esp_err_t lock_control_init(gpio_num_t lock_pin)
{
    s_lock_pin = lock_pin;
    
    gpio_config_t lock_cfg = {
        .pin_bit_mask = (1ULL << s_lock_pin),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    esp_err_t ret = gpio_config(&lock_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "配置门锁控制引脚失败");
        return ret;
    }
    
    // 初始状态：输出低电平（门锁关闭）
    gpio_set_level(s_lock_pin, 0);
    s_lock_initialized = true;
    ESP_LOGI(TAG, "门锁控制引脚初始化成功，引脚：%d，初始低电平", s_lock_pin);
    return ESP_OK;
}

void door_control(bool open)
{
    if (!s_lock_initialized) {
        ESP_LOGE(TAG, "门锁控制引脚未初始化，无法控制");
        return;
    }
    
    if (open) {
        ESP_LOGI(TAG, "开门：输出高电平");
        gpio_set_level(s_lock_pin, 1);
        // 保持高电平 3 秒（模拟开门时间）
        vTaskDelay(pdMS_TO_TICKS(3000));
        // 自动关门：拉低电平
        gpio_set_level(s_lock_pin, 0);
        ESP_LOGI(TAG, "自动关门：输出低电平");
    } else {
        ESP_LOGI(TAG, "关门：输出低电平");
        gpio_set_level(s_lock_pin, 0);
    }
}

// 为保持向后兼容，提供旧的 servo_init 函数别名（内部调用 lock_control_init）
esp_err_t servo_init(gpio_num_t servo_pin)
{
    return lock_control_init(servo_pin);
}