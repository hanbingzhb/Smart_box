/**
 * *****************************************************************************
 * @file OLED.c
 * @brief OLED显示驱动
 * @version 1.0
 * @date 2025-11-08
 *
 * @copyright Copyright (c) 2025  zhanhuangbin
 *
 * @par 修改日志:
 * Date       Version     Author      Description
 * 2025-11-08 1.0         zhanhuangbin  导入
 * *****************************************************************************
 */
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "OLED_Font.h"
#include "esp_timer.h"

/* ESP32-S3 引脚配置 - 可根据需要修改 */
#define OLED_SCL_PIN GPIO_NUM_42
#define OLED_SDA_PIN GPIO_NUM_41

/* 引脚电平设置 */
#define OLED_W_SCL(x) gpio_set_level(OLED_SCL_PIN, x)
#define OLED_W_SDA(x) gpio_set_level(OLED_SDA_PIN, x)

/* 微秒延时函数 */
static void delay_us(uint32_t us)
{
    uint32_t start = esp_timer_get_time();
    while ((esp_timer_get_time() - start) < us)
    {
        ;
    }
}

/* 毫秒延时函数 */
static void delay_ms(uint32_t ms)
{
    vTaskDelay(ms / portTICK_PERIOD_MS);
}

/* 引脚初始化 */
void OLED_I2C_Init(void)
{
    gpio_config_t io_conf = {};

    // 配置SCL引脚
    io_conf.pin_bit_mask = (1ULL << OLED_SCL_PIN);
    io_conf.mode = GPIO_MODE_OUTPUT_OD; // 开漏输出
    io_conf.pull_up_en = GPIO_PULLUP_ENABLE;
    io_conf.pull_down_en = GPIO_PULLDOWN_DISABLE;
    io_conf.intr_type = GPIO_INTR_DISABLE;
    gpio_config(&io_conf);

    // 配置SDA引脚
    io_conf.pin_bit_mask = (1ULL << OLED_SDA_PIN);
    gpio_config(&io_conf);

    OLED_W_SCL(1);
    OLED_W_SDA(1);
}

/**
 * @brief  I2C开始
 */
void OLED_I2C_Start(void)
{
    OLED_W_SDA(1);
    OLED_W_SCL(1);
    delay_us(5);
    OLED_W_SDA(0);
    delay_us(5);
    OLED_W_SCL(0);
    delay_us(5);
}

/**
 * @brief  I2C停止
 */
void OLED_I2C_Stop(void)
{
    OLED_W_SDA(0);
    OLED_W_SCL(1);
    delay_us(5);
    OLED_W_SDA(1);
    delay_us(5);
}

/**
 * @brief  I2C发送一个字节
 */
void OLED_I2C_SendByte(uint8_t Byte)
{
    uint8_t i;
    for (i = 0; i < 8; i++)
    {
        OLED_W_SDA(Byte & (0x80 >> i));
        delay_us(2);
        OLED_W_SCL(1);
        delay_us(5);
        OLED_W_SCL(0);
        delay_us(2);
    }
    OLED_W_SCL(1); // 额外的一个时钟，不处理应答信号
    delay_us(5);
    OLED_W_SCL(0);
    delay_us(2);
}

/**
 * @brief  OLED写命令
 */
void OLED_WriteCommand(uint8_t Command)
{
    OLED_I2C_Start();
    OLED_I2C_SendByte(0x78); // 从机地址
    OLED_I2C_SendByte(0x00); // 写命令
    OLED_I2C_SendByte(Command);
    OLED_I2C_Stop();
}

/**
 * @brief  OLED写数据
 */
void OLED_WriteData(uint8_t Data)
{
    OLED_I2C_Start();
    OLED_I2C_SendByte(0x78); // 从机地址
    OLED_I2C_SendByte(0x40); // 写数据
    OLED_I2C_SendByte(Data);
    OLED_I2C_Stop();
}

/**
 * @brief  OLED设置光标位置
 */
void OLED_SetCursor(uint8_t Y, uint8_t X)
{
    OLED_WriteCommand(0xB0 | Y);                 // 设置Y位置
    OLED_WriteCommand(0x10 | ((X & 0xF0) >> 4)); // 设置X位置高4位
    OLED_WriteCommand(0x00 | (X & 0x0F));        // 设置X位置低4位
}

/**
 * @brief  OLED清屏
 */
void OLED_Clear(void)
{
    uint8_t i, j;
    for (j = 0; j < 8; j++)
    {
        OLED_SetCursor(j, 0);
        for (i = 0; i < 128; i++)
        {
            OLED_WriteData(0x00);
        }
    }
}

/**
 * @brief  OLED显示一个字符
 */
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char)
{
    uint8_t i;
    OLED_SetCursor((Line - 1) * 2, (Column - 1) * 8); // 设置光标位置在上半部分
    for (i = 0; i < 8; i++)
    {
        OLED_WriteData(OLED_F8x16[Char - ' '][i]); // 显示上半部分内容
    }
    OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 8); // 设置光标位置在下半部分
    for (i = 0; i < 8; i++)
    {
        OLED_WriteData(OLED_F8x16[Char - ' '][i + 8]); // 显示下半部分内容
    }
}

/**
 * @brief  OLED显示字符串
 */
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String)
{
    uint8_t i;
    for (i = 0; String[i] != '\0'; i++)
    {
        OLED_ShowChar(Line, Column + i, String[i]);
    }
}

/**
 * @brief  OLED次方函数
 */
uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
    uint32_t Result = 1;
    while (Y--)
    {
        Result *= X;
    }
    return Result;
}

/**
 * @brief  OLED显示数字（十进制，正数）
 */
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
    uint8_t i;
    for (i = 0; i < Length; i++)
    {
        OLED_ShowChar(Line, Column + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0');
    }
}

/**
 * @brief  OLED显示数字（十进制，带符号数）
 */
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length)
{
    uint8_t i;
    uint32_t Number1;
    if (Number >= 0)
    {
        OLED_ShowChar(Line, Column, '+');
        Number1 = Number;
    }
    else
    {
        OLED_ShowChar(Line, Column, '-');
        Number1 = -Number;
    }
    for (i = 0; i < Length; i++)
    {
        OLED_ShowChar(Line, Column + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0');
    }
}

/**
 * @brief  OLED显示数字（十六进制，正数）
 */
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
    uint8_t i, SingleNumber;
    for (i = 0; i < Length; i++)
    {
        SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
        if (SingleNumber < 10)
        {
            OLED_ShowChar(Line, Column + i, SingleNumber + '0');
        }
        else
        {
            OLED_ShowChar(Line, Column + i, SingleNumber - 10 + 'A');
        }
    }
}

/**
 * @brief  OLED显示数字（二进制，正数）
 */
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length)
{
    uint8_t i;
    for (i = 0; i < Length; i++)
    {
        OLED_ShowChar(Line, Column + i, Number / OLED_Pow(2, Length - i - 1) % 2 + '0');
    }
}

/**
 * @brief 显示单个16x16中文字符
 */
void OLED_ShowChinese(uint8_t Line, uint8_t Column, chinese_char_index_t index)
{
    if (index >= CHN_MAX_INDEX)
        return;

    const uint8_t *p = OLED_Chinese16x16[index];
    uint8_t i;

    // 上半部分8行（前16字节）
    OLED_SetCursor((Line - 1) * 2, (Column - 1) * 16);
    for (i = 0; i < 16; i++)
    {
        OLED_WriteData(p[i]);
    }

    // 下半部分8行（后16字节）
    OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 16);
    for (i = 16; i < 32; i++)
    {
        OLED_WriteData(p[i]);
    }
}

/**
 * @brief 显示中文字符串
 */
void OLED_ShowChineseString(uint8_t line, uint8_t column, chinese_char_index_t indexes[], uint8_t count)
{
    uint8_t i;
    for (i = 0; i < count; i++)
    {
        OLED_ShowChinese(line, column + i, indexes[i]);
    }
}

/**
 * @brief 显示预定义的词组
 */
void OLED_ShowPhrase(uint8_t line, uint8_t column, phrase_index_t phrase)
{
    if (phrase >= PHRASE_MAX_INDEX)
        return;

    // 计算词组长度
    uint8_t count = 0;
    while (count < 8 && phrase_map[phrase][count] != CHN_MAX_INDEX)
    {
        count++;
    }

    OLED_ShowChineseString(line, column, (chinese_char_index_t *)phrase_map[phrase], count);
}

/**
 * @brief  OLED初始化
 */
void OLED_Init(void)
{
    delay_ms(100); // 上电延时

    OLED_I2C_Init(); // 端口初始化

    OLED_WriteCommand(0xAE); // 关闭显示

    OLED_WriteCommand(0xD5); // 设置显示时钟分频比/振荡器频率
    OLED_WriteCommand(0x80);

    OLED_WriteCommand(0xA8); // 设置多路复用率
    OLED_WriteCommand(0x3F);

    OLED_WriteCommand(0xD3); // 设置显示偏移
    OLED_WriteCommand(0x00);

    OLED_WriteCommand(0x40); // 设置显示开始行

    OLED_WriteCommand(0xA1); // 设置左右方向，0xA1正常 0xA0左右反置

    OLED_WriteCommand(0xC8); // 设置上下方向，0xC8正常 0xC0上下反置

    OLED_WriteCommand(0xDA); // 设置COM引脚硬件配置
    OLED_WriteCommand(0x12);

    OLED_WriteCommand(0x81); // 设置对比度控制
    OLED_WriteCommand(0xCF);

    OLED_WriteCommand(0xD9); // 设置预充电周期
    OLED_WriteCommand(0xF1);

    OLED_WriteCommand(0xDB); // 设置VCOMH取消选择级别
    OLED_WriteCommand(0x30);

    OLED_WriteCommand(0xA4); // 设置整个显示打开/关闭

    OLED_WriteCommand(0xA6); // 设置正常/倒转显示

    OLED_WriteCommand(0x8D); // 设置充电泵
    OLED_WriteCommand(0x14);

    OLED_WriteCommand(0xAF); // 开启显示

    OLED_Clear(); // OLED清屏
}