/**
 * *****************************************************************************
 * @file OLED.h
 * @brief OLED显示驱动
 * @version 1.0
 * @date 2025-11-08
 * 
 * @copyright Copyright (c) 2025  zhanhuangbin
 * 
 * @par 修改日志:
 * Date       Version     Author      Description
 * 2025-11-08 1.0         zhanhuangbin  导入
 * *****************************************************************************
 */
#ifndef __OLED_H__
#define __OLED_H__

#include <stdint.h>
#include "OLED_Font.h"

void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);

/**
 * @brief 显示单个中文字符
 * @param line 行号 (1-4)
 * @param column 列号 (1-8, 每个汉字占2列)
 * @param index 中文字符索引
 */
void OLED_ShowChinese(uint8_t line, uint8_t column, chinese_char_index_t index);

/**
 * @brief 显示中文字符串
 * @param line 行号 (1-4)
 * @param column 起始列号 (1-8)
 * @param indexes 中文字符索引数组
 * @param count 字符数量
 */
void OLED_ShowChineseString(uint8_t line, uint8_t column, chinese_char_index_t indexes[], uint8_t count);

/**
 * @brief 显示预定义的词组
 * @param line 行号 (1-4)
 * @param column 起始列号 (1-8)
 * @param phrase 词组索引
 */
void OLED_ShowPhrase(uint8_t line, uint8_t column, phrase_index_t phrase);

#endif