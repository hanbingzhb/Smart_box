/**
 * *****************************************************************************
 * @file main.c
 * @brief 智能门锁主程序入口
 * @author zhanhuangbin (awa@azxi.link)
 * @version 1.1
 * @date 2025-11-10
 * 
 * @copyright Copyright (c) 2025 zhanhuangbin
 * *****************************************************************************
 */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "app.h"
#include "wifi_config.h"
#include "web_server.h"

static const char *TAG = "Main";

// WiFi配置
static wifi_sta_config_custom_t g_wifi_config = {
    .ssid = "",
    .password = ""
};

// 连接状态标志
static bool g_connection_in_progress = false;
static TickType_t g_connection_start_time = 0;

/**
 * @brief WiFi配置回调函数
 */
static esp_err_t wifi_config_callback(const char* ssid, const char* password)
{
    ESP_LOGI(TAG, "配置WiFi: SSID=%s", ssid);
    
    // 安全地复制字符串
    size_t ssid_len = strlen(ssid);
    size_t password_len = strlen(password);
    
    if (ssid_len < sizeof(g_wifi_config.ssid)) {
        memcpy(g_wifi_config.ssid, ssid, ssid_len);
        g_wifi_config.ssid[ssid_len] = '\0';
    }
    
    if (password_len < sizeof(g_wifi_config.password)) {
        memcpy(g_wifi_config.password, password, password_len);
        g_wifi_config.password[password_len] = '\0';
    }
    
    // 保存WiFi配置到NVS
    esp_err_t ret = wifi_save_config(&g_wifi_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "保存WiFi配置失败: 0x%x", ret);
        return ret;
    }
    
    ESP_LOGI(TAG, "WiFi配置已保存到NVS");
    
    // 设置连接状态
    g_connection_in_progress = true;
    g_connection_start_time = xTaskGetTickCount();
    
    // 连接WiFi
    ret = wifi_connect_to_ap(ssid, password);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "连接WiFi失败: 0x%x", ret);
        g_connection_in_progress = false;
        return ret;
    }
    
    ESP_LOGI(TAG, "WiFi连接已启动");
    return ESP_OK;
}

/**
 * @brief 切换到纯STA模式任务
 */
static void switch_to_sta_mode_task(void *arg)
{
    ESP_LOGI(TAG, "准备切换到纯STA模式");
    
    // 延迟2秒，确保网页收到连接成功的响应
    vTaskDelay(pdMS_TO_TICKS(2000));
    
    // 停止Web服务器
    web_server_stop();
    ESP_LOGI(TAG, "Web服务器已停止");
    
    // 切换到纯STA模式
    esp_err_t ret = wifi_switch_to_sta_mode();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "切换到STA模式失败: 0x%x", ret);
    } else {
        ESP_LOGI(TAG, "已成功切换到纯STA模式，AP已关闭");
    }
    
    // 启动应用程序（如果之前没有启动）
    esp_err_t app_ret = app_init();
    if (app_ret != ESP_OK) {
        ESP_LOGE(TAG, "应用程序初始化失败: 0x%x", app_ret);
    }
    
    vTaskDelete(NULL);
}

/**
 * @brief 启动APSTA模式进行配网
 */
static void start_apsta_mode_for_config(void)
{
    ESP_LOGI(TAG, "启动APSTA模式进行配网");
    
    wifi_apsta_config_t apsta_config = {
        .ap = {
            .ssid = "SmartLock_AP",
            .password = "",
            .channel = 1,
            .authmode = WIFI_AUTH_OPEN,
            .max_connection = 4
        },
        .sta = {
            .ssid = "",
            .password = ""
        }
    };
    
    esp_err_t ret = wifi_start_apsta(&apsta_config);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动APSTA模式失败: 0x%x", ret);
        return;
    }
    
    // 启动Web服务器进行配网
    web_server_init();
    web_server_set_wifi_callback(wifi_config_callback);
    web_server_start();
    
    ESP_LOGI(TAG, "APSTA模式启动完成");
    ESP_LOGI(TAG, "AP热点: SmartLock_AP, 可通过 http://192.168.4.1 进行配网");
    ESP_LOGI(TAG, "STA模式可用于扫描和连接WiFi网络");
}

/**
 * @brief 监控连接状态任务
 */
static void connection_monitor_task(void *arg)
{
    while (1) {
        if (g_connection_in_progress) {
            // 检查连接状态
            if (wifi_is_connected()) {
                ESP_LOGI(TAG, "WiFi连接成功！准备切换到纯STA模式");
                g_connection_in_progress = false;
                
                char ip_addr[16];
                if (wifi_get_ip_address(ip_addr, sizeof(ip_addr)) == ESP_OK) {
                    ESP_LOGI(TAG, "获取到IP地址: %s", ip_addr);
                }
                
                // 创建任务切换到纯STA模式
                xTaskCreate(switch_to_sta_mode_task, "switch_to_sta", 4096, NULL, 3, NULL);
                
            } else if ((xTaskGetTickCount() - g_connection_start_time) > pdMS_TO_TICKS(30000)) {
                // 30秒连接超时
                ESP_LOGW(TAG, "WiFi连接超时，保持在配网模式");
                g_connection_in_progress = false;
            }
        }
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

/**
 * @brief 网络服务初始化任务
 */
static void network_init_task(void *arg)
{
    ESP_LOGI(TAG, "开始网络服务初始化");
    
    // 尝试从NVS加载WiFi配置
    esp_err_t load_ret = wifi_load_config(&g_wifi_config);
    
    if (load_ret == ESP_OK && strlen((char*)g_wifi_config.ssid) > 0) {
        ESP_LOGI(TAG, "从NVS加载WiFi配置: %s", g_wifi_config.ssid);
        
        // 启动STA模式
        esp_err_t sta_ret = wifi_start_sta(&g_wifi_config);
        if (sta_ret == ESP_OK) {
            ESP_LOGI(TAG, "WiFi STA模式启动成功");
            
            // 等待WiFi连接（最多15秒）
            int retry_count = 0;
            while (!wifi_is_connected() && retry_count < 15) {
                vTaskDelay(pdMS_TO_TICKS(1000));
                retry_count++;
                ESP_LOGI(TAG, "等待WiFi连接... %d/15", retry_count);
            }
            
            if (wifi_is_connected()) {
                char ip_addr[16];
                if (wifi_get_ip_address(ip_addr, sizeof(ip_addr)) == ESP_OK) {
                    ESP_LOGI(TAG, "WiFi连接成功，IP地址: %s", ip_addr);
                } else {
                    ESP_LOGI(TAG, "WiFi连接成功");
                }
                
                // 启动应用程序
                esp_err_t app_ret = app_init();
                if (app_ret != ESP_OK) {
                    ESP_LOGE(TAG, "应用程序初始化失败: 0x%x", app_ret);
                }
                
                vTaskDelete(NULL);
                return;
            } else {
                ESP_LOGW(TAG, "WiFi连接超时，进入配网模式");
                start_apsta_mode_for_config();
            }
        } else {
            ESP_LOGE(TAG, "WiFi STA模式启动失败: 0x%x", sta_ret);
            start_apsta_mode_for_config();
        }
    } else {
        // NVS中没有WiFi配置，进入APSTA配网模式
        ESP_LOGW(TAG, "未找到保存的WiFi配置，进入配网模式");
        start_apsta_mode_for_config();
    }
    
    // 创建连接监控任务
    xTaskCreate(connection_monitor_task, "conn_monitor", 2048, NULL, 1, NULL);
    
    // 任务完成
    vTaskDelete(NULL);
}

void app_main(void)
{
    ESP_LOGI(TAG, "智能储物柜系统启动");
    ESP_LOGI(TAG, "ESP32-S3 IDF v5.4.0");
    ESP_LOGI(TAG, "编译时间: %s %s", __DATE__, __TIME__);

    // 初始化NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    
    // 初始化WiFi配置
    if (wifi_config_init() != ESP_OK) {
        ESP_LOGE(TAG, "WiFi配置初始化失败");
        return;
    }

    web_server_set_device_id("SmartLock-001");

    // 创建网络初始化任务
    xTaskCreate(network_init_task, "net_init", 4096, NULL, 2, NULL);

    ESP_LOGI(TAG, "智能储物柜系统启动完成，进入主循环");
    
    // 主循环保持运行
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(60000));
    }
}